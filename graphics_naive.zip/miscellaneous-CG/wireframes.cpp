#ifndef UNICODE
#define UNICODE
#endif

#pragma warning(disable:4244 4018 4010)

#include <Windows.h>
#include <windowsx.h>
#include <tchar.h>
#include <cmath>
#include <algorithm>
using namespace std;

#define PI 3.1415926535897932384626433832795029
#define F(x,y) (1-x)*(1-x)*exp(-x*x-(y+1)*(y+1))-3*(0.2*x-x*x*x-y*y*y*y*y)*exp(-x*x-y*y)-0.1*exp(-(x+1)*(x+1)-y*y)	// peaks
//#define F(x,y) sin(1-x*x-y*y+abs(x)*y)*exp(-0.1*(x*x+y*y))	// heart
//double F(double x, double y) { double a = 2.5*log(x*x + y * y), b = 5 * atan2(y, x), re = exp(a)*cos(b), im = exp(a)*sin(b) + 1; return log(re*re + im * im + 1); }		// not convergent

#define _RGB(r,g,b) ((COLORREF)(((BYTE)(b)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(r))<<16)))
COLORREF mix(COLORREF a, COLORREF b, double r) { return _RGB((1 - r)*((BYTE*)&a)[2] + r * ((BYTE*)&b)[2], (1 - r)*((BYTE*)&a)[1] + r * ((BYTE*)&b)[1], (1 - r)*(BYTE)a + r * (BYTE)b); }

#ifdef _DEBUG
#define fill_n(First,Count,Val) for (unsigned i = 0, l = clt_w * clt_h; i < l; i++) First[i] = Val;
#define sort_segments mergesort_segments
#else
#include <memory>
#define fill_n(First,Count,Val) uninitialized_fill_n(First, Count, Val)
#define sort_segments heapsort_segments
#endif


class point {
public:
	double x, y, z;
	point() {}
	point(double x, double y, double z) :x(x), y(y), z(z) {}
	point(const point &other) :x(other.x), y(other.y), z(other.z) {}
	point& operator = (const point &other) { x = other.x, y = other.y, z = other.z; return *this; }
	~point() {}

	void normalize() { double m = sqrt(x*x + y * y + z * z); x /= m, y /= m, z /= m; }
	point operator - () const { return point(-x, -y, -z); }
	void operator += (const point &p) { x += p.x, y += p.y, z += p.z; }
	void operator -= (const point &p) { x -= p.x, y -= p.y, z -= p.z; }
	void operator *= (const double &c) { x *= c, y *= c, z *= c; }
	void operator /= (const double &c) { x /= c, y /= c, z /= c; }
};
class affine { 	// matrix
	double p[4][4];
public:
	affine() { for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) p[i][j] = i == j ? 1 : 0; }
	affine(const affine &other) { for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) p[i][j] = other.p[i][j]; }
	affine(const double& _00, const double& _01, const double& _02,
		const double& _10, const double& _11, const double& _12, const double& _20, const double& _21, const double& _22) {
		p[0][0] = _00, p[0][1] = _01, p[0][2] = _02, p[1][0] = _10, p[1][1] = _11, p[1][2] = _12, p[2][0] = _20, p[2][1] = _21, p[2][2] = _22,
			p[0][3] = p[1][3] = p[2][3] = 0, p[3][0] = p[3][1] = p[3][2] = 0, p[3][3] = 1;
	}
	affine(const double& _00, const double& _01, const double& _02, const double& _03, const double& _10, const double& _11, const double& _12, const double &_13,
		const double& _20, const double& _21, const double& _22, const double& _23, const double& _30, const double& _31, const double& _32, const double& _33) {
		p[0][0] = _00, p[0][1] = _01, p[0][2] = _02, p[0][3] = _03, p[1][0] = _10, p[1][1] = _11, p[1][2] = _12, p[1][3] = _13,
			p[2][0] = _20, p[2][1] = _21, p[2][2] = _22, p[2][3] = _23, p[3][0] = _30, p[3][1] = _31, p[3][2] = _32, p[3][3] = _33;
	}
	~affine() {}
	const double* operator [] (const unsigned &n) const { return &p[n][0]; }
	double* operator [] (const unsigned &n) { return &p[n][0]; }
	point operator * (const point &P) const {
		double m = p[3][0] * P.x + p[3][1] * P.y + p[3][2] * P.z + p[3][3];
		return point((p[0][0] * P.x + p[0][1] * P.y + p[0][2] * P.z + p[0][3]) / m,
			(p[1][0] * P.x + p[1][1] * P.y + p[1][2] * P.z + p[1][3]) / m, (p[2][0] * P.x + p[2][1] * P.y + p[2][2] * P.z + p[2][3]) / m);
	}
	affine operator * (const affine &A) const {
		affine R;
		for (int m = 0; m < 4; m++) {
			for (int n = 0; n < 4; n++) {
				R.p[m][n] = 0;
				for (int i = 0; i < 4; i++) R.p[m][n] += p[m][i] * A.p[i][n];
			}
		}
		return R;
	}
	affine invert() const {
		affine R;
		R.p[0][0] = p[1][1] * p[2][2] * p[3][3] - p[1][1] * p[2][3] * p[3][2] - p[2][1] * p[1][2] * p[3][3] + p[2][1] * p[1][3] * p[3][2] + p[3][1] * p[1][2] * p[2][3] - p[3][1] * p[1][3] * p[2][2];
		R.p[1][0] = -p[1][0] * p[2][2] * p[3][3] + p[1][0] * p[2][3] * p[3][2] + p[2][0] * p[1][2] * p[3][3] - p[2][0] * p[1][3] * p[3][2] - p[3][0] * p[1][2] * p[2][3] + p[3][0] * p[1][3] * p[2][2];
		R.p[2][0] = p[1][0] * p[2][1] * p[3][3] - p[1][0] * p[2][3] * p[3][1] - p[2][0] * p[1][1] * p[3][3] + p[2][0] * p[1][3] * p[3][1] + p[3][0] * p[1][1] * p[2][3] - p[3][0] * p[1][3] * p[2][1];
		R.p[3][0] = -p[1][0] * p[2][1] * p[3][2] + p[1][0] * p[2][2] * p[3][1] + p[2][0] * p[1][1] * p[3][2] - p[2][0] * p[1][2] * p[3][1] - p[3][0] * p[1][1] * p[2][2] + p[3][0] * p[1][2] * p[2][1];
		R.p[0][1] = -p[0][1] * p[2][2] * p[3][3] + p[0][1] * p[2][3] * p[3][2] + p[2][1] * p[0][2] * p[3][3] - p[2][1] * p[0][3] * p[3][2] - p[3][1] * p[0][2] * p[2][3] + p[3][1] * p[0][3] * p[2][2];
		R.p[1][1] = p[0][0] * p[2][2] * p[3][3] - p[0][0] * p[2][3] * p[3][2] - p[2][0] * p[0][2] * p[3][3] + p[2][0] * p[0][3] * p[3][2] + p[3][0] * p[0][2] * p[2][3] - p[3][0] * p[0][3] * p[2][2];
		R.p[2][1] = -p[0][0] * p[2][1] * p[3][3] + p[0][0] * p[2][3] * p[3][1] + p[2][0] * p[0][1] * p[3][3] - p[2][0] * p[0][3] * p[3][1] - p[3][0] * p[0][1] * p[2][3] + p[3][0] * p[0][3] * p[2][1];
		R.p[3][1] = p[0][0] * p[2][1] * p[3][2] - p[0][0] * p[2][2] * p[3][1] - p[2][0] * p[0][1] * p[3][2] + p[2][0] * p[0][2] * p[3][1] + p[3][0] * p[0][1] * p[2][2] - p[3][0] * p[0][2] * p[2][1];
		R.p[0][2] = p[0][1] * p[1][2] * p[3][3] - p[0][1] * p[1][3] * p[3][2] - p[1][1] * p[0][2] * p[3][3] + p[1][1] * p[0][3] * p[3][2] + p[3][1] * p[0][2] * p[1][3] - p[3][1] * p[0][3] * p[1][2];
		R.p[1][2] = -p[0][0] * p[1][2] * p[3][3] + p[0][0] * p[1][3] * p[3][2] + p[1][0] * p[0][2] * p[3][3] - p[1][0] * p[0][3] * p[3][2] - p[3][0] * p[0][2] * p[1][3] + p[3][0] * p[0][3] * p[1][2];
		R.p[2][2] = p[0][0] * p[1][1] * p[3][3] - p[0][0] * p[1][3] * p[3][1] - p[1][0] * p[0][1] * p[3][3] + p[1][0] * p[0][3] * p[3][1] + p[3][0] * p[0][1] * p[1][3] - p[3][0] * p[0][3] * p[1][1];
		R.p[3][2] = -p[0][0] * p[1][1] * p[3][2] + p[0][0] * p[1][2] * p[3][1] + p[1][0] * p[0][1] * p[3][2] - p[1][0] * p[0][2] * p[3][1] - p[3][0] * p[0][1] * p[1][2] + p[3][0] * p[0][2] * p[1][1];
		R.p[0][3] = -p[0][1] * p[1][2] * p[2][3] + p[0][1] * p[1][3] * p[2][2] + p[1][1] * p[0][2] * p[2][3] - p[1][1] * p[0][3] * p[2][2] - p[2][1] * p[0][2] * p[1][3] + p[2][1] * p[0][3] * p[1][2];
		R.p[1][3] = p[0][0] * p[1][2] * p[2][3] - p[0][0] * p[1][3] * p[2][2] - p[1][0] * p[0][2] * p[2][3] + p[1][0] * p[0][3] * p[2][2] + p[2][0] * p[0][2] * p[1][3] - p[2][0] * p[0][3] * p[1][2];
		R.p[2][3] = -p[0][0] * p[1][1] * p[2][3] + p[0][0] * p[1][3] * p[2][1] + p[1][0] * p[0][1] * p[2][3] - p[1][0] * p[0][3] * p[2][1] - p[2][0] * p[0][1] * p[1][3] + p[2][0] * p[0][3] * p[1][1];
		R.p[3][3] = p[0][0] * p[1][1] * p[2][2] - p[0][0] * p[1][2] * p[2][1] - p[1][0] * p[0][1] * p[2][2] + p[1][0] * p[0][2] * p[2][1] + p[2][0] * p[0][1] * p[1][2] - p[2][0] * p[0][2] * p[1][1];
		double det = p[0][0] * R.p[0][0] + p[0][1] * R.p[1][0] + p[0][2] * R.p[2][0] + p[0][3] * R.p[3][0];
		if (det == 0) for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) R.p[i][j] = NAN;
		else for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) R.p[i][j] /= det;
		return R;
	}

	void init() { for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) p[i][j] = i == j ? 1 : 0; }
	void scale(double x, double y, double z) { *this = affine(x, 0, 0, 0, y, 0, 0, 0, z)*(*this); }
	void translate(double x, double y, double z) { *this = affine(1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z, 0, 0, 0, 1)*(*this); }
	void rotate(double x, double y, double z) {
		*this = affine(		// x-y-z
			cos(y)*cos(z), sin(x)*sin(y)*cos(z) - cos(x)*sin(z), cos(x)*sin(y)*cos(z) + sin(x)*sin(z),
			cos(y)*sin(z), sin(x)*sin(y)*sin(z) + cos(x)*cos(z), cos(x)*sin(y)*sin(z) - sin(x)*cos(z),
			-sin(y), sin(x)*cos(y), cos(x)*cos(y))*(*this);
	}
	void rotate_xz(double x, double z) { *this = affine(cos(z), -sin(z), 0, cos(x)*sin(z), cos(x)*cos(z), -sin(x), sin(x)*sin(z), sin(x)*cos(z), cos(x))*(*this); }
};
class point2D {
public:
	double x, y;
	point2D() {}
	template<typename T, typename t> point2D(T x, t y) :x((double)x), y((double)y) {}
	point2D(const point &other) :x(other.x), y(other.y) {}
	point2D& operator = (const point &other) { x = other.x, y = other.y; return *this; }
	~point2D() {}

	void operator -= (const point2D &p) { x -= p.x, y -= p.y; }
};
class segment {
public:
	point A, B;
	double cz;
	COLORREF col;
	segment() {}
	segment(const point &E1, const point &E2) { A = E1, B = E2, cz = 0.5*(E1.z + E2.z); }
	segment(const point &E1, const point &E2, const COLORREF &col) { A = E1, B = E2, cz = 0.5*(E1.z + E2.z), this->col = col; }
	segment(const segment &other) { A = other.A, B = other.B, cz = other.cz, col = other.col; }
	segment& operator = (const segment &other) { A = other.A, B = other.B, cz = other.cz, col = other.col; return *this; }
	~segment() {}
};

HWND HWnd;
RECT Client; unsigned clt_w, clt_h;
COLORREF *img; HBITMAP HImg;
point2D Cursor;
bool mouse_down = false; point2D OrigCursor(NAN, NAN);
void drawLine(int x1, int y1, int x2, int y2, COLORREF fill) {	// draw segments on img, with security check
	const int w = clt_w, h = clt_h;
	double slope, intercept; int d;
	if (abs(y2 - y1) < abs(x2 - x1)) {
		if (x1 > x2) swap(x1, x2), swap(y1, y2);
		if (x2 < 0 || (y1 < 0 && y2 < 0)) return;
		if (x1 > int(w) || (y1 > int(h) && y2 > int(h))) return;
		slope = double(y2 - y1) / (x2 - x1);
		intercept = y1 - x1 * slope;
		if (x1 < 0) x1 = 0, y1 = intercept;
		if (x2 > w) x2 = w, y2 = w * slope + intercept;
		if (x1*slope + intercept < 0) x1 = -intercept / slope, y1 = 0;
		else if (x1*slope + intercept > h) x1 = (h - intercept) / slope, y1 = h;
		if (x2*slope + intercept < 0) x2 = -intercept / slope, y2 = 0;
		else if (x2*slope + intercept > h) x2 = (h - intercept) / slope, y2 = h;
		for (int i = x1; i < x2; i++) {
			d = i * slope + intercept;
			if (d >= 0 && d < h) img[d * w + i] = fill;
		}
	}
	else {
		if (y1 > y2) swap(x1, x2), swap(y1, y2);
		if (y2 < 0 || (x1 < 0 && x2 < 0)) return;
		if (y1 > int(h) || (x1 > int(w) && x2 > int(w))) return;
		slope = double(x2 - x1) / (y2 - y1);
		intercept = x1 - y1 * slope;
		if (y1 < 0) y1 = 0, x1 = intercept;
		if (y2 > h) y2 = h, x2 = h * slope + intercept;
		if (y1*slope + intercept < 0) y1 = -intercept / slope, x1 = 0;
		else if (y1*slope + intercept > w) y1 = (w - intercept) / slope, x1 = w;
		if (y2*slope + intercept < 0) y2 = -intercept / slope, x2 = 0;
		else if (y2*slope + intercept > w) y2 = (w - intercept) / slope, x2 = w;
		for (int i = y1; i < y2; i++) {
			d = i * slope + intercept;
			if (d >= 0 && d < w) img[i * w + d] = fill;
		}
	}
}

double rx = -1.2, rz = -0.8, orig_rx = rx, orig_rz = rz;
point Center(0, 0, 0);
affine Tr;
double Unit = 70; int Ng = 40; double gs = 4. / Ng;
void init_mat() {
	Tr.init();
	Tr.translate(-Center.x, -Center.y, -Center.z);
	Tr.rotate_xz(rx, rz);
}
void fix_ang(double &theta) {
	if (!(abs(theta) < 1e+6)) { theta = NAN; return; }
	while (theta < 0) theta += 2 * PI;
	while (theta > 2 * PI) theta -= 2 * PI;
}


point2D fromCoordinate(point P) {
	P = Tr * P;
	return point2D(P.x * Unit + 0.5*clt_w, P.y * Unit + 0.5*clt_h);
}
point fromCanvas(point2D P) {
	point2D O = fromCoordinate(point(0, 0, 0)), A = fromCoordinate(point(1, 0, 0)), B = fromCoordinate(point(0, 1, 0));
	A -= O, B -= O, P -= O;		// P = O + u*A + v*B  =>  [u v] = [A B].invert * [P-O]
	double a = A.x, b = B.x, c = A.y, d = B.y, det = a * d - b * c;
	A.x = d / det, B.x = -b / det, A.y = -c / det, B.y = a / det;
	return point(A.x*P.x + B.x*P.y, A.y*P.x + B.y*P.y, 0);
}

void mergesort_segments(segment* s, unsigned N) {	// sort by cz from smallest to largest
	if (N == 1) return;
	if (N == 2) {
		if (s[0].cz > s[1].cz) swap(s[0], s[1]);
		return;
	}
	if (N == 3) {
		if (s[0].cz > s[1].cz) swap(s[0], s[1]);
		if (s[1].cz > s[2].cz) swap(s[1], s[2]);
		if (s[0].cz > s[1].cz) swap(s[0], s[1]);
		return;
	}
	unsigned m = N / 2, n = N - m;
	segment *u = new segment[m], *v = new segment[n];
	memcpy(u, s, m * sizeof(segment)), memcpy(v, s + m, n * sizeof(segment));
	mergesort_segments(u, m), mergesort_segments(v, n);
	int i, j, k;
	for (i = j = k = 0; i < m && j < n; k++) {
		if (u[i].cz < v[j].cz) s[k] = u[i], i++;
		else s[k] = v[j], j++;
	}
	for (; i < m; i++, k++) s[k] = u[i];
	for (; j < n; j++, k++) s[k] = v[j];
	delete[] u; delete[] v;
};
void heapsort_segments(segment* s, unsigned N) {
	auto adjustHeap = [](segment* s, int start, int end) {
		int parent = start, child = parent * 2 + 1;
		while (child <= end) {
			if (child + 1 <= end && s[child].cz < s[child + 1].cz) child++;
			if (s[parent].cz > s[child].cz) return;
			else swap(s[parent], s[child]), parent = child, child = parent * 2 + 1;
		}
	};
	for (int i = N / 2 - 1; i >= 0; i--) adjustHeap(s, i, N - 1);
	for (int i = N - 1; i > 0; i--) swap(s[0], s[i]), adjustHeap(s, 0, i - 1);
}
void graph() {
	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);

	fill_n(img, clt_w * clt_h, _RGB(0, 0, 0));

	auto colorf = [](double t) -> COLORREF {	// fitted from Mathematica color function "TemperatureMap", 0<t<1
		double r = (((((-4.25833 * t + 4.44967) * t + 11.9988) * t - 21.8238) * t + 9.67504) * t + 0.550922) * t + 0.192637,
			g = (((((9.56635 * t - 28.444) * t + 33.7071) * t - 22.65) * t + 6.69089) * t + 0.954291) * t + 0.313476,
			b = (((((-104.058 * t + 293.31) * t - 296.559) * t + 128.762) * t - 24.036) * t + 1.7725) * t + 0.907322;
		if (r > 1) r = 1; if (g > 1) g = 1; if (b > 1) b = 1; if (r < 0) r = 0; if (g < 0) g = 0; if (b < 0) b = 0;
		return _RGB(r * 255, g * 255, b * 255);
	};
	init_mat();

	unsigned N = 2 * 2 * Ng*(2 * Ng + 1), M = 2 * Ng, L = N + 3 * M;
	segment* sgs = new segment[L];

	// Surface
	double min_z = INFINITY, max_z = -INFINITY;
	for (int i = -Ng, n = 0; i <= Ng; i++) {
		for (int j = -Ng; j <= Ng; j++) {
			double x = gs * i + Center.x, y = gs * j + Center.y, x_ = gs * (i + 1) + Center.x, y_ = gs * (j + 1) + Center.y;
			point p = point(x, y, F(x, y)), px = point(x_, y, F(x_, y)), py = point(x, y_, F(x, y_));
			if (!isnan(p.z)) min_z = min(min_z, p.z), max_z = max(max_z, p.z);
			if (i != Ng) sgs[n] = segment(p, px), n++;
			if (j != Ng) sgs[n] = segment(p, py), n++;
		}
	}
	double dz = max_z - min_z;
	for (int i = 0; i < N; i++) sgs[i].col = colorf((sgs[i].cz - min_z) / dz);

	// Axis
	for (int i = -Ng, n = N; i < Ng; i++) {
		sgs[n] = segment(point(1.2*i*gs + Center.x, 0, 0), point(1.2*(i + 1)*gs + Center.x, 0, 0), _RGB(255, 0, 0)), n++;
		sgs[n] = segment(point(0, 1.2*i*gs + Center.y, 0), point(0, 1.2*(i + 1)*gs + Center.y, 0), _RGB(0, 128, 0)), n++;
		sgs[n] = segment(point(0, 0, 0.8*i*gs + Center.z), point(0, 0, 0.8*(i + 1)*gs + Center.z), _RGB(0, 0, 255)), n++;
	}


	sort_segments(sgs, L);
	if (cos(rx) > 0) for (int i = 0; i < L; i++) {
		point2D E1 = fromCoordinate(sgs[i].A), E2 = fromCoordinate(sgs[i].B);
		if (!isnan(E1.x*E1.y*E2.x*E2.y)) drawLine(E1.x, E1.y, E2.x, E2.y, sgs[i].col);
	}
	else for (int i = L - 1; i >= 0; i--) {
		point2D E1 = fromCoordinate(sgs[i].A), E2 = fromCoordinate(sgs[i].B);
		if (!isnan(E1.x*E1.y*E2.x*E2.y)) drawLine(E1.x, E1.y, E2.x, E2.y, sgs[i].col);
	}
	delete[] sgs;


	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);
}



LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = clt_w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)clt_h : clt_h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};
	switch (message) {
	case WM_CREATE: {
		GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		InitializeClientBitmap(hWnd, HImg, img, false);
		HWnd = hWnd;
		break;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		Unit *= sqrt((clt_w * clt_h) / (prev_w * prev_h));
		DeleteObject(HImg);
		InitializeClientBitmap(hWnd, HImg, img, false);
		graph();
		break;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 600;
		lpMMI->ptMinTrackSize.y = 400;	// set minimum window size
		break;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HDwgMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HDwgMem, HImg);
		BitBlt(hdc, 0, 0, Client.right, Client.bottom, HDwgMem, 0, 0, SRCCOPY);
		SelectObject(HDwgMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HDwgMem);
		DeleteDC(hdc);
		break;
	}
	case WM_MOUSEMOVE: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		if (mouse_down) {	// click and drag
			double dx = Cursor.x - OrigCursor.x, dy = OrigCursor.y - Cursor.y;
			dx /= 100, dy /= 120;
			rx = orig_rx, rz = orig_rz;
			rx += dy, rz += dx;
			graph();
		}
		break;
	}
	case WM_LBUTTONDOWN: {
		mouse_down = true;
		OrigCursor.x = GET_X_LPARAM(lParam);
		OrigCursor.y = clt_h - GET_Y_LPARAM(lParam);
		orig_rx = rx, orig_rz = rz;
		break;
	}
	case WM_LBUTTONUP: {
		mouse_down = false;
		fix_ang(rx), fix_ang(rz);
		OrigCursor = point2D(NAN, NAN);
		break;
	}
	case WM_MOUSEWHEEL: {
		if (mouse_down) break;
		int delta = GET_WHEEL_DELTA_WPARAM(wParam);
		const double MAX = 1e+6, MIN = 1e-8;
		double d = exp(0.0005 * delta);
		if (Unit * d > MAX) d = MAX / Unit;
		else if (Unit * d < MIN) d = MIN / Unit;
		Unit *= d, gs /= d;
		point S = fromCanvas(Cursor);
		if (abs(S.x - Center.x) < Ng*gs && abs(S.y - Center.y) < Ng*gs) Center -= S, Center /= d, Center += S;
		graph();
		break;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
	default: {
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	}
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
	const wchar_t CLASS_NAME[] = _T("Wireframes");
	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(16, 20, 23));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = CLASS_NAME;
	if (!RegisterClassEx(&wc)) return -1;

	HWND hWnd = CreateWindowEx(
		0,
		CLASS_NAME,
		CLASS_NAME,
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		900, 600,
		NULL, NULL, hInstance, NULL
	);
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	return (int)message.wParam;
}
