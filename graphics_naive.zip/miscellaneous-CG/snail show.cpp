#ifndef UNICODE
#define UNICODE
#endif

#pragma warning(disable:4244 4018 4010 4305)
//#pragma optimize("",off)

#include <Windows.h>
#include <windowsx.h>
#include <tchar.h>

#include "3D.h"
#include <thread>


using namespace std;

#include <chrono>
typedef chrono::high_resolution_clock NTime;
typedef std::chrono::duration<double> fsec;

#define APPLICATION_NAME " Snail Show"


#ifdef _DEBUG
#define Fill_N(First,Count,Val) for (unsigned i = 0, l = clt_w * clt_h; i < l; i++) First[i] = Val;
#include <cstdlib>
#include <crtdbg.h>
#define CheckMemoryLeaks _CrtDumpMemoryLeaks();
#define BreakOn(t) _CrtSetBreakAlloc(t);
#else
#include <memory>
#define Fill_N(First,Count,Val) uninitialized_fill_n(First, Count, Val)
#define CheckMemoryLeaks { }
#define BreakOn(t) { }
#endif




HWND HWnd;
RECT Client; int clt_w, clt_h, img_w, img_h;
COLORREF *img, *Img; HBITMAP HImg;
double* ZB = 0;

#define AA 2



vec2 Cursor(NAN, NAN), OrigCursor(Cursor); bool mouse_down;



#include <vector>
vector<polygon*> comps;


void render();
void ConstructBox(vec3 Pos, COLORf col) {
	vec3 _000(0, 0, 0), _001(0, 0, 1), _010(0, 1, 0), _011(0, 1, 1), _100(1, 0, 0), _101(1, 0, 1), _110(1, 1, 0), _111(1, 1, 1);
	Pos -= vec2(0.5, 0.5);
	_000 += Pos, _001 += Pos, _010 += Pos, _011 += Pos, _100 += Pos, _101 += Pos, _110 += Pos, _111 += Pos;
	const int N = 10;
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			double u = i / double(N), v = j / double(N), _u = (i + 1) / double(N), _v = (j + 1) / double(N);
			comps.push_back(new quad((1 - u - v)*_000 + u * _001 + v * _010, (1 - _u - v)*_000 + _u * _001 + v * _010, (1 - _u - _v)*_000 + _u * _001 + _v * _010, (1 - u - _v)*_000 + u * _001 + _v * _010, col));	// L
			comps.push_back(new quad((1 - u - v)*_100 + u * _110 + v * _101, (1 - _u - v)*_100 + _u * _110 + v * _101, (1 - _u - _v)*_100 + _u * _110 + _v * _101, (1 - u - _v)*_100 + u * _110 + _v * _101, col));	// R
			comps.push_back(new quad((1 - u - v)*_000 + u * _100 + v * _001, (1 - _u - v)*_000 + _u * _100 + v * _001, (1 - _u - _v)*_000 + _u * _100 + _v * _001, (1 - u - _v)*_000 + u * _100 + _v * _001, col));	// F
			comps.push_back(new quad((1 - u - v)*_010 + u * _011 + v * _110, (1 - _u - v)*_010 + _u * _011 + v * _110, (1 - _u - _v)*_010 + _u * _011 + _v * _110, (1 - u - _v)*_010 + u * _011 + _v * _110, col));	// B
			comps.push_back(new quad((1 - u - v)*_000 + u * _010 + v * _100, (1 - _u - v)*_000 + _u * _010 + v * _100, (1 - _u - _v)*_000 + _u * _010 + _v * _100, (1 - u - _v)*_000 + u * _010 + _v * _100, col));	// B
			comps.push_back(new quad((1 - u - v)*_001 + u * _101 + v * _011, (1 - _u - v)*_001 + _u * _101 + v * _011, (1 - _u - _v)*_001 + _u * _101 + _v * _011, (1 - u - _v)*_001 + u * _101 + _v * _011, col));	// T
		}
	}
}
void ConstructSnail(double a, double b, double c, double n, vec3 Pos, double theta) {
	unsigned sz = comps.size();
	const COLORf col = RGBf(1, 0.9, 0.8);
#define X(u,v) a*(1-v)*(cos(u)+c)*cos(2*PI*n*v)
#define Y(u,v) a*(1-v)*(cos(u)+c)*sin(2*PI*n*v)
#define Z(u,v) a*((1-v)*sin(u)+b*v)
#define Normal(u,v) cross(vec3(a*(cos(u)+c)*((2*PI*n*v-2*PI*n)*sin(2*PI*n*v)-cos(2*PI*n*v)), -a*(cos(u)+c)*(sin(2*PI*n*v)+(2*PI*n*v-2*PI*n)*cos(2*PI*n*v)), a*(b-sin(u))), \
		vec3(a*(v-1)*cos(2*PI*n*v)*sin(u), a*(v-1)*sin(2*PI*n*v)*sin(u), a*(1-v)*cos(u)))
	/* Equation of this snail:
		 x = a (1-v) (cos u + c) cos(2π n v)
		 y = a (1-v) (cos u + c) sin(2π n v)
		 z = a ((1-v) (sin u) + b v)
	   where  0 < u < 2π  and  0 < v < 1
	 a controls the size of the snail
	 b controls the offset of main axis (height/sharpness)
	 c controls the spreading of the snail, greater than 1
	 n indicates the number of screws
	 a,b,c are generally positive. a negative n generates a left-handed snail.
	 Since the opening of the snail is a circle, this equation more generally represent freshwater or land snails.
	 An online demo: https://www.math3d.org/Y5ItkiIO
	*/
	const int u_dif = 50, v_dif = 50 * n;
	double u, v, u_, v_;
	vec3 p, px, py, pxy;
	vec3 N, Nx, Ny, Nxy;
	for (int i = 0; i < u_dif; i++) {
		for (int j = 0; j < v_dif; j++) {
			u = double(i) / u_dif * 2 * PI, v = double(j) / v_dif, u_ = double(i + 1) / u_dif * 2 * PI, v_ = double(j + 1) / v_dif;
			p = vec3(X(u, v), Y(u, v), Z(u, v)), px = vec3(X(u_, v), Y(u_, v), Z(u_, v)), py = vec3(X(u, v_), Y(u, v_), Z(u, v_)), pxy = vec3(X(u_, v_), Y(u_, v_), Z(u_, v_));
			N = Normal(u, v), Nx = Normal(u_, v), Ny = Normal(u, v_), Nxy = Normal(u_, v_);
			comps.push_back(new triangle(p, py, px, N, Ny, Nx, col)), comps.push_back(new triangle(py, pxy, px, Ny, Nxy, Nx, col));
		}
	}

	auto BalanceSnail = [](int beg, int end) {	// DEBUGGING
		// This function only give a balanced status, the result may be different from that the snail falls freely
		//for (int i = 0; i < 7; i++) comps.push_back(new quad);

		/* find the center of mass and initial supporting point */
		triangle* t;
		double mass = 0, m; vec3 Sp(0, 0, INFINITY), COM(0, 0, 0);		// supporting point and center of mass
		for (int i = beg; i < end; i++) {
			t = (triangle*)(comps[i]);
			m = 0.5*cross(t->B - t->A, t->C - t->A).mod();
			mass += m, COM += m * (t->A + t->B + t->C) / 3;
			if (t->A.z < Sp.z) Sp = t->A; if (t->B.z < Sp.z) Sp = t->B; if (t->C.z < Sp.z) Sp = t->C;
		}
		COM /= mass;
		vec3 T(0, 0, -Sp.z);
		for (int i = beg; i < end; i++) *comps[i] += T; COM += T;


		/* numerically find a balanced status */
		vec3 Sp1 = Sp, Sp2, Sp3, Sp1n, Sp2n, Sp3n; int nSp = 1;
		vec3 L;
		double EPSILON = 0.01, ETA = 0.1, DIF = 0.02;
		bool rd2 = -1, _rd2 = -1;
		int i; for (i = 0;; i++) {
			//comps.at(comps.size() - 1) = new quad(Sp1 - vec3(0, 0, 0.01), vec3(0.03, 0.03, 0.3), vec3(-0.03, -0.03, 0.3), RGBf(1, 0, 0)); \
				comps.at(comps.size() - 2) = new quad(Sp2 - vec3(0, 0, 0.01), vec3(0.03, 0.03, 0.3), vec3(-0.03, -0.03, 0.3), RGBf(0, 0.6, 0)); \
				comps.at(comps.size() - 3) = new quad(Sp3 - vec3(0, 0, 0.01), vec3(0.03, 0.03, 0.3), vec3(-0.03, -0.03, 0.3), RGBf(0, 0, 1)); \
				comps.at(comps.size() - 4) = new quad(Sp1n - vec3(0, 0, 0.01), vec3(-0.03, 0.03, 0.25), vec3(0.03, -0.03, 0.25), RGBf(1, 0, 0)); \
				comps.at(comps.size() - 5) = new quad(Sp2n - vec3(0, 0, 0.01), vec3(-0.03, 0.03, 0.25), vec3(0.03, -0.03, 0.25), RGBf(0, 0.6, 0)); \
				comps.at(comps.size() - 6) = new quad(Sp3n - vec3(0, 0, 0.01), vec3(-0.03, 0.03, 0.25), vec3(0.03, -0.03, 0.25), RGBf(0, 0, 1)); \
				comps.at(comps.size() - 7) = new triangle(COM - vec3(0, 0, 0.01), COM + vec3(-0.05, 0, 0.5), COM + vec3(0.05, 0, 0.5), RGBf(1, 1, 0));

			//render(); //Sleep(200);
			if (i > 1000) break;
			if (nSp == -1) break;
			if (isnan(Sp1)) { Dout("NaN"); break; }

			switch (nSp) {	// number of supporting points
			case 1: {	// one supporting point Sp1
				//Sleep(10);
				L = (COM - Sp1).unitvec(); if (L.xy().mod() < EPSILON) { nSp = -1; break; };
				mat3 M; M.rotate(cross(L, vec3(0, 0, 1)), -DIF);
				for (int i = beg; i < end; i++) comps[i]->applyMatrix(M); COM = M * COM, Sp1 = M * Sp1;
				Sp = vec3(0, 0, INFINITY); for (int i = beg; i < end; i++) {
					t = (triangle*)(comps[i]);
					if (t->A.z < Sp.z) Sp = t->A; if (t->B.z < Sp.z) Sp = t->B; if (t->C.z < Sp.z) Sp = t->C;
				}
				if ((Sp - Sp1).mod() > ETA && dot((COM - Sp).xy(), (Sp1 - Sp).xy()) > 0) {	// number of supporting points increase
					affine3 M;
					M.rotate(cross(Sp1 - Sp, vec3(0, 0, 1)), asin((Sp - Sp1).unitvec().z));
					M.translate(0, 0, -(M*Sp).z);
					for (int i = beg; i < end; i++) comps[i]->applyMatrix(M);
					COM = M * COM, Sp1 = M * Sp1, Sp2 = M * Sp;
					nSp = 2;
				}
				else {	// origin supporting point moved
					vec3 T(0, 0, -Sp.z);
					for (int i = beg; i < end; i++) *comps[i] += T;
					COM += T, Sp1 = Sp + T;
				}
				break;
				// Note that sometimes an object balances with only one supporting point.  ex. an ellipsoid
			}
			case 2: {	// two supporting points Sp1 and Sp2
				//Sleep(500);
				Sp = (Sp2 - Sp1).unitvec(); L = (COM - dot(COM - Sp1, Sp) * Sp).unitvec();
				if (L.xy().mod() < EPSILON) { nSp = -1; break; }
				bool rd = det(Sp.xy(), (COM - Sp1).xy()) > 0; if (rd == _rd2 && rd != rd2) DIF *= 0.8;
				if (DIF < EPSILON) { nSp = -1; break; }
				_rd2 = rd2, rd2 = rd;
				mat3 M; M.rotate(Sp, rd ? -DIF : DIF);
				for (int i = beg; i < end; i++) comps[i]->applyMatrix(M); COM = M * COM, Sp1 = M * Sp1, Sp2 = M * Sp2;
				Sp1n = Sp2n = Sp = vec3(0, 0, INFINITY);
				double est = 0.5 * (Sp1.xy() - Sp2.xy()).mod();
				for (int i = beg; i < end; i++) {
					t = (triangle*)(comps[i]);
					if (t->A.z < Sp1n.z && (t->A.xy() - Sp1.xy()).mod() < est) Sp1n = t->A; if (t->B.z < Sp1n.z && (t->B.xy() - Sp1.xy()).mod() < est) Sp1n = t->B; if (t->C.z < Sp1n.z && (t->C.xy() - Sp1.xy()).mod() < est) Sp1n = t->C;
					if (t->A.z < Sp2n.z && (t->A.xy() - Sp2.xy()).mod() < est) Sp2n = t->A; if (t->B.z < Sp2n.z && (t->B.xy() - Sp2.xy()).mod() < est) Sp2n = t->B; if (t->C.z < Sp2n.z && (t->C.xy() - Sp2.xy()).mod() < est) Sp2n = t->C;
					if (t->A.z < Sp.z) Sp = t->A; if (t->B.z < Sp.z) Sp = t->B; if (t->C.z < Sp.z) Sp = t->C;
				}
				if (isnan(Sp1n - Sp2n)) Sp1n = Sp1, Sp2n = Sp2;		// bug
				if ((Sp - Sp1).mod() > est && (Sp - Sp2).mod() > est) {		// number of supporting points increase
					if (!(((det(Sp.xy() - COM.xy(), Sp1n.xy() - COM.xy()) >= 0) + (det(Sp1n.xy() - COM.xy(), Sp2n.xy() - COM.xy()) >= 0)
						+ (det(Sp2n.xy() - COM.xy(), Sp.xy() - COM.xy()) >= 0)) % 3)) { 	// center of mass inside the triangle formed by 3 supporting points
						Sp1 = Sp1n, Sp2 = Sp2n, Sp3 = Sp;
						vec3 cn(cross(Sp2 - Sp1, Sp3 - Sp1).unitvec()); if (cn.z < 0) cn = -cn;
						affine3 M; M.rotate(cross(cn, vec3(0, 0, 1)), acos(cn.z)); M.translate(0, 0, -(M*Sp1).z);
						for (int i = beg; i < end; i++) comps[i]->applyMatrix(M);
						COM = M * COM, Sp1 = M * Sp1, Sp2 = M * Sp2, Sp3 = M * Sp3;
						nSp = 3;
					}
					else {
						// not present in this demo
						Sp1 = Sp1n, Sp2 = Sp2n;
					}
				}
				/*else if (dot(COM.xy() - Sp1n.xy(), Sp2n.xy() - Sp1n.xy()) < 0) {
					vec3 v(Sp1n - Sp1); for (int i = beg; i < end; i++) *comps[i] += v;
					Sp1 = Sp1n, nSp = 1; break;
				}
				else if (dot(COM.xy() - Sp2n.xy(), Sp2n.xy() - Sp1n.xy()) > 0) {
					vec3 v(Sp2n - Sp2); for (int i = beg; i < end; i++) *comps[i] += v;
					Sp1 = Sp2n, nSp = 1; break;
				}*/
				else {
					Sp1 = Sp1n, Sp2 = Sp2n, Sp = Sp2 - Sp1;

					affine3 M;
					M.translate(-Sp1); M.rotate(cross(Sp, vec3(0, 0, 1)), -asin(Sp.unitvec().z)); M.translate(Sp1);
					M.translate(0, 0, -(M*Sp2).z);
					for (int i = beg; i < end; i++) comps[i]->applyMatrix(M);
					COM = M * COM, Sp1 = M * Sp1, Sp2 = M * Sp2;
				}
				break;
			}

			default: break;
			}
		}
		Dout("Object " << beg << "-" << (end - 1) << " balanced with iteration " << i);
	};

	auto TranslateSnail = [](int beg, int end, vec3 Pos, double theta) {
		affine3 M;
		//const double PI_2 = -PI / 2; double da = 0.7, das = 0.5 / n + da / (2 * PI * n); vec3 base(X(PI_2, 0), Y(PI_2, 0), Z(PI_2, 0)), buttom(X(PI_2, das), Y(PI_2, das), Z(PI_2, das));
		//vec3 dr = (buttom - base).unitvec(); double ang = asin(dr.z);
		//M.rotate_z(-da); M.rotate_y(-ang); M.rotate_z(da);	// I tried to solve the balance of this snail but failed
		//M.translate(-0.4*(X(0, 0) + X(0, 0.5 / n)), -0.45*(Y(0, 0.25 / n) + Y(0, 0.75 / n)), a + 1.005 - ((M*base).z - base.z));
		vec3 maxp(-INFINITY, -INFINITY, -INFINITY), minp(INFINITY, INFINITY, INFINITY);
		triangle* t; for (int i = beg; i < end; i++) {
			t = (triangle*)(comps[i]);
			if (t->A.x < minp.x) minp.x = t->A.x; if (t->B.x < minp.x) minp.x = t->B.x; if (t->C.x < minp.x) minp.x = t->C.x;
			if (t->A.x > maxp.x) maxp.x = t->A.x; if (t->B.x > maxp.x) maxp.x = t->B.x; if (t->C.x > maxp.x) maxp.x = t->C.x;
			if (t->A.y < minp.y) minp.y = t->A.y; if (t->B.y < minp.y) minp.y = t->B.y; if (t->C.y < minp.y) minp.y = t->C.y;
			if (t->A.y > maxp.y) maxp.y = t->A.y; if (t->B.y > maxp.y) maxp.y = t->B.y; if (t->C.y > maxp.y) maxp.y = t->C.y;
			if (t->A.z < minp.z) minp.z = t->A.z; if (t->B.z < minp.z) minp.z = t->B.z; if (t->C.z < minp.z) minp.z = t->C.z;
			if (t->A.z > maxp.z) maxp.z = t->A.z; if (t->B.z > maxp.z) maxp.z = t->B.z; if (t->C.z > maxp.z) maxp.z = t->C.z;
		}
		M.translate(-0.5*(maxp.x + minp.x), -0.5*(maxp.y + minp.y), -minp.z);
		M.rotate_z(theta);
		M.translate(Pos);
		for (int i = beg; i < end; i++) comps[i]->applyMatrix(M);

	};

	BalanceSnail(sz, comps.size()); TranslateSnail(sz, comps.size(), Pos, theta);
	//thread T([&](int beg, int end) { Sleep(100); BalanceSnail(beg, end); }, sz, comps.size()); T.detach();

#undef X
#undef Y
#undef Z
#undef Normal
	Dout("Snail #(" << a << "," << b << "," << c << "," << n << ") constructed");
}
void model() {
	if (!comps.empty()) {
		for (int i = 0; i < comps.size(); i++) if (comps[i] != 0) delete comps[i];
		comps.clear();
	}

	//comps.push_back(new quad(vec3(3, -4, -1), vec3(3, 4, -1), vec3(-5, 4, -1), vec3(-5, -4, -1), RGBf(1, 0.9, 0.8)));
	const int N = 20;
	vec3 O(3, -4, -1), A(3, 4, -1), B(-5, -4, -1);
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			double u = i / double(N), v = j / double(N), _u = (i + 1) / double(N), _v = (j + 1) / double(N);
			//comps.push_back(new quad((1 - u - v)*O + u * A + v * B, (1 - _u - v)*O + _u * A + v * B, (1 - _u - _v)*O + _u * A + _v * B, (1 - u - _v)*O + u * A + _v * B, RGBf(1, 0.9, 0.8)));
			comps.push_back(new triangle((1 - u - v)*O + u * A + v * B, (1 - _u - v)*O + _u * A + v * B, (1 - _u - _v)*O + _u * A + _v * B, RGBf(1, 0.9, 0.8)));
			comps.push_back(new triangle((1 - u - v)*O + u * A + v * B, (1 - u - _v)*O + u * A + _v * B, (1 - _u - _v)*O + _u * A + _v * B, RGBf(1, 0.9, 0.8)));
		}
	}


	// Cube
	{
		ConstructBox(vec3(1, -2, -1), RGBf(1, 0.9, 0.8));
		ConstructBox(vec3(1, 0, -1), RGBf(1, 0.9, 0.8));
		ConstructBox(vec3(1, 2, -1), RGBf(1, 0.9, 0.8));
		ConstructBox(vec3(-1, 0, -1), RGBf(1, 0.9, 0.8));
		ConstructBox(vec3(-3, 0, -1), RGBf(1, 0.9, 0.8));
	}

	// Snail
	{
		ConstructSnail(0.18, 1.2, 1, 3, vec3(1, -2, 0), PI / 2);	// land snail
		ConstructSnail(0.18, 2.2, 1, 4.5, vec3(1, 0, 0), PI / 2);	// river snail, I don't know why it looks like shit
		ConstructSnail(0.22, 1.1, 0.5, 2, vec3(1, 2, 0), PI / 2);	// giant river snail
		ConstructSnail(0.2, 1.8, 0.2, 2.4, vec3(-1, 0, 0), PI / 2);	// land cone snail
		ConstructSnail(0.2, 3.5, 0.2, 8, vec3(-3, 0, 0), PI / 2);	// cone snail
	}
}
void destruct() {
	if (!comps.empty()) {
		for (int i = 0; i < comps.size(); i++) if (comps[i] != 0) delete comps[i];
		comps.clear();
	}
	DeleteObject(HImg);
	delete Img;
	if (ZB != 0) delete ZB, ZB = 0;
}






const vec3 light = vec3(0.6, 0.5, 1).unitvec();
const COLORf bkg_col = RGBf(0.05, 0.1, 0.15);
bool rendering = false;

bool Ctrl = false, Shift = false, Alt = false;


vec3 Pos, prev_Pos;
double rx, rz, prev_rx, prev_rz;
double Unit, img_Unit;


affine3 fromWorld, fromScreen;
void recalcMatrix() {
	fromWorld.init();
	fromWorld.translate(-Pos);
	fromWorld.rotate_z(-rz); fromWorld.rotate_x(PI - rx); fromWorld.rotate_z(PI);
	fromWorld.translate(0, 0, 1);
	fromWorld.perspective(-1);
	fromWorld.scale(img_Unit);
	fromWorld.translate(img_w / 2, img_h / 2);
	fromScreen = fromWorld.invert();
}

void initView() {
	Pos = prev_Pos = vec3(7.4, 3.6, 2.4);
	rx = prev_rx = 2, rz = prev_rz = -1.1;
	Unit = 700;
	recalcMatrix();
}





void render() {
	// https://www.math3d.org/h2nq9VQq
	if (rendering) return; rendering = true;

	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);
	Fill_N(Img, img_w * img_h, _RGB(0, 0, 0));

	if (ZB == 0) ZB = new double[img_w*img_h];
	Fill_N(ZB, img_w*img_h, -INFINITY);

	recalcMatrix();
	affine3 M(fromWorld);

	auto calc_col = [](const COLORf &Col, vec3 n, vec3 v) -> COLORf {
		const double Kd = 0.4, Ks = 1 - Kd, N = 5;
		n /= n.mod(), v /= v.mod();
		if (dot(n, v) > 0) n = -n;
		double a = dot(light, n);
		double amb = 0.5 - 0.5*n.x;
		double dif = Kd * max(a, 0.0);
		double spc = Ks * pow(max(-dot(2 * a*n - light, v), 0.0), N);
		return amb * bkg_col + (dif + spc) * Col;
	};


	double min_z = -img_Unit, max_z = 100 * img_Unit;
	vec3 MA, MB, MC, MD;
	for (int i = 0; i < comps.size(); i++) {
		if (comps[i]->type() == PLG_TRIANGLE) {
			triangle* t = (triangle*)comps[i];
			MA = M * t->A, MB = M * t->B, MC = M * t->C;
			if (-MA.z < img_Unit && -MB.z < img_Unit && -MC.z < img_Unit) triangle(MA, MB, MC).GouraudShadeInZBuffer(
				Img, img_w, img_h, ZB, { calc_col(t->col, t->nA(), t->A - Pos), calc_col(t->col, t->nB(), t->B - Pos), calc_col(t->col, t->nC(), t->C - Pos) }, min_z, max_z);
		}
		else if (comps[i]->type() == PLG_QUAD) {
			quad* t = (quad*)comps[i];
			MA = M * t->A, MB = M * t->B, MC = M * t->C, MD = M * t->D;
			if (-MA.z < img_Unit && -MB.z < img_Unit && -MC.z < img_Unit && -MD.z < img_Unit) quad(MA, MB, MC, MD).GouraudShadeInZBuffer(
				Img, img_w, img_h, ZB, { calc_col(t->col, t->nA(), t->A - Pos), calc_col(t->col, t->nB(), t->B - Pos), calc_col(t->col, t->nC(), t->C - Pos), calc_col(t->col, t->nD(), t->D - Pos) }, min_z, max_z);
		}
	}


	COLORf col;
	for (int j = 0; j < clt_h; j++) for (int i = 0; i < clt_w; i++) {
		col.r = col.g = col.b = 0;
		for (int u = 0; u < AA; u++) for (int v = 0; v < AA; v++) {
			col += toCOLORf(Img[(AA*j + u)*img_w + (AA*i + v)]);
		}
		col /= AA * AA;
		img[j*clt_w + i] = toCOLORREF(col);
	}




	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);

	rendering = false;
}


HANDLE RenderingThread;
DWORD WINAPI fpsTest(HANDLE H) {

	auto uint2str = [](unsigned n)->string {
		string r;
		while (n) r = char('0' + n % 10) + r, n /= 10;
		return r;
	};
	auto fps2str = [](double a)->string {
		if (a <= 0 || a > 2000 || isNaN(a)) return "###";
		int e = 3;
		while (a < 100) a *= 10, e--;
		string r;
		while (a != 0) r = char('0' + int(a) % 10) + r, a = int(a) / 10;
		while (e <= 0) r = '0' + r, e++;
		if (e < 3) r.insert(r.begin() + e, '.');
		return r;
	};

	while (1) {
		Sleep(1000);
		auto t0 = NTime::now();
		render();
		auto t1 = NTime::now();
		fsec fs = t1 - t0;
		SetWindowTextA(HWnd, &(string(APPLICATION_NAME) + " (" + uint2str(comps.size()) + ")      " + uint2str(img_w) + "x" + uint2str(img_h) + "      " + (fps2str(1 / fs.count()) + "fps"))[0]);
	}


	return 0;
}




vec3 Intersect; double Intersect_dist;

bool IntersectionTest(vec3 P, vec3 v, vec3 *I, double *t) {
	vec3 _I; double _t = INFINITY;
	vec3 Int; double dist;
	for (int i = 0; i < comps.size(); i++) {
		if (comps[i]->IntersectionTest(P, v, Int, dist) && dist < _t) _t = dist, _I = Int;
	}
	if (!isNaN(_t)) {
		if (I) *I = _I; if (t) *t = _t;
		return true;
	}
	return false;
}











#include <chrono>

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = clt_w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)clt_h : clt_h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};
	//if (fromScreen.isnan()) initView();

	double scr_w = clt_w / Unit, scr_h = clt_h / Unit;
	vec3 _O(0.5*scr_w, -0.5*scr_h, 1), _A(-scr_w, 0, 0), _B(0, scr_h, 0);
	mat3 M; M.rotate_zx(rz, rx); vec3 O = M * _O + prev_Pos, A = M * _A, B = M * _B;
	mat3 prev_M; prev_M.rotate_zx(prev_rz, prev_rx); vec3 prev_O = prev_M * _O + prev_Pos, prev_A = prev_M * _A, prev_B = prev_M * _B;
	vec3 V = M * vec3(0, 0, 1), prev_V = prev_M * vec3(0, 0, 1);
	recalcMatrix();

	switch (message) {
	case WM_CREATE: {
		GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		img_w = AA * clt_w, img_h = AA * clt_h;
		HWnd = hWnd;
		model();
		initView();
		RenderingThread = CreateThread(NULL, NULL, &fpsTest, NULL, NULL, NULL);
		break;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		img_w = AA * clt_w, img_h = AA * clt_h;
		while (rendering) Sleep(1); rendering = true;
		if (ZB != 0) delete ZB, ZB = new double[img_w*img_h];
		delete Img; Img = new COLORREF[img_w*img_h];
		Unit *= sqrt((clt_w * clt_h) / (prev_w * prev_h));
		img_Unit = AA * Unit;
		DeleteObject(HImg);
		InitializeClientBitmap(hWnd, HImg, img, false);
		rendering = false;
		render();

		// Test the speed of different rendering methods
		auto Test = [](unsigned N) {
			typedef chrono::high_resolution_clock NTime;
			typedef std::chrono::duration<double> fsec;
			auto t0 = NTime::now();
			for (int i = 0; i < N; i++) render();
			auto t1 = NTime::now();
			fsec fs = t1 - t0;
			dout("\n" << (N / fs.count()) << "fps\n\n");
		};
		//Test(50); exit(0);

		break;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 600, lpMMI->ptMinTrackSize.y = 400;
		break;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HMem, HImg);
		BitBlt(hdc, 0, 0, Client.right, Client.bottom, HMem, 0, 0, SRCCOPY);
		SelectObject(HMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HMem);
		DeleteDC(hdc);
		break;
	}
	case WM_MOUSEMOVE: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		if (mouse_down) {	// doesn't work fine
			double u = Cursor.x / double(clt_w), v = Cursor.y / double(clt_h);
			double _u = OrigCursor.x / double(clt_w), _v = OrigCursor.y / double(clt_h);
			vec3 dr = O + u * A + v * B, _dr = O + _u * A + _v * B, prev_dr = prev_O + _u * prev_A + _v * prev_B;
			if (Shift) {
				double dx = -(Cursor.x - OrigCursor.x) / (0.5 * Unit), dy = -(Cursor.y - OrigCursor.y) / (0.5 * Unit);
				mat3 R(RotationMatrix_xz(dy, dx)); R = RotationMatrix_zx(dx, dy);
				Pos = R * (prev_Pos - Intersect) + Intersect;
				vec3 s = (R * ((prev_O + 0.5 * (prev_A + prev_B)) - Intersect) + Intersect - Pos).unitvec();
				rz = atan2(s.x, -s.y), rx = atan2(hypot(s.x, s.y), s.z);
			}
			else if (Ctrl) {
				vec3 _a = (_dr - Pos).unitvec(), a = (dr - Pos).unitvec();
				mat3 R; R.rotate(cross(a, _a), acos(dot(a, _a))); R = R * RotationMatrix_zx(prev_rz, prev_rx);
				rz = atan2(R[0][2], -R[1][2]), rx = atan2(hypot(R[0][2], R[1][2]), R[2][2]);
				if (isNaN(rx) || isNaN(rz)) rx = prev_rx, rz = prev_rz;
			}
			else {	// click and drag
				dr -= prev_Pos, _dr -= prev_Pos;
				dr /= dr.mod() / Intersect_dist, _dr /= _dr.mod() / Intersect_dist;
				Pos = prev_Pos + _dr - dr;
			}
			render();
		}
		else prev_Pos = Pos;
		break;
	}
	case WM_MOUSEWHEEL: {
		int delta = GET_WHEEL_DELTA_WPARAM(wParam);
		mouse_down = false;
		IntersectionTest(Pos, O + 0.5*(A + B) - Pos, NULL, &Intersect_dist);
		Pos += (0.001*delta) * (Intersect_dist + 0.1) *V;
		prev_Pos = Pos;
		render();
		break;
	}
	case WM_SYSKEYDOWN:;
	case WM_KEYDOWN: {
		if (!mouse_down) switch (wParam) {
		case VK_CONTROL: { Ctrl = true; break; }
		case VK_SHIFT: { Shift = true; break; }
		case VK_MENU: { Alt = true; break; }
		}
		break;
	}
	case WM_KEYUP: {
		if (!mouse_down) switch (wParam) {
		case VK_CONTROL: { Ctrl = false; break; }
		case VK_SHIFT: { Shift = false; break; }
		case VK_MENU: { Alt = false; break; }
		}
		break;
	}
	case WM_LBUTTONDOWN: {
		OrigCursor.x = GET_X_LPARAM(lParam);
		OrigCursor.y = clt_h - GET_Y_LPARAM(lParam);
		vec3 P = fromScreen * vec3(OrigCursor.x, OrigCursor.y);
		double t; if (IntersectionTest(P, (P - Pos).unitvec(), &Intersect, &t)) Intersect_dist = t + (P - Pos).mod();
		prev_rx = rx, prev_rz = rz;
		mouse_down = true;
		break;
	}
	case WM_LBUTTONUP: {
		mouse_down = false;
		Ctrl = Shift = Alt = false;
		OrigCursor = vec2(NAN, NAN);
		break;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		while (rendering) Sleep(1);
		TerminateThread(RenderingThread, 0);
		destruct();
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {

	//BreakOn(5008);

	const wchar_t CLASS_NAME[] = _T(APPLICATION_NAME);
	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = CLASS_NAME;
	if (!RegisterClassEx(&wc)) return -1;

	HWND hWnd = CreateWindowEx(
		0,
		CLASS_NAME,
		CLASS_NAME,
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		900, 600,
		NULL, NULL, hInstance, NULL
	);
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	CheckMemoryLeaks;
	return (int)message.wParam;
}


