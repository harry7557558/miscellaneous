#ifndef UNICODE
#define UNICODE
#endif

#pragma warning(disable:4244 4018 4010)


#include <Windows.h>
#include <windowsx.h>
#include <tchar.h>
#include <cmath>
#include <algorithm>
using namespace std;

#define PI 3.1415926535897932384626433832795029

#define _RGB(r,g,b) ((COLORREF)(((BYTE)(b)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(r))<<16)))
COLORREF mix(COLORREF a, COLORREF b, double r) { return _RGB((1 - r)*((BYTE*)&a)[2] + r * ((BYTE*)&b)[2], (1 - r)*((BYTE*)&a)[1] + r * ((BYTE*)&b)[1], (1 - r)*(BYTE)a + r * (BYTE)b); }
typedef struct { double r, g, b; } COLORf;
#define toCOLORREF(col) _RGB(255*max(min(col.r,1),0),255*max(min(col.g,1),0),255*max(min(col.b,1),0))
COLORf RGBf(const double &r, const double &g, const double &b) { COLORf c; c.r = r, c.g = g, c.b = b; return c; }
COLORf RGBf(const double &g) { COLORf c; c.r = c.g = c.b = g; return c; }
COLORf operator + (const COLORf &a, const COLORf &b) { return RGBf(a.r + b.r, a.g + b.g, a.b + b.b); }
void operator += (COLORf &a, const COLORf &b) { a.r += b.r, a.g += b.g, a.b += b.b; }
void operator -= (COLORf &a, const COLORf &b) { a.r -= b.r, a.g -= b.g, a.b -= b.b; }
COLORf operator * (const double &a, const COLORf &b) { return RGBf(a*b.r, a*b.g, a*b.b); }


// linear congruence producing random float value
extern double RAND_LCG_SEED = 0.36787944117;	// seed
#define RAND_LCG_TMS 1335.7170284377952		// problems may occur if this is too small
#define RAND_LCG_ADD 85.147098480789738
inline double pick_random(double max) {
	RAND_LCG_SEED = fmod(RAND_LCG_SEED * RAND_LCG_TMS + RAND_LCG_ADD, max);
	return RAND_LCG_SEED;
}
inline double pick_random(double min, double max) {
	RAND_LCG_SEED = fmod(RAND_LCG_SEED * RAND_LCG_TMS + RAND_LCG_ADD, max - min);
	return RAND_LCG_SEED + min;
}


#ifdef _DEBUG
#define fill_n(First,Count,Val) for (unsigned i = 0, l = clt_w * clt_h; i < l; i++) First[i] = Val;
#include <iostream>
#include <sstream>
#define DBGLOG(s) { std::wostringstream os_; os_ << s; OutputDebugStringW( os_.str().c_str() ); }	// log to Visual Studio output window
#include <cstdlib>
#include <crtdbg.h>
#define CheckMemoryLeaks _CrtDumpMemoryLeaks();
#define BreakOn(t) _CrtSetBreakAlloc(t);
#else
#include <memory>
#define fill_n(First,Count,Val) uninitialized_fill_n(First, Count, Val)
#define DBGLOG(s) { }
#define CheckMemoryLeaks { }
#define BreakOn(t) { }
#endif


class point {
public:
	double x, y, z;
	point() {}
	point(double x, double y, double z) :x(x), y(y), z(z) {}
	point(const point &other) :x(other.x), y(other.y), z(other.z) {}
	point& operator = (const point &other) { x = other.x, y = other.y, z = other.z; return *this; }
	~point() {}

	void normalize() { double m = sqrt(x*x + y * y + z * z); x /= m, y /= m, z /= m; }
	double mod() const { return sqrt(x*x + y * y + z * z); }
	friend double dot(const point &P, const point &Q) { return P.x*Q.x + P.y*Q.y + P.z*Q.z; }
	friend point cross(const point &P, const point &Q) { return point(P.y*Q.z - P.z*Q.y, P.z*Q.x - P.x*Q.z, P.x*Q.y - P.y*Q.x); }
	bool operator == (const point &other) const { return abs(x - other.x) < 1e-6 && abs(y - other.y) < 1e-6 && abs(z - other.z) < 1e-6; }
	point operator - () const { return point(-x, -y, -z); }
	point operator + (const point &p) const { return point(x + p.x, y + p.y, z + p.z); }
	point operator - (const point &p) const { return point(x - p.x, y - p.y, z - p.z); }
	friend point operator * (const double &c, const point &p) { return point(c*p.x, c*p.y, c*p.z); }
	void operator += (const point &p) { x += p.x, y += p.y, z += p.z; }
	void operator -= (const point &p) { x -= p.x, y -= p.y, z -= p.z; }
	void operator *= (const double &c) { x *= c, y *= c, z *= c; }
	void operator /= (const double &c) { x /= c, y /= c, z /= c; }
};
class point2D {
public:
	double x, y;
	point2D() {}
	template<typename T, typename t> point2D(T x, t y) :x((double)x), y((double)y) {}
	point2D(const point &other) :x(other.x), y(other.y) {}
	point2D& operator = (const point2D &other) { x = other.x, y = other.y; return *this; }
	~point2D() {}

	bool operator == (const point2D &other) const { return abs(x - other.x) < 1e-6 && abs(y - other.y) < 1e-6; }
	void operator -= (const point2D &p) { x -= p.x, y -= p.y; }
};
typedef point vec3;

vec3 randomVector() {	// uniform in solid angle
	vec3 r; do {
		r.x = pick_random(-1, 1), r.y = pick_random(-1, 1), r.z = pick_random(-1, 1);
	} while (r.x*r.x + r.y * r.y + r.z * r.z > 1);
	r.normalize(); return r;
}

class quaternion {	// unit quaternion
	double* m;	// calculated matrix
	double a, b, c, d;
	void initMatrix() {
		if (m == 0) m = new double[9];
		m[0] = 1 - 2 * c*c - 2 * d*d, m[1] = 2 * b*c - 2 * a*d, m[2] = 2 * a*c + 2 * b*d;
		m[3] = 2 * b*c + 2 * a*d, m[4] = 1 - 2 * b*b - 2 * d*d, m[5] = 2 * c*d - 2 * a*b;
		m[6] = 2 * b*d - 2 * a*c, m[7] = 2 * a*b + 2 * c*d, m[8] = 1 - 2 * b*b - 2 * c*c;
	}
public:
	quaternion() { m = 0; }
	quaternion(vec3 v, double theta) {
		v.normalize();
		a = cos(0.5*theta); double s = sin(0.5*theta);
		b = s * v.x, c = s * v.y, d = s * v.z;
		m = 0;
	}
	quaternion(double a, double b, double c, double d) :a(a), b(b), c(c), d(d) {
		double M = sqrt(a*a + b * b + c * c + d * d);
		this->a /= M, this->b /= M, this->c /= M, this->d /= M;
		m = 0;
	}
	quaternion(const quaternion &other) {
		a = other.a, b = other.b, c = other.c, d = other.d;
		m = 0;
	}
	quaternion& operator = (const quaternion &other) {
		a = other.a, b = other.b, c = other.c, d = other.d;
		if (m != 0) { delete m; m = 0; }
		return *this;
	}
	~quaternion() { if (m != 0) delete m; m = 0; }

	vec3 getAxis() const { vec3 r(b, c, d); r.normalize(); return r; }
	double getAngle() const { return 2 * acos(a); }

	vec3 operator * (const vec3 &v) const {
		if (m == 0) const_cast<quaternion*>(this)->initMatrix();
		return vec3(
			m[0] * v.x + m[1] * v.y + m[2] * v.z,
			m[3] * v.x + m[4] * v.y + m[5] * v.z,
			m[6] * v.x + m[7] * v.y + m[8] * v.z
		);
	}
	quaternion operator * (const quaternion &q) const {
		return quaternion(
			a*q.a - b * q.b - c * q.c - d * q.d,
			b*q.a + a * q.b - d * q.c + c * q.d,
			c*q.a + d * q.b + a * q.c - b * q.d,
			d*q.a - c * q.b + b * q.c + a * q.d
		);
	}
	quaternion invert() const { return quaternion(a, -b, -c, -d); }
};


HWND HWnd;
RECT Client; int clt_w, clt_h;
COLORREF *img; HBITMAP HImg;
point2D Cursor;
bool mouse_down = false; point CursorPos, OldCursorPos;

quaternion Tr(0.76, -0.52, -0.21, -0.32);
double Unit = 160;
const double MAX_Unit = 5000, MIN_Unit = 50;


point2D fromCoordinate(point P) {
	//P = Tr * P;
	return point2D(P.x * Unit + 0.5*clt_w, P.y * Unit + 0.5*clt_h);
}
point fromCanvas(point2D P) {
	P.x = (P.x - 0.5*clt_w) / Unit, P.y = (P.y - 0.5*clt_h) / Unit;
	double z = sqrt(1 - P.x*P.x - P.y*P.y);
	return Tr.invert()*vec3(P.x, P.y, z);
}

const vec3 light(-1, 2, 1);	// about screen coordinate (rotated)


class segment {
public:
	double cz; COLORf col;
	point A, B;
	segment() {}
	segment(const point &E1, const point &E2) { A = E1, B = E2, cz = 0.5*(E1.z + E2.z); }
	segment(const point &E1, const point &E2, const COLORf &col) { A = E1, B = E2, cz = 0.5*(E1.z + E2.z), this->col = col; }
	segment(const segment &other) { A = other.A, B = other.B, cz = other.cz, col = other.col; }
	segment& operator = (const segment &other) { A = other.A, B = other.B, cz = other.cz, col = other.col; return *this; }
	~segment() {}
	void transform() { A = Tr * A, B = Tr * B, cz = 0.5*(A.z + B.z); }
	void fill();
};
class triangle {
public:
	double cz; COLORf col;
	point A, B, C;
	vec3 n;	// normal
	triangle() {}
	triangle(const point &V1, const point &V2, const point &V3) { A = V1, B = V2, C = V3, cz = (V1.z + V2.z + V3.z) / 3; n = cross(B - A, C - A), n.normalize(); }
	triangle(const point &V1, const point &V2, const point &V3, const COLORf &col) { A = V1, B = V2, C = V3, cz = (V1.z + V2.z + V3.z) / 3; n = cross(B - A, C - A), n.normalize(); this->col = col; }
	triangle(const triangle &other) { A = other.A, B = other.B, C = other.C, cz = other.cz, n = other.n, col = other.col; }
	triangle& operator = (const triangle &other) { A = other.A, B = other.B, C = other.C, cz = other.cz, n = other.n, col = other.col; return *this; }
	~triangle() {}
	inline void transform() { A = Tr * A, B = Tr * B, C = Tr * C, n = Tr * n, cz = (A.z + B.z + C.z) / 3; }
	void fill();
};
void drawLine(int x1, int y1, int x2, int y2, COLORREF fill) {
	const int w = clt_w, h = clt_h;
	double slope, intercept; int d;
	if (abs(y2 - y1) < abs(x2 - x1)) {
		if (x1 > x2) swap(x1, x2), swap(y1, y2);
		if (x2 < 0 || (y1 < 0 && y2 < 0)) return;
		if (x1 > int(w) || (y1 > int(h) && y2 > int(h))) return;
		slope = double(y2 - y1) / (x2 - x1);
		intercept = y1 - x1 * slope;
		if (x1 < 0) x1 = 0, y1 = intercept;
		if (x2 > w) x2 = w, y2 = w * slope + intercept;
		if (x1*slope + intercept < 0) x1 = -intercept / slope, y1 = 0;
		else if (x1*slope + intercept > h) x1 = (h - intercept) / slope, y1 = h;
		if (x2*slope + intercept < 0) x2 = -intercept / slope, y2 = 0;
		else if (x2*slope + intercept > h) x2 = (h - intercept) / slope, y2 = h;
		for (int i = x1; i < x2; i++) {
			d = i * slope + intercept;
			if (d >= 0 && d < h) img[d * w + i] = fill;
		}
	}
	else {
		if (y1 > y2) swap(x1, x2), swap(y1, y2);
		if (y2 < 0 || (x1 < 0 && x2 < 0)) return;
		if (y1 > int(h) || (x1 > int(w) && x2 > int(w))) return;
		slope = double(x2 - x1) / (y2 - y1);
		intercept = x1 - y1 * slope;
		if (y1 < 0) y1 = 0, x1 = intercept;
		if (y2 > h) y2 = h, x2 = h * slope + intercept;
		if (y1*slope + intercept < 0) y1 = -intercept / slope, x1 = 0;
		else if (y1*slope + intercept > w) y1 = (w - intercept) / slope, x1 = w;
		if (y2*slope + intercept < 0) y2 = -intercept / slope, x2 = 0;
		else if (y2*slope + intercept > w) y2 = (w - intercept) / slope, x2 = w;
		for (int i = y1; i < y2; i++) {
			d = i * slope + intercept;
			if (d >= 0 && d < w) img[i * w + d] = fill;
		}
	}
}
void fillTrig(int x1, int y1, int x2, int y2, int x3, int y3, COLORREF fill) {
	// http://www.sunshine2k.de/coding/java/TriangleRasterization/TriangleRasterization.html
	auto fillBottomFlatTriangle = [](int x1, int y1, int x2, int y2, int x3, int y3, COLORREF fill) {
		double invslope1 = double(x2 - x1) / double(y2 - y1);
		double invslope2 = double(x3 - x1) / double(y3 - y1);
		if (0 * invslope1 != 0 || 0 * invslope2 != 0) return;
		double curx1 = x1, curx2 = x1; if (0 * curx1 != 0) return;
		int y_min = y1, y_max = y2; if (y_min > y_max) swap(y_min, y_max);
		if (y_min < 0) curx1 -= y_min * invslope1, curx2 -= y_min * invslope2, y_min = 0; if (y_max >= clt_h) y_max = clt_h - 1;
		for (int scanlineY = y_min; scanlineY <= y_max; scanlineY++) {
			int x_min = curx1, x_max = curx2; if (x_min > x_max) swap(x_min, x_max);
			if (x_min < 0) x_min = 0; if (x_max >= clt_w) x_max = clt_w - 1;
			for (int i = x_min; i <= x_max; i++) img[scanlineY*clt_w + i] = fill;
			curx1 += invslope1, curx2 += invslope2;
		}
	};
	auto fillTopFlatTriangle = [](int x1, int y1, int x2, int y2, int x3, int y3, COLORREF fill) {
		float invslope1 = double(x3 - x1) / double(y3 - y1);
		float invslope2 = double(x3 - x2) / double(y3 - y2);
		if (0 * invslope1 != 0 || 0 * invslope2 != 0) return;
		float curx1 = x3, curx2 = x3; if (0 * curx1 != 0) return;
		int y_min = y1, y_max = y3; if (y_min > y_max) swap(y_min, y_max);
		if (y_min < -1) y_min = -1; if (y_max >= clt_h) curx1 -= (y_max - clt_h + 1)*invslope1, curx2 -= (y_max - clt_h + 1)*invslope2, y_max = clt_h - 1;
		for (int scanlineY = y_max; scanlineY > y_min; scanlineY--) {
			int x_min = curx1, x_max = curx2; if (x_min > x_max) swap(x_min, x_max);
			if (x_min < 0) x_min = 0; if (x_max >= clt_w) x_max = clt_w - 1;
			for (int i = x_min; i <= x_max; i++) img[scanlineY*clt_w + i] = fill;
			curx1 -= invslope1, curx2 -= invslope2;
		}
	};
	if (y1 > y2) swap(x1, x2), swap(y1, y2); if (y2 > y3) swap(x2, x3), swap(y2, y3); if (y1 > y2) swap(x1, x2), swap(y1, y2);
	if (y2 == y3) fillBottomFlatTriangle(x1, y1, x2, y2, x3, y3, fill);
	else if (y1 == y2) fillTopFlatTriangle(x1, y1, x2, y2, x3, y3, fill);
	else {
		int x = x1 + (double(y2 - y1) / double(y3 - y1)) * (x3 - x1);
		fillBottomFlatTriangle(x1, y1, x2, y2, x, y2, fill);
		fillTopFlatTriangle(x2, y2, x, y2, x3, y3, fill);
	}
}
void segment::fill() {
	point2D A2 = fromCoordinate(A), B2 = fromCoordinate(B);
	drawLine(A2.x, A2.y, B2.x, B2.y, toCOLORREF(col));
}
void triangle::fill() {
	point2D A2 = fromCoordinate(A), B2 = fromCoordinate(B), C2 = fromCoordinate(C);
	fillTrig(A2.x, A2.y, B2.x, B2.y, C2.x, C2.y, toCOLORREF(col));
}


bool graphing = true;	// Indicates if a thread is graphing

const unsigned Niter = 8;
const unsigned Ng = ([](unsigned iter) -> unsigned { int Ng = 4; for (int i = 0; i < iter; i++) Ng *= 4; return Ng; })(Niter);
const unsigned iter = 1000;
triangle** sgs;
HANDLE IllustratingThread;


DWORD WINAPI graph(HANDLE H);
bool rotating = false, zooming = false;
DWORD WINAPI IllustrateModel(HANDLE H) {	// See http://paulbourke.net/fractals/noise/
	RAND_LCG_SEED = 0;	// set random number seed
	vec3 v, c;
	COLORf lt_alpha, dk_alpha;
	for (int i = 0; i < iter; i++) {
		v = randomVector(); double c = dot(randomVector(), v);
		lt_alpha = RGBf(pick_random(0.2) / sqrt(iter)), dk_alpha = RGBf(pick_random(0.2) / sqrt(iter));
		for (int j = 0; j < Ng; j++) {
			if (dot(sgs[j]->A, v) > c) sgs[j]->col += lt_alpha;
			else sgs[j]->col -= dk_alpha;
		}
		if (i % 5 == 0) graph(NULL);
	}
	while (1) {
		if (rotating || zooming) graph(NULL);
		Sleep(5);
	}
	return 0;
}
void model() {
	sgs = new triangle*[Ng];
	vec3 v0(0, 0, 1), v1(-sqrt(6) / 3, -sqrt(2) / 3, -1. / 3), v2(sqrt(6) / 3, -sqrt(2) / 3, -1. / 3), v3(0, 2 * sqrt(2) / 3, -1. / 3), v4, v5, v6;
	sgs[0] = new triangle(v2, v1, v3), sgs[1] = new triangle(v0, v2, v3), sgs[2] = new triangle(v0, v3, v1), sgs[3] = new triangle(v0, v1, v2);
	for (unsigned i = 0, s = 4; i < Niter; i++, s *= 4) {
		triangle **src = sgs + Ng - s, **p = sgs;
		memcpy(src, sgs, s * sizeof(triangle*));
		for (int i = 0; i < s; i++, p += 4) {
			triangle *q = src[i];
			v1 = q->A, v3 = q->B, v5 = q->C;
			v2 = v1 + v3, v4 = v3 + v5, v6 = v5 + v1; v2.normalize(), v4.normalize(), v6.normalize();
			p[0] = new triangle(v2, v4, v6), p[1] = new triangle(v2, v3, v4), p[2] = new triangle(v4, v5, v6), p[3] = new triangle(v6, v1, v2);
			delete q;
		}
	}
	//for (int i = 0; i < Ng; i++) sgs[i]->col = RGBf(0.85, 0.85, 0.85);	// Moon
	for (int i = 0; i < Ng; i++) sgs[i]->col = RGBf(0.8, 0.3, 0.1);		// Mars
	graphing = false;
	IllustratingThread = CreateThread(NULL, NULL, &IllustrateModel, NULL, NULL, NULL);
}
void destruct() {
	TerminateThread(IllustratingThread, 0);
	for (int i = 0; i < Ng; i++) delete sgs[i];
	delete sgs; sgs = 0;
}


DWORD WINAPI graph(HANDLE H) {
	if (!graphing) graphing = true;
	else return 0;
	HANDLE MT = CreateMutex(NULL, FALSE, NULL);

	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);


	fill_n(img, clt_w * clt_h, _RGB(0, 0, 0));

	vec3 v = Tr.invert() * vec3(0, 0, 1);

	segment x_axis(point(0, 0, 0), point(1, 0, 0), RGBf(1, 0, 0));
	segment y_axis(point(0, 0, 0), point(0, 1, 0), RGBf(0, 0.5, 0));
	segment z_axis(point(0, 0, 0), point(0, 0, 1), RGBf(0, 0, 1));

	for (int i = 0; i < Ng; i++) if (dot(v, sgs[i]->n) > 0) {
		triangle p = *(sgs[i]);
		p.transform();
		double a = dot(p.n, light); if (a < 0) a = 0;
		p.col = a * p.col;
		p.fill();
	}

	auto drawAxis = [](segment axis) {
		axis.A *= 50, axis.B *= 50;
		axis.A += vec3(80, clt_h - 80, 0), axis.B += vec3(80, clt_h - 80, 0);
		drawLine(axis.A.x, axis.A.y, axis.B.x, axis.B.y, toCOLORREF(axis.col));
	};
	x_axis.transform(), y_axis.transform(), z_axis.transform();
	segment* p[3] = { &x_axis, &y_axis, &z_axis };
	if (p[0]->cz > p[1]->cz) swap(p[0], p[1]); if (p[1]->cz > p[2]->cz) swap(p[1], p[2]); if (p[0]->cz > p[1]->cz) swap(p[0], p[1]);
	//drawAxis(*p[0]), drawAxis(*p[1]), drawAxis(*p[2]);


	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);

	ReleaseMutex(MT);
	graphing = false;
	return 0;
}



#include <chrono>
typedef std::chrono::high_resolution_clock NTime;
double zoom_v = 1;
bool zoom_rotate = false;

DWORD WINAPI AccelerateZooming(HANDLE H) {
	OldCursorPos = fromCanvas(Cursor);
	double t = *(double*)H;
	double dif = (t - zoom_v) / 100;
	for (int i = 0; i < 100; i++) zoom_v += dif, Sleep(1);
	return 0;
}

DWORD WINAPI RotationZoom(HANDLE H) {
	quaternion rotate_v(vec3(0, 0, 1), 0);
	quaternion rtv;
	while (1) {
		// zoom
		if (isnan(zoom_v)) Sleep(10), zoom_v = 1;
		if (isnan(Unit)) Sleep(10), Unit = 160;
		if (abs(zoom_v - 1) < 0.001) {
			zoom_v = 1, zooming = false;
			zoom_rotate = false;
		}
		else {
			while (graphing) Sleep(1);
			Unit *= zoom_v;
			if (Unit > MAX_Unit) Unit = MAX_Unit;
			if (Unit < MIN_Unit) Unit = MIN_Unit;

			CursorPos = fromCanvas(Cursor);
			if (zoom_rotate) {
				point t_OldCursorPos = Tr * OldCursorPos, t_CursorPos = Tr * CursorPos;
				vec3 axis(cross(t_OldCursorPos, t_CursorPos)); double theta = acos(dot(t_OldCursorPos, t_CursorPos));
				if (!(axis.mod() > 1e-6) || !(theta > 1e-3));
				else {
					while (graphing) Sleep(1);
					rtv = quaternion(axis, theta);
					Tr = rtv * Tr;
				}
			}
			//OldCursorPos = CursorPos;

			zoom_v = pow(zoom_v, 0.8);
			zooming = true;
		}

		// rotation
		if (mouse_down) {
			point t_OldCursorPos = Tr * OldCursorPos, t_CursorPos = Tr * fromCanvas(Cursor);
			vec3 axis(cross(t_OldCursorPos, t_CursorPos)); double theta = acos(dot(t_OldCursorPos, t_CursorPos));
			if (!(axis.mod() > 1e-6) || !(theta > 1e-3)) rotating = false;
			else {
				while (graphing) Sleep(1);
				rotate_v = quaternion(axis, 0.3 * theta);
				Tr = rotate_v * Tr;
				rotating = true;
			}
		}
		else {
			rotating = false;
			vec3 axis = rotate_v.getAxis(); double theta = rotate_v.getAngle();
			if (!(axis.mod() > 1e-6) || !(theta > 1e-3)) rotating = false;
			else {
				while (graphing) Sleep(1);
				rotate_v = quaternion(axis, 0.95*theta);
				Tr = rotate_v * Tr;
				rotating = true;
			}
		}
		Sleep(10);
	}
}
HANDLE RotationZoomThread;

void PauseThreads() {
	SuspendThread(IllustratingThread);
	SuspendThread(RotationZoomThread);
}
void ResumeThreads() {
	ResumeThread(IllustratingThread);
	ResumeThread(RotationZoomThread);
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = clt_w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)clt_h : clt_h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};
	switch (message) {
	case WM_CREATE: {
		GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		InitializeClientBitmap(hWnd, HImg, img, false);
		const_cast<vec3*>(&light)->normalize();
		HWnd = hWnd;
		RotationZoomThread = CreateThread(NULL, NULL, &RotationZoom, NULL, NULL, NULL);
		model();
		break;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		while (graphing) Sleep(1);
		PauseThreads();
		GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		Unit *= sqrt((clt_w * clt_h) / (prev_w * prev_h));
		DeleteObject(HImg);
		InitializeClientBitmap(hWnd, HImg, img, false);
		graph(NULL);
		ResumeThreads();
		break;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 600;
		lpMMI->ptMinTrackSize.y = 400;	// set minimum window size
		break;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HDwgMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HDwgMem, HImg);
		BitBlt(hdc, 0, 0, Client.right, Client.bottom, HDwgMem, 0, 0, SRCCOPY);
		SelectObject(HDwgMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HDwgMem);
		DeleteDC(hdc);
		break;
	}
	case WM_MOUSEMOVE: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		CursorPos = fromCanvas(Cursor);
		if (abs(log(zoom_v)) < 0.1) zoom_rotate = false;
		if (mouse_down) {	// click and drag
			if (isnan(CursorPos.x)) {
				OldCursorPos = CursorPos, mouse_down = false;
				break;
			}
		}
		break;
	}
	case WM_LBUTTONDOWN: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		OldCursorPos = CursorPos = fromCanvas(Cursor);
		if (!isnan(CursorPos.x)) mouse_down = true;
		break;
	}
	case WM_MOUSELEAVE:;
	case WM_NCMOUSEMOVE:;
	case WM_NCLBUTTONUP:;
	case WM_LBUTTONUP: {
		mouse_down = false;
		break;
	}
	case WM_MOUSEWHEEL: {
		if (!isnan(CursorPos.x)) zoom_rotate = true;
		int delta = GET_WHEEL_DELTA_WPARAM(wParam);
		double d = exp(0.0008 * delta);
		if (Unit * d > MAX_Unit) d = MAX_Unit / Unit;
		else if (Unit * d < MIN_Unit) d = MIN_Unit / Unit;
		CreateThread(NULL, NULL, &AccelerateZooming, &d, NULL, NULL);
		Sleep(10);	// waiting for thread to recieve data
		break;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		TerminateThread(RotationZoomThread, 0);
		destruct();
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
	default: {
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	}
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
	BreakOn(-1);

	const wchar_t CLASS_NAME[] = _T("Planet");
	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(16, 20, 23));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = CLASS_NAME;
	if (!RegisterClassEx(&wc)) return -1;

	HWND hWnd = CreateWindowEx(
		0,
		CLASS_NAME,
		CLASS_NAME,
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		900, 600,
		NULL, NULL, hInstance, NULL
	);
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	CheckMemoryLeaks;
	return (int)message.wParam;
}

