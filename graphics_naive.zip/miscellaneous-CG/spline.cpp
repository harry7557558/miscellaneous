#ifndef UNICODE
#define UNICODE
#endif

#pragma warning(disable:4244 4018 4010)

#include <Windows.h>
#include <tchar.h>
#include <windowsx.h>
#include <cmath>
#include <algorithm>
#include <vector>
using namespace std;


#pragma region Global

class point {
public:
	double x, y;
	point() {}
	template<typename T, typename t> point(T x, t y) :x((double)x), y((double)y) {}
	point(const point &other) :x(other.x), y(other.y) {}
	point& operator = (const point &other) { x = other.x, y = other.y; return *this; }
	~point() {}

	double mod() const { return sqrt(x*x + y * y); }
	friend double dot(const point &a, const point &b) { return a.x*b.x + a.y*b.y; }
	point operator + (const point &other) const { return point(x + other.x, y + other.y); }
	point operator - (const point &other) const { return point(x - other.x, y - other.y); }
	point operator * (const double &c) const { return point(c*x, c*y); }
	point operator / (const double &c) const { return point(x / c, y / c); }
	friend point operator * (const double &c, const point &p) { return point(c*p.x, c*p.y); }
};
#define _RGB(r,g,b) ((COLORREF)(((BYTE)(b)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(r))<<16)))
inline COLORREF mix(COLORREF a, COLORREF b, double r) {
	return _RGB((1 - r)*((BYTE*)&a)[2] + r * ((BYTE*)&b)[2], (1 - r)*((BYTE*)&a)[1] + r * ((BYTE*)&b)[1], (1 - r)*(BYTE)a + r * (BYTE)b);
}
void drawLine_p(COLORREF* data, int w, int h, double x1, double y1, double x2, double y2, double width, COLORREF fill) {	// width security check and anti-aliasing
	double dx = x2 - x1, dy = y2 - y1;
	double m = sqrt(dx*dx + dy * dy); dx /= m, dy /= m;		// components of direction vector
	double a = -dy, b = dx, c = -(a*x1 + b * y1);	// ax+by+c=0
	int x_min = min(x1, x2) - width, y_min = min(y1, y2) - width, x_max = max(x1, x2) + width, y_max = max(y1, y2) + width;
	x_min -= ceil(width), x_max += ceil(width), y_min -= ceil(width), y_max += ceil(width);
#define fix(x,min,max) if (x<min) x=min; if (x>=max) x=max-1;
	fix(x_min, 0, w); fix(x_max, 0, w); fix(y_min, 0, h); fix(y_max, 0, h);
#undef fix
	width /= 2; double sd, ds;
	for (int y = y_min; y < y_max; y++) {
		for (int x = x_min; x < x_max; x++) {
			ds = (x - x1) * dx + (y - y1) * dy;
			if (ds > 0 && ds < m) {
				sd = abs(a*x + b * y + c);
				sd = 0.5 - (sd - width);	// width can be zero or negative
				if (sd > 1) data[y*w + x] = fill;
				else if (sd > 0) data[y*w + x] = mix(data[y*w + x], fill, sd);
			}
		}
	}
}
void drawLine(COLORREF* data, int w, int h, double x1, double y1, double x2, double y2, double width, COLORREF fill) {
	// Call "drawLine_p" for parallel or verticle lines or short lines
#define fix(x,min,max) if (x<min) x=min; if (x>=max) x=max-1;
#define init \
		double dx = x2 - x1, dy = y2 - y1; \
		double m = sqrt(dx*dx + dy * dy); dx /= m, dy /= m; \
		double a = -dy, b = dx, c = -(a*x1 + b * y1); \
		int x_min = min(x1, x2) - width, y_min = min(y1, y2) - width, x_max = max(x1, x2) + width, y_max = max(y1, y2) + width; \
		fix(x_min, 0, w); fix(x_max, 0, w); fix(y_min, 0, h); fix(y_max, 0, h); \
		double width_2 = 0.5 * width; width = ceil(width); \
		double sd, ds;
	double slope, intercept; int d;
	if (abs(y2 - y1) < abs(x2 - x1)) {
		if (x1 > x2) swap(x1, x2), swap(y1, y2);
		if (x2 < 0 || (y1 < 0 && y2 < 0)) return;
		if (x1 > int(w) || (y1 > int(h) && y2 > int(h))) return;
		slope = double(y2 - y1) / (x2 - x1);
		intercept = y1 - x1 * slope;
		if (x1 < 0) x1 = 0, y1 = intercept;
		if (x2 >= w) x2 = w - 1, y2 = w * slope + intercept;
		if (int(x1*slope + intercept) < 0) x1 = -intercept / slope, y1 = 0;
		else if (int(x1*slope + intercept) >= h) x1 = (h - intercept) / slope, y1 = h - 1;
		if (int(x2*slope + intercept) < 0) x2 = -intercept / slope, y2 = 0;
		else if (int(x2*slope + intercept) >= h) x2 = (h - intercept) / slope, y2 = h - 1;
		init;
		for (int i = x1 - width; i < x2 + width; i++) {
			if (i >= 0 && i < w) {
				d = ceil(i * slope + intercept + width);
				for (int j = d - 2 * width - 1; j <= d; j++) {
					if (j >= 0 && j < h) {
						ds = (i - x1) * dx + (j - y1) * dy;
						if (ds > 0 && ds < m) {
							sd = abs(a*i + b * j + c);
							sd = 0.5 - (sd - width_2);
							if (sd > 1) data[j*w + i] = fill;
							else if (sd > 0) data[j*w + i] = mix(data[j*w + i], fill, sd);
						}
					}
				}
			}
		}
	}
	else {
		if (y1 > y2) swap(x1, x2), swap(y1, y2);
		if (y2 < 0 || (x1 < 0 && x2 < 0)) return;
		if (y1 > int(h) || (x1 > int(w) && x2 > int(w))) return;
		slope = double(x2 - x1) / (y2 - y1);
		intercept = x1 - y1 * slope;
		if (y1 < 0) y1 = 0, x1 = intercept;
		if (y2 >= h) y2 = h - 1, x2 = h * slope + intercept;
		if (int(y1*slope + intercept) < 0) y1 = -intercept / slope, x1 = 0;
		else if (int(y1*slope + intercept) >= w) y1 = (w - intercept) / slope, x1 = w - 1;
		if (int(y2*slope + intercept) < 0) y2 = -intercept / slope, x2 = 0;
		else if (int(y2*slope + intercept) >= w) y2 = (w - intercept) / slope, x2 = w - 1;
		init;
		for (int i = y1 - width; i < y2 + width; i++) {
			if (i >= 0 && i < h) {
				d = ceil(i * slope + intercept + width);
				for (int j = d - 2 * width - 1; j <= d; j++) {
					if (j >= 0 && j < w) {
						ds = (j - x1) * dx + (i - y1) * dy;
						if (ds > 0 && ds < m) {
							sd = abs(a*j + b * i + c);
							sd = 0.5 - (sd - width_2);
							if (sd > 1) data[i*w + j] = fill;
							else if (sd > 0) data[i*w + j] = mix(data[i*w + j], fill, sd);
						}
					}
				}
			}
		}
	}
#undef fix
#undef init
}

HWND HWnd;
RECT Client; unsigned clt_w, clt_h;
COLORREF* bkg_data;
COLORREF* dwg_data; HBITMAP HDwg;
point Cursor;
point Origin(0, 0); double Unit = 15;
inline point fromCoordinate(point P) {
	return point(P.x * Unit + Origin.x, -P.y * Unit + Origin.y);
}
inline point fromCanvas(point P) {
	return point((P.x - Origin.x) / Unit, -(P.y - Origin.y) / Unit);
}


#include "C:\\Users\\harry\\Desktop\\Polynomial Solver\\Polynomial Solver\\Polynomial Solver.cpp"	// https://github.com/Harry7557558/miscellaneous/blob/master/Polynomial%20Solver.cpp
class spline {
	// Construct a smooth curve between P1 and P2 \
	                |-0.5  1.5 -1.5  0.5 | |P0|					\
	P = [t³ t² t 1] | 1.0 -2.5  2.0 -0.5 | |P1|   0 ≤ t ≤ 1		\
	                |-0.5  0.0  0.5  0.0 | |P2|					\
	                | 0.0  1.0  0.0  0.0 | |P3|					
	vector<point> ctp;
	point E0, E1;
	vector<point> ftp;
	void init() {
		if (ctp.size() >= 2) E0 = 2 * ctp[0] - ctp[1], E1 = 2 * ctp.back() - ctp[ctp.size() - 2];
		ftp.clear();
		ftp.push_back(E0); for (int i = 0; i < ctp.size(); i++) ftp.push_back(ctp.at(i)); ftp.push_back(E1);
	}
public:
	spline() :E0(0, 0), E1(0, 0) {}
	spline(initializer_list<point> p) { ctp.assign(p); init(); }
	spline(const spline &other) { ctp = other.ctp; init(); }
	spline& operator = (const spline &other) { ctp = other.ctp; init(); return *this; }
	~spline() { ctp.clear(); }

	int size() const { return ctp.size(); }
	point begin() const { return ctp.at(0); }
	point end() const { return ctp.at(ctp.size() - 1); }
	point at(unsigned n) const { return ctp.at(n); }
	point eval(double t) const {
		unsigned n = t; t -= n; n++;
		if (n + 2 >= ftp.size()) return point(NAN, NAN);
		return (((-0.5*t + 1.0)*t - 0.5)*t) * ftp[n - 1]
			+ (((1.5*t - 2.5)*t)*t + 1.0) * ftp[n]
			+ (((-1.5*t + 2.0)*t + 0.5)*t) * ftp[n + 1]
			+ (((0.5*t - 0.5)*t)*t) * ftp[n + 2];
	}
	double sdc(const point &p, double &m) const {	// cofficient to the minimum distance to a point
		if (ftp.size() < 4) return NAN;
		auto psdc = [](const point &P0, const point &P1, const point &P2, const point &P3, const point &P, double &md) -> double {	// for single spline
			double PP0 = dot(P, P0), PP1 = dot(P, P1), PP2 = dot(P, P2), PP3 = dot(P, P3), P0P0 = dot(P0, P0), P0P1 = dot(P0, P1), P0P2 = dot(P0, P2), P0P3 = dot(P0, P3),
				P1P1 = dot(P1, P1), P1P2 = dot(P1, P2), P1P3 = dot(P1, P3), P2P2 = dot(P2, P2), P2P3 = dot(P2, P3), P3P3 = dot(P3, P3);
			double r1, r2, r3, r4, r5;
			solveQuintic(0.75*P0P0 - 4.5*P0P1 + 4.5*P0P2 - 1.5*P0P3 + 6.75*P1P1 - 13.5*P1P2 + 4.5*P1P3 + 6.75*P2P2 - 4.5*P2P3 + 0.75*P3P3,
				-2.5*P0P0 + 13.75*P0P1 - 12.5*P0P2 + 3.75*P0P3 - 18.75*P1P1 + 33.75*P1P2 - 10 * P1P3 - 15 * P2P2 + 8.75*P2P3 - 1.25*P3P3,
				3 * P0P0 - 13 * P0P1 + 10 * P0P2 - 3 * P0P3 + 12.5*P1P1 - 17 * P1P2 + 5 * P1P3 + 5 * P2P2 - 3 * P2P3 + 0.5*P3P3,
				1.5*PP0 - 4.5*PP1 + 4.5*PP2 - 1.5*PP3 - 1.5*P0P0 + 2.25*P0P1 - 1.5*P0P2 + 0.75*P0P3 + 4.5*P1P1 - 8.25*P1P2 + 1.5*P1P3 + 3 * P2P2 - 0.75*P2P3,
				-2 * PP0 + 5 * PP1 - 4 * PP2 + PP3 + 0.25*P0P0 + 2 * P0P1 - 0.5*P0P2 - 5 * P1P1 + 4 * P1P2 - P1P3 + 0.25*P2P2,
				0.5*PP0 - 0.5*PP2 - 0.5*P0P1 + 0.5*P1P2, r1, r2, r3, r4, r5);
			if (r1 < 0 || r1 >= 1) r1 = NAN; if (r2 < 0 || r2 >= 1) r2 = NAN; if (r3 < 0 || r3 >= 1) r3 = NAN; if (r4 < 0 || r4 >= 1) r4 = NAN; if (r5 < 0 || r5 >= 1) r5 = NAN;
			double m0 = (P - P1).mod(), m1 = (P - P2).mod(), m;
			double min_m, min_t; if (m0 < m1) min_m = m0, min_t = 0; else min_m = m1, min_t = 0.999999;
#define S(x) if (x == x) { \
				m = (P - ((((-0.5*x + 1.0)*x - 0.5)*x) * P0 + (((1.5*x - 2.5)*x)*x + 1.0) * P1 + (((-1.5*x + 2.0)*x + 0.5)*x) * P2 + (((0.5*x - 0.5)*x)*x) * P3)).mod(); \
				if (m < min_m) min_t = x, min_m = m; }
			S(r1); S(r2); S(r3); S(r4); S(r5);
#undef S
			md = min_m; return min_t;
		};
		double mm, mt = psdc(ftp[0], ftp[1], ftp[2], ftp[3], p, mm), md, t; int mn = 0;
		for (int i = 1; i < ftp.size() - 3; i++) {
			t = psdc(ftp[i], ftp[i + 1], ftp[i + 2], ftp[i + 3], p, md);
			if (md < mm) mm = md, mn = i, mt = t;
		}
		m = mm; return mn + mt;
	}
	double sdc(const point &p) const { double m; return sdc(p, m); }

	point& at(unsigned n) { return ctp.at(n); }
	void push(point P) { ctp.push_back(P); init(); }
	void pop() { ctp.pop_back(); init(); }

};
void drawSpline(COLORREF* data, int w, int h, const spline &c, double width, COLORREF fill) {
	unsigned n = c.size(); if (n < 2) return; n--;
	point pp = c.eval(0), p;
	for (double t = 0; t < n; t += 0.05) {
		p = c.eval(t);
		drawLine(data, w, h, pp.x, pp.y, p.x, p.y, width, fill);
		pp = p;
	}
	p = c.eval(n - 1e-9);
	drawLine(data, w, h, pp.x, pp.y, p.x, p.y, width, fill);
}
vector<spline> osp;
spline spline_tmp;
enum opr_status { previewing, drawing, editing, fixing }; opr_status Status;
point fitted(NAN, NAN);
spline* fitted_l = 0; double fitted_l_t = NAN;

#pragma endregion

void fitEndpoints() {
	double dist, mdist = INFINITY;
	fitted = point(NAN, NAN);
	for (int i = 0; i < osp.size(); i++) {
		dist = (Cursor - fromCoordinate(osp.at(i).begin())).mod();
		if (dist < 20 && dist < mdist) fitted = osp.at(i).begin();
		mdist = min(dist, mdist);
	}
	for (int i = 0; i < osp.size(); i++) {
		dist = (Cursor - fromCoordinate(osp.at(i).end())).mod();
		if (dist < 20 && dist < mdist) fitted = osp.at(i).end();
		mdist = min(dist, mdist);
	}
}
void fitLine() {
	fitted_l = 0, fitted_l_t = NAN;
	double t, m, mt = NAN, mm = INFINITY; spline* c = 0;
	for (int i = 0; i < osp.size(); i++) {
		t = osp.at(i).sdc(fromCanvas(Cursor), m); m *= Unit;
		if (m < 20 && m < mm) mm = m, mt = t, c = &osp.at(i);
	}
	if (Status == drawing) {
		t = spline_tmp.sdc(fromCanvas(Cursor), m); m *= Unit;
		if (m < 20 && m < mm) mm = m, mt = t, c = &spline_tmp;
	}
	fitted_l = c, fitted_l_t = mt;
}


#include <memory>
void draw_bkg_data() {
	// Background
	COLORREF col = _RGB(16, 20, 23);
#ifdef _DEBUG
	for (unsigned i = 0, l = clt_w * clt_h; i < l; i++) bkg_data[i] = col;
#else
	uninitialized_fill_n(bkg_data, clt_w * clt_h, col);		// much faster in release mode, but not debug mode
#endif

	// Grid
	double L = 100.0 / Unit;	// side length of major gridlines
	double tp = pow(10, floor(log10(L)));
	L /= tp; L = (L < 2 ? 1 : L < 5 ? 2 : 5) * tp;
	double l = L / 5;	// side length of minor gridlines
	point LeftTop = fromCanvas(point(0, 0)), RightBottom = fromCanvas(point(clt_w, clt_h));
	LeftTop.x = round(LeftTop.x / l - 0.5), LeftTop.y = round(LeftTop.y / l + 0.5);
	RightBottom.x = round(RightBottom.x / l + 0.5), RightBottom.y = round(RightBottom.y / l - 0.5);

	// Minor gridlines
	col = mix(_RGB(16, 20, 23), _RGB(35, 45, 50), 0.3);
	for (double i = LeftTop.x; i <= RightBottom.x; i++) {
		point P = fromCoordinate(point(i * l, 0));
		int dr = round(P.x);
		if (dr >= 0 && dr < clt_w) for (int i = 0; i < clt_h; i++) {
			bkg_data[i*clt_w + dr] = col;
		}
	}
	for (double i = LeftTop.y; i >= RightBottom.y; i--) {
		point P = fromCoordinate(point(0, i * l));
		int dr = round(P.y);
		if (dr >= 0 && dr < clt_h) for (int i = 0; i < clt_w; i++) {
			bkg_data[dr*clt_w + i] = col;
		}
	}

	// Major gridlines
	LeftTop.x = round(LeftTop.x / 5 - 0.5), LeftTop.y = round(LeftTop.y / 5 + 0.5);
	RightBottom.x = round(RightBottom.x / 5 + 0.5), RightBottom.y = round(RightBottom.y / 5 - 0.5);
	col = mix(_RGB(16, 20, 23), _RGB(55, 65, 75), 0.4);
	for (double i = LeftTop.x; i <= RightBottom.x; i++) {
		point P = fromCoordinate(point(i * L, 0));
		int dr = round(P.x);
		if (dr >= 0 && dr < clt_w) for (int i = 0; i < clt_h; i++) {
			bkg_data[i*clt_w + dr] = col;
		}
	}
	for (double i = LeftTop.y; i >= RightBottom.y; i--) {
		point P = fromCoordinate(point(0, i * L));
		int dr = round(P.y);
		if (dr >= 0 && dr < clt_h) for (int i = 0; i < clt_w; i++) {
			bkg_data[dr*clt_w + i] = col;
		}
	}

	// Axis
	drawLine_p(bkg_data, clt_w, clt_h, Origin.x, 0, Origin.x, clt_h, 1.0, _RGB(80, 75, 140));
	drawLine_p(bkg_data, clt_w, clt_h, 0, Origin.y, clt_w, Origin.y, 1.0, _RGB(80, 75, 140));

}
void draw_dwg_data() {
	HDC hdc = GetDC(HWnd);
	HDC HDwgMem = CreateCompatibleDC(hdc);	// sometimes returns null
	HBITMAP hbmOld = (HBITMAP)SelectObject(HDwgMem, HDwg);

	//draw_bkg_data();
	memcpy(dwg_data, bkg_data, sizeof(COLORREF) * clt_w * clt_h);

	// Cursor
	drawLine(dwg_data, clt_w, clt_h, Cursor.x - 12, Cursor.y, Cursor.x + 12, Cursor.y, 2, _RGB(0, 255, 0));
	drawLine(dwg_data, clt_w, clt_h, Cursor.x, Cursor.y - 12, Cursor.x, Cursor.y + 12, 2, _RGB(0, 255, 0));

	// Splines
	spline C;
	for (int i = 0; i < osp.size(); i++) {
		C = spline();
		for (int d = 0; d < osp.at(i).size(); d++) C.push(fromCoordinate(osp.at(i).at(d)));
		drawSpline(dwg_data, clt_w, clt_h, C, 1, _RGB(255, 255, 255));
	}

	// Preview splines
	C = spline();
	for (int d = 0; d < spline_tmp.size(); d++) C.push(fromCoordinate(spline_tmp.at(d)));
	C.push(Cursor);
	drawSpline(dwg_data, clt_w, clt_h, C, 2, _RGB(255, 255, 255));
	for (int i = 0; i < spline_tmp.size(); i++) {	// draw control points
		point P = C.at(i);
		drawLine_p(dwg_data, clt_w, clt_h, P.x - 6, P.y, P.x + 6, P.y, 1, _RGB(65, 225, 105));
		drawLine_p(dwg_data, clt_w, clt_h, P.x, P.y - 6, P.x, P.y + 6, 1, _RGB(65, 225, 105));
	}

	// Draw fitted point/line
	if (fitted.x == fitted.x && fitted.y == fitted.y) {
		point P = fromCoordinate(fitted);
		drawLine_p(dwg_data, clt_w, clt_h, P.x - 6, P.y, P.x + 6, P.y, 1, _RGB(0, 225, 0));
		drawLine_p(dwg_data, clt_w, clt_h, P.x, P.y - 6, P.x, P.y + 6, 1, _RGB(0, 225, 0));
	}
	else if (fitted_l != 0 && !isnan(fitted_l_t)) {
		point P = fromCoordinate(fitted_l->eval(fitted_l_t));
		drawLine_p(dwg_data, clt_w, clt_h, P.x - 6, P.y, P.x + 6, P.y, 1, _RGB(0, 225, 0));
		drawLine_p(dwg_data, clt_w, clt_h, P.x, P.y - 6, P.x, P.y + 6, 1, _RGB(0, 225, 0));
	}


	BitBlt(hdc, 0, 0, clt_w, clt_h, HDwgMem, 0, 0, SRCCOPY);
	SelectObject(HDwgMem, hbmOld);
	DeleteDC(HDwgMem);
	DeleteDC(hdc);
}



LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = clt_w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)clt_h : clt_h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};
	if (message == WM_SETCURSOR && LOWORD(lParam) == HTCLIENT) {
		SetCursor(NULL);
		return TRUE;	// hide cursor, doesn't work in switch/case/else
	}
	switch (message) {
	case WM_CREATE: {
		HWnd = hWnd;
		GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		Origin = point(0.5*clt_w, 0.5*clt_h);
		bkg_data = new COLORREF[clt_w*clt_h];
		InitializeClientBitmap(hWnd, HDwg, dwg_data, false);
		HWnd = hWnd;
		Status = previewing;
		break;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		Unit *= sqrt((clt_w * clt_h) / (prev_w * prev_h));
		Origin.x *= clt_w / prev_w, Origin.y *= clt_h / prev_h;

		delete bkg_data; bkg_data = new COLORREF[clt_w*clt_h];
		InitializeClientBitmap(hWnd, HDwg, dwg_data, false);

		draw_bkg_data();
		draw_dwg_data();
		break;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 600;
		lpMMI->ptMinTrackSize.y = 400;	// set minimum window size
		break;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HDwgMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HDwgMem, HDwg);
		BitBlt(hdc, 0, 0, Client.right, Client.bottom, HDwgMem, 0, 0, SRCCOPY);
		SelectObject(HDwgMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HDwgMem);
		DeleteDC(hdc);
		break;
	}
	case WM_MOUSEMOVE: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		fitEndpoints();
		fitLine();
		draw_dwg_data();
		break;
	}
	case WM_LBUTTONDOWN: {
		if (Status == previewing) {
			point P(GET_X_LPARAM(lParam), clt_h - GET_Y_LPARAM(lParam));
			if (!isnan(fitted.x) && !isnan(fitted.y)) P = fromCoordinate(fitted);
			else if (fitted_l != 0 && !isnan(fitted_l_t)) P = fromCoordinate(fitted_l->eval(fitted_l_t));
			spline_tmp.push(fromCanvas(P));
			Status = drawing;
			break;
		}
		else if (Status == drawing) {
			point P(GET_X_LPARAM(lParam), clt_h - GET_Y_LPARAM(lParam));
			if (!isnan(fitted.x) && !isnan(fitted.y)) P = fromCoordinate(fitted);
			else if (fitted_l != 0 && !isnan(fitted_l_t)) P = fromCoordinate(fitted_l->eval(fitted_l_t));
			spline_tmp.push(fromCanvas(P));
			break;
		}
		else if (Status == editing) {

		}
		else if (Status == fixing) {

		}
		break;
	}
	case WM_RBUTTONDOWN: {
		if (Status == drawing) {
			spline_tmp.pop();
			if (spline_tmp.size() == 0) Status = previewing;
			draw_dwg_data();
			break;
		}
		break;
	}
	case WM_MOUSEWHEEL: {
		int delta = GET_WHEEL_DELTA_WPARAM(wParam);
		const double MAX = 1e+6, MIN = 1e-8;
		double d = exp(0.0008 * delta);
		if (Unit * d > MAX) d = MAX / Unit;
		else if (Unit * d < MIN) d = MIN / Unit;
		Origin.x = Origin.x * d + Cursor.x * (1 - d), Origin.y = Origin.y * d + Cursor.y * (1 - d);
		Unit *= d;
		draw_bkg_data();
		draw_dwg_data();
		break;
	}
	case WM_KEYDOWN: {
		switch (wParam) {
		case VK_RETURN: {
			if (Status == drawing) {
				if (spline_tmp.size() >= 2) osp.push_back(spline_tmp);
				spline_tmp = spline();
				Status = previewing;
				draw_dwg_data();
			}
			break;
		}
		}
		break;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		delete bkg_data;
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
	default: {
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	}
	return 0;
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
	const wchar_t CLASS_NAME[] = _T("Mouse Input Test");
	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(16, 20, 23));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = CLASS_NAME;
	if (!RegisterClassEx(&wc)) return -1;

	HWND hWnd = CreateWindowEx(
		0,
		CLASS_NAME,
		CLASS_NAME,
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		800, 600,
		NULL, NULL, hInstance, NULL
	);
	//ShowWindow(hWnd, SW_MAXIMIZE);
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	return (int)message.wParam;
}
