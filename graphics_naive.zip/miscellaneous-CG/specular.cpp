#include <Windows.h>
#include <tchar.h>

#pragma warning(disable:4244 4018 4010 4305)

#include "3D.h"
#include "RayTracing.h"


using namespace std;


#define APPLICATION_NAME " Real-Time Ray Tracing (specular only)"

HWND HWnd;
RECT Client; int clt_w, clt_h;
COLORREF *img; HBITMAP HImg;
bool param_is_modifying = true;


#include <chrono>
typedef chrono::high_resolution_clock NTime;
typedef std::chrono::duration<double> fsec;

const auto t0 = NTime::now();
inline double iTime() { return fsec(NTime::now() - t0).count(); }


const vec3 dome = vec3(0, 0, 1).unitvec();

vec3 P(800, 300, 300), V(0, 0, 0); double Unit = 2, dist = 300;
RT_Parallelogram Screen;

void CalcScreen() {
	vec3 v = (V - P).unitvec();
	double rz = atan2(v.x, -v.y), rx = atan2(hypot(v.x, v.y), v.z);
	mat3 M; M.rotate_zx(rz, rx);
	Screen = RT_Parallelogram(M*vec3(0.5*clt_w / Unit, -0.5*clt_h / Unit, dist) + P, M*vec3(-clt_w / Unit, 0, 0), M*vec3(0, clt_h / Unit, 0));
	//Dout("P=" << P << ", v=Vector(" << P << "," << (P + dist * v) << "), Screen=" << Screen);
}



//-------------------------------------------



#include <vector>
vector<RT_Object*> Objs;
void destruct() {
	for (int i = 0; i < Objs.size(); i++) delete Objs[i];
	Objs.clear();
}
void construct() {
	if (!Objs.empty()) destruct();
	Objs.push_back(new RT_Parallelogram(vec3(-200, -200, 0), vec3(400, 0, 0), vec3(0, 400, 0), vec3(0.5, 0.8, 1)));
	Objs.push_back(new RT_Sphere(vec3(0, 0, 50), 50, vec3(255, 250, 238) / 256));
	Objs.push_back(new RT_Cylinder(vec3(0, 100, 50), vec3(0, -100, 80), 30, vec3(255, 215, 0) / 256));
	CalcScreen();
	for (int i = 0; i < Objs.size(); i++) dout("C_{" << i << "}=" << *Objs.at(i) << ";  "
		<< "SetColor(C_{" << i << "}," << int(255 * Objs.at(i)->col.x) << "," << int(255 * Objs.at(i)->col.y) << "," << int(255 * Objs.at(i)->col.z) << ")" << endl);
}



//-------------------------------------------



bool calcIntersect(cv3ref P, cv3ref d, RT_Object* &IO, double &t, vec3 &n) {
	double min_t = INFINITY; vec3 min_n; IO = 0;
	for (int i = 0; i < Objs.size(); i++) {
		if (Objs.at(i)->intersect(P, d, t, n) && t < min_t) {
			min_t = t, min_n = n, IO = Objs.at(i);
		}
	}
	t = min_t, n = min_n;
	return IO;
}

vec3 traceRay(cv3ref P, cv3ref d, unsigned N) {		// return color
	if (++N > 50) return vec3(0, 0, 0);
	RT_Object* IO; double t; vec3 n;
	if (calcIntersect(P, d, IO, t, n)) {
		vec3 col = traceRay(P + t * d, d - (2 * dot(d, n)) * n, N);
		col.x *= IO->col.x, col.y *= IO->col.y, col.z *= IO->col.z;
		//dout("Vector(" << P << "," << (P + t * d) << ")" << endl);
		return col;
	}
	else {
		double t = dot(dome, d);
		//dout("Vector(" << P << "," << (P + Unit * d) << ")" << endl);
		if (t > 0) return vec3(t, t, t);
		else return vec3(0, 0, 0);
	}

}


void MainImage(vec3 &col, vec2 coor) {
	vec3 dir = (Screen.O + (coor.x / clt_w)*Screen.A + (coor.y / clt_h)*Screen.B - P).unitvec();
	col = traceRay(P, dir, 0);
}




//-------------------------------------------



#include <thread>

bool rendering = false;
void render() {

	if (rendering) return; rendering = true;

	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);


	unsigned clt_size = clt_w * clt_h;
	const unsigned MAX_THREADS = thread::hardware_concurrency();
	const unsigned ppt = 0x1000;
	const unsigned N = clt_size / ppt;

	bool* fn = new bool[MAX_THREADS]; for (int i = 0; i < MAX_THREADS; i++) fn[i] = false;
	thread** T = new thread*[MAX_THREADS]; for (int i = 0; i < MAX_THREADS; i++) T[i] = NULL;

	unsigned released = 0, finished = 0;
	while (finished < N) {
		for (int i = 0; i < MAX_THREADS; i++) {
			if (fn[i]) {
				fn[i] = false;
				delete T[i]; T[i] = 0;
				if (++finished >= N) break;
			}
			if (!fn[i] && !T[i] && released < N) {
				T[i] = new thread([&](unsigned beg, unsigned end, bool* sig) {
					COLORf col;
					for (unsigned i = beg; i < end; i++) {
						MainImage(*(vec3*)&col, vec2(i % clt_w, i / clt_w));
						if (!param_is_modifying) img[i] = toCOLORREF(col);
					}
					*sig = true;
				}, ppt * released, ppt * (released + 1), fn + i);
				T[i]->detach();
				released++;
			}
		}
	}

	COLORf col;
	for (unsigned i = N * ppt; i < clt_size; i++) {
		MainImage(*(vec3*)&col, vec2(i % clt_w, i / clt_w));
		if (!param_is_modifying) img[i] = toCOLORREF(col);
	}

	delete fn;
	delete T;



	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);

	rendering = false;

}
void dbgRender() {
	COLORf col;
	for (unsigned i = 0, clt_size = clt_w * clt_h; i < clt_size; i++) {
		MainImage(*(vec3*)&col, vec2(i % clt_w, i / clt_w)); \
			img[i] = toCOLORREF(col);
	}

	unsigned Fw = 360, Fh = 140;
	if (Fw > 0 && Fh > 0 && Fw + 1 < clt_w && Fh + 1 < clt_h) {
		MainImage(*(vec3*)&col, vec2(Fw, Fh));
		img[Fh * clt_w + Fw] = toCOLORREF(col);
		img[(Fh - 1)*clt_w + Fw] = img[(Fh + 1)*clt_w + Fw] = img[Fh*clt_w + Fw - 1] = img[Fh*clt_w + Fw + 1] = _RGB(255, 0, 0);
	}

	saveBitmap(img, clt_w, clt_h, "C:\\Users\\harry\\Desktop\\Test\\Release\\dbg.bmp");
	exit(0);
}


#include <string>

HANDLE RenderingThread;
DWORD WINAPI fpsTest(HANDLE H) {

	auto uint2str = [](unsigned n)->string {
		string r;
		while (n) r = char('0' + n % 10) + r, n /= 10;
		return r;
	};
	auto fps2str = [](double a)->string {
		if (a <= 0 || a > 2000 || isNaN(a)) return "###";
		int e = 3;
		while (a < 100) a *= 10, e--;
		string r;
		while (a != 0) r = char('0' + int(a) % 10) + r, a = int(a) / 10;
		while (e <= 0) r = '0' + r, e++;
		if (e < 3) r.insert(r.begin() + e, '.');
		return r;
	};

	while (1) {
		Sleep(1000);
		auto t0 = NTime::now();
		render();
		auto t1 = NTime::now();
		fsec fs = t1 - t0;
		SetWindowTextA(HWnd, &("   " + (fps2str(1 / fs.count()) + "fps") + "      " + (uint2str(clt_w) + "x" + uint2str(clt_h)) + "       " + APPLICATION_NAME)[0]);
	}


	return 0;
}



//-------------------------------------------



#include <windowsx.h>

bool mouse_down = false;
vec2 Cursor(0, 0), OrigCursor = Cursor;
vec3 OrigP, OrigV; RT_Parallelogram OrigScreen;


bool IntersectionTest(cv3ref P, cv3ref d, double* _t, vec3* _n) {
	double min_t = INFINITY, t; vec3 min_n, n; bool I = false;
	for (int i = 0; i < Objs.size(); i++) {
		if (Objs.at(i)->intersect(P, d, t, n) && t < min_t) min_t = t, min_n = n, I = true;
	}
	if (isNaN(min_t)) min_t = -P.z / d.z;
	if (_t != 0) *_t = min_t; if (_n != 0) *_n = min_n;
	return I;
}
vec3 fromScreen(vec2 coor) {
	coor.x /= clt_w, coor.y /= clt_h;
	vec3 S = Screen.O + coor.x * Screen.A + coor.y * Screen.B, dir = (S - P).unitvec();
	double t; if (IntersectionTest(P, dir, &t, NULL)) return P + t * dir;
	return P - (P.z / dir.z) * dir;
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = clt_w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)clt_h : clt_h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};
	switch (message) {
#pragma region window
	case WM_CREATE: {
		GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		InitializeClientBitmap(hWnd, HImg, img, false);
		HWnd = hWnd;
		construct();
		RT_Object* IO; double t; vec3 n;
		if (calcIntersect(P, (V - P).unitvec(), IO, t, n)) V = P + t * (V - P).unitvec();
		//dbgRender();
		RenderingThread = CreateThread(NULL, NULL, &fpsTest, NULL, NULL, NULL);
		return 0;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		param_is_modifying = true;
		while (rendering) Sleep(1);
		SuspendThread(RenderingThread);
		GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		Unit *= sqrt((clt_w*clt_h) / (prev_w*prev_h));
		DeleteObject(HImg);
		InitializeClientBitmap(hWnd, HImg, img, false);
		CalcScreen();
		param_is_modifying = false;
		render();
		ResumeThread(RenderingThread);
		return 0;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 120, lpMMI->ptMinTrackSize.y = 80;
		return 0;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HMem, HImg);
		BitBlt(hdc, 0, 0, Client.right, Client.bottom, HMem, 0, 0, SRCCOPY);
		SelectObject(HMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HMem);
		DeleteDC(hdc);
		return 0;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		while (rendering) Sleep(1);
		TerminateThread(RenderingThread, NULL);
		destruct();
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
#pragma endregion
#pragma region user
	case WM_MOUSEMOVE: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		if (mouse_down) {
			double dx = OrigCursor.x - Cursor.x, dy = OrigCursor.y - Cursor.y;
			dx *= 2 * PI / clt_w, dy *= 2 * PI / clt_h;
			vec3 OP = OrigP, OV = OrigV;
			double a = asin((OP - OV).unitvec().z);
			if (a + dy >= 1.57) dy = 1.57 - a;
			if (a + dy <= -1.57) dy = -1.57 - a;
			mat3 M; M.rotate_z(dx); M.rotate(cross(M * (OP - OV), vec3(0, 0, 1)), dy);
			P = M * (OP - OV) + OV;
			CalcScreen();
			render(); return 0;
		}
		return 0;
	}
	case WM_LBUTTONDOWN: {
		mouse_down = true;
		OrigCursor = Cursor, OrigP = P, OrigV = V, OrigScreen = Screen;
		return 0;
	}
	case WM_LBUTTONUP: {
		mouse_down = false;
		return 0;
	}
	case WM_MOUSEWHEEL: {	// doesn't work fine
		double delta = GET_WHEEL_DELTA_WPARAM(wParam);
		vec3 Vf = fromScreen(Cursor);
		double t; IntersectionTest(P, (Vf - P).unitvec(), &t, NULL);
		delta *= 0.0005 * t;
		if (abs(delta) < 0.1) delta = delta < 0 ? -0.1 : 0.1;
		if (abs(delta) > 1000) delta = delta < 0 ? -1000 : 1000;
		vec3 SI = (Vf - P).unitvec();
		vec3 dr = (V - P).unitvec();
		P += delta * (V - P).unitvec();
		vec3 nSI = (Vf - P).unitvec();
		mat3 M; M.rotate_z(asin(det(nSI.xy().unitvec(), SI.xy().unitvec())));
		SI = M * SI; M.rotate(cross(SI, nSI), acos(dot(SI, nSI)));
		dr = M * dr;
		if (IntersectionTest(P, dr, &t, NULL)) V = P + t * dr;


		CalcScreen();
		render(); return 0;
	}
#pragma endregion
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}


int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
	const wchar_t CLASS_NAME[] = _T(APPLICATION_NAME);
	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = CLASS_NAME;
	if (!RegisterClassEx(&wc)) return -1;

	HWND hWnd = CreateWindowEx(
		0,
		CLASS_NAME,
		CLASS_NAME,
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		640, 400,
		NULL, NULL, hInstance, NULL
	);
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	return (int)message.wParam;
}


