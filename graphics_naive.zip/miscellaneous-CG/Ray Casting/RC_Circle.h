#pragma once

#ifndef _INC_RC_BASIC
#include "RC_basic.h"
#endif

class RT_Circle : public RT_Object {
	double r2, d;
public:
	vec3 C, n; double r;
	virtual void init() {
		if (r < 0) r = -r;
		n /= n.mod(), r2 = r * r, d = -dot(C, n);
	}
	virtual void debug_output(wostream& os) const {
		os << "Translate(Rotate(Rotate(Surface(v*cos(u),v*sin(u),0,u,0,2*pi,v,0," << r << ")," << atan2(hypot(n.x, n.y), n.z) << ",xAxis)," << atan2(n.x, -n.y) << ",zAxis),Vector(" << C << "))";
	}

	RT_Circle(cv3ref C, cv3ref n, cdref r) :C(C), n(n), r(r) { init(); }
	RT_Circle(cv3ref C, cv3ref n, cdref r, vec3 col) :C(C), n(n), r(r) { this->col = col; init(); }
	RT_Circle(cv3ref C, cdref rx, cdref rz, cdref r) :C(C), r(r) { n = vec3(sin(rx)*sin(rz), -sin(rx)*cos(rz), cos(rx)); init(); }
	RT_Circle(cv3ref C, cdref rx, cdref rz, cdref r, vec3 col) :C(C), r(r) { n = vec3(sin(rx)*sin(rz), -sin(rx)*cos(rz), cos(rx)); this->col = col; init(); }
	RT_Circle(const RT_Circle &other) : C(other.C), n(other.n), r(other.r) { col = other.col; init(); }
	RT_Circle& operator = (const RT_Circle &other) { C = other.C, n = other.n, r = other.r, col = other.col; init(); return *this; }
	~RT_Circle() {}

	virtual RT_BBox getMaxMin() const {
		double rx = atan2(hypot(n.x, n.y), n.z), rz = atan2(n.x, -n.y);
		RT_BBox R;
		double t = -atan(cos(rx)*tan(rz));
		R.Min.x = cos(rz)*cos(t) - cos(rx)*sin(rz)*sin(t);
		t += PI; R.Max.x = cos(rz)*cos(t) - cos(rx)*sin(rz)*sin(t);
		t = atan(cos(rx) / tan(rz));
		R.Min.y = sin(rz)*cos(t) + cos(rx)*cos(rz)*sin(t);
		t += PI; R.Max.y = sin(rz)*cos(t) + cos(rx)*cos(rz)*sin(t);
		R.Min.z = -sin(rx), R.Max.z = sin(rx);
		R.init(); R.Max = R.Max*r + C, R.Min = R.Min*r + C; return R;
	}
	virtual bool intersect(cv3ref P, cv3ref d, double &t, vec3 &n) const {
		t = -(dot(this->n, P) + this->d) / dot(this->n, d); if (t < RT_EPSILON) return false;
		if ((P + t * d - C).sqr() > r2) return false;
		n = this->n; return true;
	}
};

