#pragma once

#ifndef _INC_RC_BASIC
#include "RC_basic.h"
#endif

// infinite large plane

class RT_Plane : public RT_Object {
	double d;
public:
	vec3 p, n;
	virtual void init() {
		n /= n.mod(); d = -dot(p, n);		// ax+by+cz+d=0
	}
	virtual void debug_output(wostream& os) const {
		os << "PerpendicularPlane(" << p << ",Vector(" << n << "))";
	}

	RT_Plane(cdref d) :p(0, 0, d), n(0, 0, 1) { init(); }
	RT_Plane(cdref d, vec3 col) :p(0, 0, d), n(0, 0, 1) { this->col = col; init(); }
	RT_Plane(cv3ref p, cv3ref n) :p(p), n(n) { init(); }
	RT_Plane(cv3ref p, cv3ref n, vec3 col) :p(p), n(n) { this->col = col; init(); }
	RT_Plane(cv3ref A, cv3ref B, cv3ref C) :p(A), n(cross(B - A, C - A)) { init(); }
	RT_Plane(cv3ref A, cv3ref B, cv3ref C, vec3 col) :p(A), n(cross(B - A, C - A)) { this->col = col; init(); }
	RT_Plane(const RT_Plane &other) :p(other.p), n(other.n) { col = other.col; init(); }
	RT_Plane& operator = (const RT_Plane &other) { p = other.p, n = other.n, col = other.col; init(); }
	~RT_Plane() {}

	virtual RT_BBox getMaxMin() const {
		return RT_BBox(vec3(abs(n.y) < RT_EPSILON && abs(n.z) < RT_EPSILON ? p.x : -INFINITY, abs(n.x) < RT_EPSILON && abs(n.z) < RT_EPSILON ? p.y : -INFINITY, abs(n.x) < RT_EPSILON && abs(n.y) < RT_EPSILON ? p.z : -INFINITY),
			vec3(abs(n.y) < RT_EPSILON && abs(n.z) < RT_EPSILON ? p.x : INFINITY, abs(n.x) < RT_EPSILON && abs(n.z) < RT_EPSILON ? p.y : INFINITY, abs(n.x) < RT_EPSILON && abs(n.y) < RT_EPSILON ? p.z : INFINITY));
	}
	virtual bool intersect(cv3ref P, cv3ref d, double &t, vec3 &n) const {
		t = -(dot(this->n, P) + this->d) / dot(this->n, d); if (t < RT_EPSILON) return false;
		n = this->n; return true;
	}
};

