#pragma once

#include "RC_basic.h"


double sd_Circle(double r, cv2ref P) {
	return P.mod() - r;
}

double sd_Segment(vec2 V1, vec2 V2, cv2ref P) {
	double t = dot(V2 - V1, P - V1);
	if (t < 0) return (P - V1).mod();
	if (t > (V2 - V1).sqr()) return (P - V2).mod();
	return abs(det((V2 - V1).unitvec(), P - V1));
}

double sd_Box(vec2 Min, vec2 Max, cv2ref P) {	// order doesn't matter
	if (P.x > Min.x == P.x < Max.x) {
		if (P.y > Min.y == P.y < Max.y) {
			return -min(min(abs(P.x - Min.x), abs(P.x - Max.x)), min(abs(P.y - Min.y), abs(P.y - Max.y)));
		}
		return min(abs(P.y - Min.y), abs(P.y - Max.y));
	}
	else if (P.y > Min.y == P.y < Max.y) return min(abs(P.x - Min.x), abs(P.x - Max.x));
	return min(min((P - Min).mod(), (P - Max).mod()), min((P - vec2(Min.x, Max.y)).mod(), (P - vec2(Max.x, Min.y)).mod()));
}

double sd_Triangle(vec2 A, vec2 B, vec2 C, cv2ref P) {
	A -= P, B -= P, C -= P;
	//if (((det(A, B) > 0) + (det(B, C) > 0) + (det(C, A) > 0)) % 3) {		// outside
	if (((A.x*B.y > B.x*A.y) + (B.x*C.y > C.x*B.y) + (C.x*A.y > A.x*C.y)) % 3) {		// outside
		double t, m, d = INFINITY, td;
		t = dot(A - B, A), m = (B - A).sqr(); if (t > 0 && t < m) d = abs(det(A, B - A)) / sqrt(m);
		t = dot(B - C, B), m = (C - B).sqr(); if (t > 0 && t < m) { td = abs(det(B, C - B)) / sqrt(m); if (td < d) d = td; }
		t = dot(C - A, C), m = (A - C).sqr(); if (t > 0 && t < m) { td = abs(det(C, C - A)) / sqrt(m); if (td < d) d = td; }
		td = A.mod(); if (td < d) d = td;
		td = B.mod(); if (td < d) d = td;
		td = C.mod(); if (td < d) d = td;
		return d;
	}
	else {	// inside
		double d = abs(det(A, (B - A).unitvec()));
		double td = abs(det(B, (C - B).unitvec())); if (td < d) d = td;
		td = abs(det(C, (A - C).unitvec())); if (td < d) d = td;
		return -d;
	}
}

double sd_RegularPolygon(double r, int N, cv2ref P) {	// first vertex at (0,r)
	double ang = 2 * PI / N;
	double rang = atan(P.x / P.y); if (P.y < 0) rang += P.x > 0 ? PI : -PI;
	double a = rang - ang * int(rang / ang); if (a < 0) a += ang;
	vec2 p = P.mod() * vec2(cos(a), sin(a)) - vec2(r, 0), e = r * vec2(cos(ang) - 1, sin(ang));
	a = dot(p, e);
	if (a < 0) return p.mod(); if (a > e.sqr()) return (p - e).mod();
	return det(p, e.unitvec());
}

double sd_RegularStar(double R, double r, int N, cv2ref P) {	// 0<r<R, first vertex at (0,R)
	double ang = 2 * PI / N;
	double rang = atan(P.x / P.y); if (P.y < 0) rang += P.x > 0 ? PI : -PI;
	double a = rang - ang * int(rang / ang); if (a < 0) a += ang;
	if (a > 0.5*ang) a = ang - a; ang /= 2;
	vec2 p = P.mod() * vec2(cos(a), sin(a)) - vec2(R, 0), e = r * vec2(cos(ang), sin(ang)) - vec2(R, 0);
	a = dot(p, e);
	if (a < 0) return p.mod();
	if (a > e.sqr()) return P.mod() < r ? -(p - e).mod() : (p - e).mod();
	return det(p, e.unitvec());
}

double sd_Sector(double r, double ang, cv2ref P) {	// centered at origin, range [-ang, ang], 0<ang<π
	double a = atan(P.y / P.x); if (P.x < 0) a += P.y > 0 ? PI : -PI; a = abs(a) - ang;
	double sd = P.mod();
	if (a < 0) {
		if (sd > r) return sd - r;
		if (a > -PI / 2) sd = max(sd - r, sd*sin(a));
		else sd = max(sd - r, -sd);
		return sd;
	}
	if (a > PI / 2) return sd;
	if (sd*cos(a) < r) return sd * sin(a);
	return sqrt(sd*sd + r * r - 2 * r*sd*cos(a));
}

double sd_Arc(double r, double ang, cv2ref P) {	// centered at origin, range [-ang, ang], 0<ang<π
	double a = atan(P.y / P.x); if (P.x < 0) a += P.y > 0 ? PI : -PI; a = abs(a) - ang;
	double sd = P.mod(); if (a < 0) return abs(sd - r);
	return vec2(P.x - r * cos(ang), abs(P.y) - r * sin(ang)).mod();
}

double sd_Ellipse(double a, double b, cv2ref P) {	// a,b > 0
	// see http://iquilezles.org/www/articles/ellipsedist/ellipsedist.htm, solve a quartic equation
	vec2 p(abs(P.x), abs(P.y)); if (p.x > p.y) swap(p.x, p.y), swap(a, b);
	double l = b * b - a * a;
	double m = a * p.x / l, m2 = m * m;
	double n = b * p.y / l, n2 = n * n;
	double c = (m2 + n2 - 1.0) / 3.0, c3 = c * c * c;
	double q = c3 + m2 * n2*2.0;
	double d = c3 + m2 * n2;
	double g = m + m * n2;
	double co;
	if (d < 0) {
		double p = acos(q / c3) / 3.0;
		double s = cos(p);
		double t = sin(p)*sqrt(3.0);
		double rx = sqrt(-c * (s + t + 2.0) + m2);
		double ry = sqrt(-c * (s - t + 2.0) + m2);
		co = (ry + (l > 0 ? rx : -rx) + abs(g) / (rx*ry) - m) / 2.0;
	}
	else {
		double h = 2.0*m*n*sqrt(d);
		//double s = cbrt(q + h);
		//double u = cbrt(q - h);
		double s = q + h > 0 ? pow(q + h, 1. / 3) : -pow(-q - h, 1. / 3);
		double u = q > h ? pow(q - h, 1. / 3) : -pow(h - q, 1. / 3);
		double rx = -s - u - c * 4.0 + 2.0*m2;
		double ry = (s - u)*sqrt(3.0);
		double rm = sqrt(rx*rx + ry * ry);
		double p = ry / sqrt(rm - rx);
		co = (p + 2.0*g / rm - m) / 2.0;
	}
	vec2 closestPoint = vec2(a*co, b*sqrt(1.0 - co * co));
	double sd = (closestPoint - p).mod();
	if (p.y > closestPoint.y) return sd;
	return -sd;
}

double sd_Polygon(const vec2 *v, int N, cv2ref p) {
	double d = dot(p - v[0], p - v[0]);
	bool sgn = 0;
	vec2 e, w, b; double c;
	for (int i = 0, j = N - 1; i < N; j = i++) {
		e = v[j] - v[i];
		w = p - v[i];
		c = dot(w, e) / e.sqr();
		b = c < 0 ? w : c > 1 ? w - e : w - e * c;
		d = min(d, b.sqr());
		if (e.y < 0) e.y = -e.y, w.y = -w.y;
		if (w.y > 0 && w.y < e.y && (w.y*e.x / e.y > w.x)) sgn ^= 1;
	}
	return sgn ? -sqrt(d) : sqrt(d);
}
inline double sd_Polygon(initializer_list<vec2> v, cv2ref p) {
	return sd_Polygon(v.begin(), v.size(), p);
}

double sd_Bezier2(vec2 A, vec2 B, vec2 C, cv2ref P) {
	vec2 C2 = A - 2 * B + C, C1 = 2 * (B - A), C0 = A - P;
	double t = 2 * dot(C2, C2)
		, a = 3 * dot(C2, C1) / t, b = (2 * dot(C2, C0) + dot(C1, C1)) / t, c = dot(C1, C0) / t;
	double a2 = a * a, p = (-a2 / 3 + b) / 3, q = (a*a2 / 13.5 - a * b / 3 + c) / 2;
	double p3 = p * p*p, delta = q * q + p3;
	if (delta > 0) {
		delta = sqrt(delta);
		//t = cbrt(delta - q) - cbrt(delta + q) - a / 3;
		t = (delta > q ? pow(delta - q, 1. / 3) : -pow(q - delta, 1. / 3)) - (delta + q > 0 ? pow(delta + q, 1. / 3) : -pow(-delta - q, 1. / 3)) - a / 3;
		return t > 1 ? (P - C).mod() : t < 0 ? C0.mod() : ((C2*t + C1)*t + C0).mod();
	}
	else {
		q = acos(-q / sqrt(-p3)) / 3, p = 2 * sqrt(-p), a /= 3;
		t = p * cos(q) - a;
		double sd = t > 1 ? (P - C).sqr() : t < 0 ? C0.sqr() : ((C2*t + C1)*t + C0).sqr();
		t = -p * cos(q + PI / 3) - a;
		sd = min(sd, t > 1 ? (P - C).sqr() : t < 0 ? C0.sqr() : ((C2*t + C1)*t + C0).sqr());
		t = -p * cos(q - PI / 3) - a;
		sd = min(sd, t > 1 ? (P - C).sqr() : t < 0 ? C0.sqr() : ((C2*t + C1)*t + C0).sqr());
		return sqrt(sd);
	}
}

double sd_Spline3(vec2 C3, vec2 C2, vec2 C1, vec2 C0, cv2ref P) {	// C3 t³ + C2 t² + C1 t + C0,  0 < t < 1
	C0 -= P;
	double c[6] = { dot(C0,C1), 2 * dot(C0,C2) + C1.sqr(), 3 * (dot(C0,C3) + dot(C1,C2)), 2 * C2.sqr() + 4 * dot(C1,C3), 5 * dot(C2,C3), 3 * C3.sqr() };
	double r[5]; int n = solveQuintic(c, r);
	double sd = INFINITY;
	for (int i = 0; i < n; i++) {
		sd = min(sd, r[i] < 0 ? C0.mod() : r[i]>1 ? (C3 + C2 + C1 + C0).mod() : (((C3*r[i] + C2)*r[i] + C1)*r[i] + C0).mod());
	}
	return sd;
}
inline double sd_Bezier3(cv2ref A, cv2ref B, cv2ref C, cv2ref D, cv2ref P) {
	return sd_Spline3(-A + 3 * B - 3 * C + D, 3 * A - 6 * B + 3 * C, -3 * A + 3 * B, A, P);
}
inline double sd_Hermite(cv2ref P1, cv2ref P2, cv2ref V1, cv2ref V2, cv2ref P) {
	return sd_Spline3(2 * P1 - 2 * P2 + V1 + V2, -3 * P1 + 3 * P2 - 2 * V1 - V2, V1, P1, P);
}
inline double sd_CatmullRom(cv2ref A, cv2ref B, cv2ref C, cv2ref D, cv2ref P) {
	return sd_Spline3(-0.5*A + 1.5*B - 1.5*C + 0.5*D, A - 2.5*B + 2 * C - 0.5*D, -0.5*A + 0.5*C, B, P);
}






// boolean operations, incontinous bound
inline double sd_OpUnion(cdref sd1, cdref sd2) { return min(sd1, sd2); }
inline double sd_OpIntersect(cdref sd1, cdref sd2) { return max(sd1, sd2); }
inline double sd_OpSubtract(cdref sd1, cdref sd2) { return max(sd1, -sd2); }
inline double sd_OpComplement(cdref sd) { return -sd; }

// implementions of smoothed boolean operations: see https://www.iquilezles.org/www/articles/smin/smin.htm
// r: effect radius;  cp: component of coordinate of vertex;  cr: curvature radius on vertex
// gradient ↓

// exponential smoothed boolean operations: cp=ln2/k, cr=rt2/k
inline double sd_OpSmoothedUnion_exp(cdref sd1, cdref sd2, double k) {
	double r = exp(-k * sd1) + exp(-k * sd2);
	if (r < 1e-200) return min(sd1, sd2);
	return -log(r) / k;
}
inline double sd_OpSmoothedIntersect_exp(cdref sd1, cdref sd2, double k) {
	double r = exp(k * sd1) + exp(k * sd2);
	if (r > 1e+200) return max(sd1, sd2);
	return log(r) / k;
}
inline double sd_OpSmoothedSubtract_exp(cdref sd1, cdref sd2, double k) {
	double r = exp(k * sd1) + exp(-k * sd2);
	if (r > 1e+200) return max(sd1, -sd2);
	return log(r) / k;
}

// C1 continuety; r=k, cp=k/4, cr=k/rt2
inline double sd_OpSmoothedUnion(cdref a, cdref b, cdref k) {
	double h = 0.5 + 0.5*(b - a) / k;
	if (h < 0) return b; if (h > 1) return a;
	return (1 - h)*b + h * a - k * h * (1 - h);
}
inline double sd_OpSmoothedIntersect(cdref a, cdref b, cdref k) {
	double h = 0.5 - 0.5*(b - a) / k;
	if (h < 0) return b; if (h > 1) return a;
	return (1 - h)*b + h * a + k * h * (1 - h);
}
inline double sd_OpSmoothedSubtract(cdref a, cdref b, cdref k) {
	double h = 0.5 - 0.5*(b + a) / k;
	if (h < 0) return a; if (h > 1) return -b;
	return (1 - h)*a - h * b + k * h * (1 - h);
}

// Cn continuety: r=k
inline double sd_OpSmoothedUnion_1(cdref a, cdref b, cdref k) {
	double h = 1 - abs(a - b) / k; if (h < 0) return min(a, b);
	return min(a, b) - 0.25 * h * h * k;
}
inline double sd_OpSmoothedIntersect_1(cdref a, cdref b, cdref k) {
	double h = 1 - abs(a - b) / k; if (h < 0) return max(a, b);
	return max(a, b) + 0.25 * h * h * k;
}
inline double sd_OpSmoothedSubtract_1(cdref a, cdref b, cdref k) {
	double h = 1 - abs(a + b) / k; if (h < 0) return max(a, -b);
	return max(a, -b) + 0.25 * h * h * k;
}
inline double sd_OpSmoothedUnion_2(cdref a, cdref b, cdref k) {
	double h = 1 - abs(a - b) / k; if (h < 0) return min(a, b);
	return min(a, b) - 1. / 6 * h * h * h * k;
}
inline double sd_OpSmoothedIntersect_2(cdref a, cdref b, cdref k) {
	double h = 1 - abs(a - b) / k; if (h < 0) return max(a, b);
	return max(a, b) + 1. / 6 * h * h * h * k;
}
inline double sd_OpSmoothedSubtract_2(cdref a, cdref b, cdref k) {
	double h = 1 - abs(a + b) / k; if (h < 0) return max(a, -b);
	return max(a, -b) + 1. / 6 * h * h * h * k;
}


inline double sd_OpRound(cdref sd, cdref r) {	// exact
	return sd - r;
}
inline double sd_OpOnion(cdref sd, cdref r) {	// exact
	return abs(sd) - r;
}





// not recommand calling these functions: manually write them inline

inline double sd_OpTranslate(double(*sd)(vec2), vec2 d, cv2ref P) {
	return sd(P - d);
}
inline double sd_OpRotate(double(*sd)(vec2), double a, cv2ref P) {
	double c = cos(a), s = sin(a);
	return sd(vec2(c*P.x + s * P.y, -s * P.x + c * P.y));
}
inline double sd_OpScale(double(*sd)(vec2), double s, cv2ref P) {
	return s * sd(P / s);
}
inline double sd_OpSymmetry(double(*sd)(vec2), double s, cv2ref P) {	// about y axis
	return sd(vec2(-P.x, P.y));
}


// split at origin and move apart;  sometimes grad ↓
// for best effect, make sure the shape is symmetrical and centered at origin
inline double sd_OpElongation(double(*sd)(vec2), double x, double y, cv2ref P) {
	if (abs(P.x) <= x && abs(P.y) <= y) {
		double d = sd(vec2(0, 0));
		if (d < 0) return d - min(x - abs(P.x), y - abs(P.y));
		return d + min(x - abs(P.x), y - abs(P.y));
	}
	if (P.x > x && P.y > y) return sd(vec2(P.x - x, P.y - y));
	if (P.x > x && P.y < -y) return sd(vec2(P.x - x, P.y + y));
	if (P.x < -x && P.y > y) return sd(vec2(P.x + x, P.y - y));
	if (P.x < -x && P.y < -y) return sd(vec2(P.x + x, P.y + y));
	if (abs(P.x) <= x) return P.y < 0 ? sd(vec2(0, P.y + y)) : sd(vec2(0, P.y - y));
	if (abs(P.y) <= y) return P.x < 0 ? sd(vec2(P.x + x, 0)) : sd(vec2(P.x - x, 0));
}

