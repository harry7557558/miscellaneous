#pragma once


#ifndef _INC_RC_BASIC

#define _INC_RC_BASIC



#include "C:\Users\harry\Desktop\Test\Test\3D.h"


#pragma region Root Finder

int SolveQuadric(const double *c, double *s)
{
	double p = c[1] / (2 * c[2]), D = p * p - c[0] / c[2];
	if (D < 0) return 0;
	else {
		D = sqrt(D);
		s[0] = D - p, s[1] = -D - p;
		return 2;
	}
}

int SolveCubic(const double *c, double *s)
{
	int num;

	/* normal form: x^3 + Ax^2 + Bx + C = 0 */

	double A = c[2] / c[3], B = c[1] / c[3], C = c[0] / c[3];

	/*  substitute x = y - A/3 to eliminate quadric term:
	x^3 +px + q = 0 */

	double A2 = A * A,
		p = (-A2 / 3 + B) / 3,
		q = (A * A2 / 13.5 - A * B / 3 + C) / 2;

	/* use Cardano's formula */

	double p3 = p * p * p, D = q * q + p3;

	if (D < 0) {
		q = acos(-q / sqrt(-p3)) / 3;
		p = 2 * sqrt(-p);
		s[0] = p * cos(q);
		s[1] = -p * cos(q + PI / 3);
		s[2] = -p * cos(q - PI / 3);
		num = 3;
	}
	else {
		D = sqrt(D);
		s[0] = cbrt(D - q) - cbrt(D + q);
		num = 1;
	}

	A /= 3;
	for (int i = 0; i < num; i++) s[i] -= A;

	return num;
}

int SolveQuartic(const double *c, double *s)
{
	int num;

	/* normal form: x^4 + Ax^3 + Bx^2 + Cx + D = 0 */

	double A = c[3] / c[4], B = c[2] / c[4], C = c[1] / c[4], D = c[0] / c[4];

	/*  substitute x = y - A/4 to eliminate cubic term:
	x^4 + px^2 + qx + r = 0 */

	double A2 = A * A,
		p = -3.0 / 8 * A2 + B,
		q = A2 * A / 8 - A * B / 2 + C,
		r = -3.0 / 256 * A2*A2 + A2 * B / 16 - A * C / 4 + D;

	/* solve the resolvent cubic ... */

	double coeffs[4] = { r * p / 2 - q * q / 8, -r, -0.5 * p, 1 };

	SolveCubic(coeffs, s);
	double z = s[0];

	/* ... and take the one real solution to build two quadric equations */

	double u = z * z - r, v = 2 * z - p;
	if (u > 0) u = sqrt(u); else return 0;
	if (v > 0) v = sqrt(v); else return 0;

	coeffs[0] = z - u;
	coeffs[1] = q < 0 ? -v : v;
	coeffs[2] = 1;

	num = SolveQuadric(coeffs, s);

	coeffs[0] = z + u;
	coeffs[1] = q < 0 ? v : -v;
	coeffs[2] = 1;

	num += SolveQuadric(coeffs, s + num);

	/* resubstitute */

	A /= 4;
	for (int i = 0; i < num; i++) s[i] -= A;

	return num;
}

int solveQuintic(const double *cof, double *rt)
{
	// x^5 + B x^4 + C x^3 + D x^2 + E x + F = 0
	double B = cof[4] / cof[5], C = cof[3] / cof[5], D = cof[2] / cof[5], E = cof[1] / cof[5], F = cof[0] / cof[5];

	// Find one real root with Newton's iteration method
	double x = -0.2*B, u, v, dx;
	double a = 5, b = 4 * B, c = 3 * C, d = 2 * D, e = E;
	unsigned n = 0, N = 0; do {
		if (++n > 30) x = pick_random(-2, 2) - 0.2*B, n -= 30, N++;
		u = ((((x + B)*x + C)*x + D)*x + E)*x + F, v = (((a*x + b)*x + c)*x + d)*x + e;
		dx = u / v; x -= dx;
	} while (abs(dx) > 1e-8 && N < 2000);
	rt[0] = x;

	// Divide that root from polynomial
	c = B + x, d = x * c + C, e = x * d + D, F = x * e + E, E = e, D = d, C = c;

	// Solve the quartic equation
	double c4[5] = { F, E, D, C, 1 };
	return SolveQuartic(c4, rt + 1) + 1;
}

#pragma endregion modified from https://github.com/erich666/GraphicsGems/blob/master/gems/Roots3And4.c


#define RT_EPSILON 1e-8




inline vec3 PMax(cv3ref P, cv3ref Q) { return vec3(max(P.x, Q.x), max(P.y, Q.y), max(P.z, Q.z)); }
inline vec3 PMin(cv3ref P, cv3ref Q) { return vec3(min(P.x, Q.x), min(P.y, Q.y), min(P.z, Q.z)); }

class RT_BBox {
public:
	vec3 Min, Max;
	void init() {
		if (Min.x > Max.x) swap(Min.x, Max.x);
		if (Min.y > Max.y) swap(Min.y, Max.y);
		if (Min.z > Max.z) swap(Min.z, Max.z);
	}

	RT_BBox() { Min = vec3(-INFINITY, -INFINITY, -INFINITY), Max = vec3(INFINITY, INFINITY, INFINITY); }
	RT_BBox(cv3ref Min, cv3ref Max) :Min(Min), Max(Max) { init(); }
	RT_BBox(const RT_BBox &other) :Min(other.Min), Max(other.Max) { init(); }
	RT_BBox& operator = (const RT_BBox &other) { Min = other.Min, Max = other.Max; init(); return *this; }
	~RT_BBox() {}

	bool intersect(cv3ref P, cv3ref d) const {
		double tmin, tmax, tymin, tymax, tzmin, tzmax;
		tmin = ((d.x < 0 ? Max.x : Min.x) - P.x) / d.x;
		tmax = ((d.x < 0 ? Min.x : Max.x) - P.x) / d.x;
		tymin = ((d.y < 0 ? Max.y : Min.y) - P.y) / d.y;
		tymax = ((d.y < 0 ? Min.y : Max.y) - P.y) / d.y;
		if ((tmin > tymax) || (tymin > tmax)) return false;
		if (tymin > tmin) tmin = tymin;
		if (tymax < tmax) tmax = tymax;
		tzmin = ((d.z < 0 ? Max.z : Min.z) - P.z) / d.z;
		tzmax = ((d.z < 0 ? Min.z : Max.z) - P.z) / d.z;
		if ((tmin > tzmax) || (tzmin > tmax)) return false;
		if (tzmin > tmin) tmin = tzmin;
		if (tzmax < tmax) tmax = tzmax;
		return tmax > 0;
	}

	friend RT_BBox Union(const RT_BBox &A, const RT_BBox &B) { return RT_BBox(PMin(A.Min, B.Min), PMax(A.Max, B.Max)); }
	void Union(const RT_BBox &B) { Min = PMin(Min, B.Min), Max = PMax(Max, B.Max); }

	void add(cv3ref P) {
		Min = PMin(P, Min), Max = PMax(P, Max); init();
	}
};



class RT_Object {
public:
	vec3 col;
	virtual void init() = 0 {}	// call this function after some values are manually modified
	virtual void debug_output(wostream& os) const = 0 {}
	virtual ~RT_Object() = 0 {}

	virtual RT_BBox getMaxMin() const = 0 {}
	virtual bool intersect(cv3ref P, cv3ref d, double &t, vec3 &n) const = 0 {}	// d unit vector,  Int = P + t d,  n unit normal
};






#endif	// _INC_RC_BASIC