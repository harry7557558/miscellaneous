#pragma once

#include "RC_basic.h"
#include "SDF_2D.h"

double SD_Sphere(double r, cv3ref P) {
	return P.mod() - r;
}

double SD_Segment(vec3 V1, vec3 V2, cv3ref P) {
	double t = dot(V2 - V1, P - V1);
	if (t < 0) return (P - V1).mod();
	if (t > (V2 - V1).sqr()) return (P - V2).mod();
	return cross((V2 - V1).unitvec(), P - V1).mod();
}

double SD_Box(vec3 B, cv3ref P) {
	vec3 d = vec3(abs(P.x), abs(P.y), abs(P.z)) - B;
	return vec3(max(d.x, 0), max(d.y, 0), max(d.z, 0)).mod() + min(max(d.x, max(d.y, d.z)), 0.0);
}

double SD_Torus(double R, double r, cv3ref P) {		// xOy
	double D = P.xy().mod() - R;
	return sqrt(D * D + P.z * P.z) - r;
}

double SD_Cylinder_z(double r, double min_z, double max_z, cv3ref P) {	// perpendicular to xOy, min_z<max_z
	double d = P.xy().mod() - r;
	if (P.z < max_z && P.z > min_z) return max(d, max(min_z - P.z, P.z - max_z));
	if (d < 0) return P.z > max_z ? P.z - max_z : min_z - P.z;
	return P.z > max_z ? sqrt(d*d + (P.z - max_z)*(P.z - max_z)) : sqrt(d*d + (P.z - min_z)*(P.z - min_z));
}
double SD_Cylinder(vec3 V1, vec3 V2, double r, cv3ref P) {
	vec3 dr = V2 - V1; double h = dr.mod(); dr /= h;
	double t = dot(dr, P - V1), d = cross(P - V1, dr).mod() - r;
	if (t < 0) {
		if (d > 0) return sqrt(d * d + t * t);
		return -t;
	}
	if (t > h) {
		t -= h;
		if (d > 0) return sqrt(d * d + t * t);
		return t;
	}
	if (d > 0) return d;
	return max(max(-t, t - h), d);
}
double SD_Cylinder(vec3 C, vec3 dir, double r, double h, cv3ref P) {	// dir unit vectors
	C -= P;
	double t = -dot(dir, C);
	double d = cross(C, dir).mod() - r;
	if (t < 0) {
		if (d > 0) return sqrt(d * d + t * t);
		return -t;
	}
	if (t > h) {
		t -= h;
		if (d > 0) return sqrt(d * d + t * t);
		return t;
	}
	if (d > 0) return d;
	return max(max(-t, t - h), d);
}

double SD_Cone(vec3 C, vec3 dir, double r, double h, cv3ref P) {	// dir unit vector,  h,r > 0
	C -= P;
	double t = -dot(dir, C);
	double d = cross(C, dir).mod();
	if (t > h) {
		if (d < r) return t - h;
		d -= r, t -= h; return sqrt(d * d + t * t);
	}
	if (t < 0) {
		if (r * d + h * t < 0) return sqrt(d * d + t * t);
		return (h * d - r * t) / sqrt(h * h + r * r);
	}
	if (r * (d - r) + h * (t - h) > 0) {
		d -= r, t -= h; return sqrt(d * d + t * t);
	}
	d = (h * d - r * t) / sqrt(h * h + r * r);
	if (d > 0) return d;
	return max(d, t - h);
}

double SD_Ellipsoid(double xy, double z, cv3ref P) {	// exact, rotating ellipse
	return sd_Ellipse(xy, z, vec2(P.xy().mod(), P.z));
}
double SD_Ellipsoid(double a, double b, double c, cv3ref P) {	// seems no analytic result
	// See this: https://www.iquilezles.org/www/articles/ellipsoids/ellipsoids.htm
	return NAN;
}
double SD_Ellipsoid_fast(double a, double b, double c, cv3ref P) {	// not exact, problem occurs inside and far outside
	double k0 = vec3(P.x / a, P.y / b, P.z / c).mod();
	double k1 = vec3(P.x / (a*a), P.y / (b*b), P.z / (c*c)).mod();
	return k0 * (k0 - 1) / k1;
}

double SD_Bezier2(vec3 A, vec3 B, vec3 C, cv3ref P) {
	vec3 C2 = A - 2 * B + C, C1 = 2 * (B - A), C0 = A - P;
	double t = 2 * dot(C2, C2)
		, a = 3 * dot(C2, C1) / t, b = (2 * dot(C2, C0) + dot(C1, C1)) / t, c = dot(C1, C0) / t;
	double a2 = a * a, p = (-a2 / 3 + b) / 3, q = (a*a2 / 13.5 - a * b / 3 + c) / 2;
	double p3 = p * p*p, delta = q * q + p3;
	if (delta > 0) {
		delta = sqrt(delta);
		t = (delta > q ? pow(delta - q, 1. / 3) : -pow(q - delta, 1. / 3)) - (delta + q > 0 ? pow(delta + q, 1. / 3) : -pow(-delta - q, 1. / 3)) - a / 3;
		return t > 1 ? (P - C).mod() : t < 0 ? C0.mod() : ((C2*t + C1)*t + C0).mod();
	}
	else {
		q = acos(-q / sqrt(-p3)) / 3, p = 2 * sqrt(-p), a /= 3;
		t = p * cos(q) - a;
		double sd = t > 1 ? (P - C).sqr() : t < 0 ? C0.sqr() : ((C2*t + C1)*t + C0).sqr();
		t = -p * cos(q + PI / 3) - a;
		sd = min(sd, t > 1 ? (P - C).sqr() : t < 0 ? C0.sqr() : ((C2*t + C1)*t + C0).sqr());
		t = -p * cos(q - PI / 3) - a;
		sd = min(sd, t > 1 ? (P - C).sqr() : t < 0 ? C0.sqr() : ((C2*t + C1)*t + C0).sqr());
		return sqrt(sd);
	}
}

double SD_Spline3(vec3 C3, vec3 C2, vec3 C1, vec3 C0, cv3ref P) {	// C3 t³ + C2 t² + C1 t + C0,  0 < t < 1
	C0 -= P;
	double c[6] = { dot(C0,C1), 2 * dot(C0,C2) + C1.sqr(), 3 * (dot(C0,C3) + dot(C1,C2)), 2 * C2.sqr() + 4 * dot(C1,C3), 5 * dot(C2,C3), 3 * C3.sqr() };
	double r[5]; int n = solveQuintic(c, r);
	double sd = INFINITY;
	for (int i = 0; i < n; i++) {
		sd = min(sd, r[i] < 0 ? C0.mod() : r[i]>1 ? (C3 + C2 + C1 + C0).mod() : (((C3*r[i] + C2)*r[i] + C1)*r[i] + C0).mod());
	}
	return sd;
}
inline double SD_Bezier3(cv3ref A, cv3ref B, cv3ref C, cv3ref D, cv3ref P) {
	return SD_Spline3(-A + 3 * B - 3 * C + D, 3 * A - 6 * B + 3 * C, -3 * A + 3 * B, A, P);
}
inline double sd_Hermite(cv3ref P1, cv3ref P2, cv3ref V1, cv3ref V2, cv3ref P) {
	return SD_Spline3(2 * P1 - 2 * P2 + V1 + V2, -3 * P1 + 3 * P2 - 2 * V1 - V2, V1, P1, P);
}
inline double sd_CatmullRom(cv3ref A, cv3ref B, cv3ref C, cv3ref D, cv3ref P) {
	return SD_Spline3(-0.5*A + 1.5*B - 1.5*C + 0.5*D, A - 2.5*B + 2 * C - 0.5*D, -0.5*A + 0.5*C, B, P);
}







double SD_OpExtrusion(double(*sd)(vec2), double h, cv3ref P) {	// exact, extrude toward z-axis
	double d = sd(P.xy());
	if (P.z >= 0 && P.z <= h) return d > 0 ? d : max(d, max(-P.z, P.z - h));
	if (P.z > h) return d > 0 ? sqrt(d*d + (P.z - h)*(P.z - h)) : P.z - h;
	if (P.z < 0) return d > 0 ? sqrt(d*d + P.z*P.z) : -P.z;
}

double SD_OpRevolution(double(*sd)(vec2), double d, cv3ref P) {	// exact, axis x=-d becomes revolution axis (z-axis)
	return sd(vec2(P.xy().mod() - d, P.z));
}

double SD_OpRevolution(double(*sd)(vec2), double d, double ang, cv3ref P) {		// rotate an angle(0-π), revolute from right to both sides, exact
	double a = atan(P.y / P.x); if (P.x < 0) a += P.y > 0 ? PI : -PI; a = abs(a) - ang;
	double s = sd(vec2(P.xy().mod() - d, P.z));
	double m = P.xy().mod(), n = m * sin(a);
	if (a < 0) {
		if (s > 0) return s;
		if (sd(vec2(m*cos(a) - d, P.z)) < 0) return max(s, n);
		return s;
	}
	s = sd(vec2(m*cos(a) - d, P.z));
	if (s < 0) return n;
	return sqrt(s*s + n * n);
}

double SD_OpSwept_Bezier2(double(*sd)(vec2), vec3 A, vec3 B, vec3 C, cv3ref P) {
	vec3 C2 = A - 2 * B + C, C1 = 2 * (B - A), C0 = A - P;
	double t;
	{
		t = 2 * dot(C2, C2);
		double a = 3 * dot(C2, C1) / t, b = (2 * dot(C2, C0) + dot(C1, C1)) / t, c = dot(C1, C0) / t;
		double a2 = a * a, p = (-a2 / 3 + b) / 3, q = (a*a2 / 13.5 - a * b / 3 + c) / 2;
		double p3 = p * p*p, delta = q * q + p3;
		if (delta > 0) {
			delta = sqrt(delta);
			t = (delta > q ? pow(delta - q, 1. / 3) : -pow(q - delta, 1. / 3)) - (delta + q > 0 ? pow(delta + q, 1. / 3) : -pow(-delta - q, 1. / 3)) - a / 3;
		}
		else {
			q = acos(-q / sqrt(-p3)) / 3, p = 2 * sqrt(-p), a /= 3;
			t = p * cos(q) - a;
			double sd = t > 1 ? (P - C).sqr() : t < 0 ? C0.sqr() : ((C2*t + C1)*t + C0).sqr();
			double tt = -p * cos(q + PI / 3) - a;
			if (tt > 0 && tt < 1 && (c = ((C2*tt + C1)*tt + C0).sqr()) < sd) t = tt, sd = c;
			tt = -p * cos(q - PI / 3) - a;
			if (tt > 0 && tt < 1 && ((C2*tt + C1)*tt + C0).sqr() < sd) t = tt;
		}
	}

	vec3 T = 2 * C2 + C1;
	double rz = atan2(T.x, -T.y), rx = atan2(sqrt(T.x*T.x + T.y*T.y), T.z);


	return (t > 1 ? (P - C).mod() : t < 0 ? C0.mod() : ((C2*t + C1)*t + C0).mod()) - 0.1;
}



