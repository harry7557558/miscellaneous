
#pragma warning(disable:4244 4018 4010 4305)

#include <Windows.h>
#include <windowsx.h>
#include <tchar.h>

using namespace std;

#include <chrono>
typedef chrono::high_resolution_clock NTime;
typedef chrono::duration<double> fsec;

#include "SDF_3D.h"

#include <string>
#include <vector>

#define WIN_NAME " SDF 3D"

HWND HWnd;
int clt_w, clt_h;
COLORREF *img; HBITMAP HImg;



#define Visualize_3D

#ifdef Visualize_3D

vec3 Pos(5, 5, 3), prevPos;
double Unit = 500, dist = Pos.mod();
vec2 Cursor, prevCursor;

affine3 fromWorld;

typedef struct { vec3 O; vec3 A; vec3 B; } Screen;
Screen Scr;
inline vec3 fromScreen(double u, double v) {
	return Scr.O + u * Scr.A + v * Scr.B;
}

void recalc() {
	fromWorld.init();
	fromWorld.translate(-Pos);
	double rz = atan2(-Pos.x, Pos.y), rx = atan2(hypot(Pos.x, Pos.y), -Pos.z);
	fromWorld.rotate_z(-rz); fromWorld.rotate_x(PI - rx); fromWorld.rotate_z(PI);
	fromWorld.translate(0, 0, 1);
	fromWorld.perspective(-1);
	fromWorld.scale(Unit);
	fromWorld.translate(0.5*clt_w, 0.5*clt_h);
	mat3 M = RotationMatrix_zx(atan2(-Pos.x, Pos.y), atan2(hypot(Pos.x, Pos.y), -Pos.z));
	Scr.O = M * vec3(0.5*clt_w / Unit, -0.5*clt_h / Unit, 1), Scr.A = M * vec3(-clt_w / Unit, 0), Scr.B = M * vec3(0, clt_h / Unit);
	dist = Pos.mod();
}

const vec3 light = vec3(-0.3, 0.1, 1).unitvec();

#else	// Visualize_3D

vec2 Pos(0, 0), prevPos;
double Unit = 100, dist = Pos.mod();
vec2 Cursor, prevCursor;

bool renderGradient = false;

double cross_z = 0;

#endif	// Visualize_3D



// set sdf here
double scene(vec3 P) {
	P.z += 1;
	double sd = P.z;
	//sd = INFINITY;
	auto Mug = [](vec3 P) ->double {
		P.z -= 0.23;
		double cyl = SD_Cylinder_z(0.75, 0, 2, P);	// main body
		double sd = abs(cyl - 0.15) - 0.08;		// make annular
		sd = sd_OpSmoothedSubtract(sd, 1.8 - P.z, 0.08);	// opening
		double handle = SD_OpExtrusion([](vec2 p) {
			return abs(sd_Polygon({ vec2(0,0.9), vec2(0.4,0.9), vec2(0.3,0.35), vec2(0,0.1) }, p) - 0.2) - 0.05;
		}, 0.3, vec3(P.x - 1.03, P.z - 0.38, P.y + 0.15)) - 0.1;	// handle, rounded polygon
		handle = sd_OpSubtract(handle, cyl - 0.12);		// cut extra part of handle
		sd = sd_OpSmoothedUnion(sd, handle, 0.05);
		return sd;
	};
	auto Bottle = [](vec3 P)->double {
		return SD_OpRevolution([](vec2 p) ->double {
			double sd = sd_Segment(vec2(0, 0.1), vec2(0.75, 0), p);		// bottom
			sd = sd_OpSmoothedUnion(sd, sd_Segment(vec2(0.8, 0.05), vec2(0.8, 2.5), p), 0.1);	// lower side
			sd = sd_OpUnion(sd, sd_Bezier2(vec2(0.8, 2.5), vec2(0.8, 3.5), vec2(0.33, 4.1), p));	// curved part
			sd = sd_OpSmoothedUnion(sd, sd_Segment(vec2(0.33, 4.1), vec2(0.25, 5.7), p), 0.1);	// neck
			sd = sd_OpSmoothedUnion(sd, sd_Segment(vec2(0.25, 5.7), vec2(0.27, 5.7), p), 0.1);	// mouth
			return sd - 0.05;
		}, 0, P - vec3(0, 0, 0.1));
	};
	sd = min(sd, Mug(P));
	return sd;
}
double map(cv3ref P) {
	return scene(P);
	double sd = INFINITY;
	//vec3 A(-1, 0, -2), B(0, 1, 0), C(1, 0, 3), D(1, 1, 0);
	//sd = min(sd, SD_OpSwept_Bezier2([](vec2 p) { return sd_RegularPolygon(1, 4, p); }, A, B, C, P));
	return sd - 0.1;
	//return max(abs(abs(sd) - 0.3) - 0.1, P.z - 0.5);	// a nice way to check if sdf is correct
}



auto fps2str = [](double a)->string {	// float to string
	bool sgn = a < 0; a = abs(a);
	if (a < 1e-5) return "0";
	if (a > 9999 || isNaN(a)) return "###";
	int e = 3;
	while (a < 100) a *= 10, e--;
	string r;
	while (a != 0) r = char('0' + int(a) % 10) + r, a = int(a) / 10;
	while (e <= 0) r = '0' + r, e++;
	if (e < 3) r.insert(r.begin() + e, '.');
	if (sgn) r = "-" + r;
	return r;
};
auto int2str = [](unsigned i) -> string {
	string r;
	while (i) r = char('0' + i % 10) + r, i /= 10;
	return r;
};

#ifdef Visualize_3D

#define EPSILON 1e-4

#define MAX_STEP 1024
#define MAX_DIST 200


UINT64 total_ray = 0;

vec3 castRay(vec3 d) {	// return color
	total_ray++;

	// cast ray
	double t = 100 * EPSILON, dt;
	vec3 p = Pos + t * d;
	if (map(p) < 0) return vec3(0, 0, 0);
	for (int i = 0; i < MAX_STEP; i++) {
		dt = map(Pos + t * d);
		t += dt;
		if (dt < -EPSILON) return vec3(1, 0, 0);
		if (dt < EPSILON) break;
		if (dt > MAX_DIST) {
			t = max(dot(d, light), 0);
			return vec3(t, t, t);
		}
	}
	p = Pos + t * d;

	// calculate normal, see https://www.iquilezles.org/www/articles/normalsSDF/normalsSDF.htm
	double k_111 = map(vec3(p.x + EPSILON, p.y + EPSILON, p.z + EPSILON));
	double k_100 = map(vec3(p.x + EPSILON, p.y - EPSILON, p.z - EPSILON));
	double k_010 = map(vec3(p.x - EPSILON, p.y + EPSILON, p.z - EPSILON));
	double k_001 = map(vec3(p.x - EPSILON, p.y - EPSILON, p.z + EPSILON));
	vec3 n(k_111 + k_100 - k_010 - k_001, k_111 - k_100 + k_010 - k_001, k_111 - k_100 - k_010 + k_001);
	n /= 0.25*EPSILON; n /= n.mod();
	if (dot(n, d) > 0) n = -n;

	// calculate shadow, see https://www.iquilezles.org/www/articles/rmshadows/rmshadows.htm
	d -= 2 * dot(d, n)*n;
	double r = 1;
	t = 0.001;
	for (int i = 0; i < MAX_STEP; i++) {
		dt = map(p + t * light);
		r = min(r, 15 * dt / t);
		if (r < 0.001 || t > 2) break;
		t += Clamp(dt, 1, 2)*Clamp(dist / Unit, 0.002, 0.2);
	}
	r = Clamp(r, 0, 1);

	// final result
	double dif = dot(n, light); if (dif < 0) dif = 0;
	return (dif*r + 0.2*pow(max(dot(d, light), 0), 4))*vec3(0.87, 0.8, 0.7) + (0.5 - 0.5*dif)*vec3(0.1, 0.15, 0.25);
}


#include <thread>

void render() {
	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);

	recalc();
	total_ray = 0;

	// multithread rendering
	auto t0 = NTime::now();

	unsigned L = clt_w * clt_h;
	const unsigned MAX_THREADS = thread::hardware_concurrency();
	const unsigned ppt = 0x4000;
	const unsigned N = L / ppt;

	bool* fn = new bool[MAX_THREADS]; for (int i = 0; i < MAX_THREADS; i++) fn[i] = false;
	thread** T = new thread*[MAX_THREADS]; for (int i = 0; i < MAX_THREADS; i++) T[i] = NULL;

	unsigned released = 0, finished = 0;
	while (finished < N) {
		for (int i = 0; i < MAX_THREADS; i++) {
			if (fn[i]) {
				fn[i] = false;
				delete T[i]; T[i] = 0;
				if (++finished >= N) break;
			}
			if (!fn[i] && !T[i] && released < N) {
				T[i] = new thread([&](unsigned beg, unsigned end, bool* sig) {
					COLORf col; vec3 d;
					for (unsigned i = beg; i < end; i++) {
						d = fromScreen(i % clt_w / double(clt_w), i / clt_w / double(clt_h)).unitvec();
						col = *(COLORf*)&castRay(d);
						img[i] = toCOLORREF(col);
					}
					*sig = true;
				}, ppt * released, ppt * (released + 1), fn + i);
				T[i]->detach();
				released++;
			}
		}
		Sleep(1);
	}

	COLORf col; vec3 d;
	for (unsigned i = N * ppt; i < L; i++) {
		d = fromScreen(i % clt_w / double(clt_w), i / clt_w / double(clt_h)).unitvec();
		col = *(COLORf*)&castRay(d);
		img[i] = toCOLORREF(col);
	}

	delete fn;
	delete T;

	double dt = fsec(NTime::now() - t0).count();


	// mark on window title
	double Mrps = total_ray / dt / 1e+6;
	SetWindowTextA(HWnd, &(" Elapsed Time: " + fps2str(dt) + "secs  (" + fps2str(1 / dt) + "fps, " + fps2str(Mrps) + "Mrps, " + int2str(MAX_THREADS) + "cores)      ")[0]);

	// axis, painter's algo
	double m = 0.1*dist;
	vec2 dr = 0.5*vec2(clt_w, clt_h) - 0.2*vec2(min(clt_w, clt_h), min(clt_w, clt_h));
	vec3 O = fromWorld * vec3(0, 0, 0) + dr;
	vec3 P[3] = { vec3(m, 0, 0), vec3(0, m, 0), vec3(0, 0, m) };
	for (int i = 0; i < 3; i++) P[i] = fromWorld * P[i] + dr;
	for (int i = 0; i < 3; i++) {
		int m = 0; double d = INFINITY;
		for (int n = 0; n < 3; n++) if (P[n].z < d) m = n, d = P[n].z;
		drawLine(img, clt_w, clt_h, O.x, O.y, P[m].x, P[m].y, 0.005*Unit, m == 0 ? _RGB(255, 0, 0) : m == 1 ? _RGB(0, 128, 0) : _RGB(0, 0, 255));
		P[m].z = INFINITY;
	}

	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);
}


#else	// Visualize_3D

void render() {
	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);

	vec2 O(-0.5*vec2(clt_w, clt_h) / Unit + Pos), X(0.5*vec2(clt_w, -clt_h) / Unit + Pos - O), Y(0.5*vec2(-clt_w, clt_h) / Unit + Pos - O);
	double *SDF = new double[clt_w*clt_h];

	auto t0 = NTime::now();
	for (int y = 0; y < clt_h; y++) {
		for (int x = 0; x < clt_w; x++) {
			SDF[y*clt_w + x] = map(vec3(O + (x / double(clt_w)) * X + (y / double(clt_h)) * Y, cross_z));
		}
	}

	double dt = fsec(NTime::now() - t0).count();
	double Mrps = clt_w * clt_h / dt / 1e+6;


	auto colorf = [](double sd) -> COLORf {
		if (isNaN(sd)) return RGBf(0, 0.25, 0);
		//return sd > 0 ? RGBf(0.9, 0.6, 0.3) : RGBf(0.1, 0.4, 0.7);
		vec3 col = vec3(1, 1, 1) - (sd > 0 ? 1 : -1)*vec3(0.1, 0.4, 0.7);
		col *= (1.0 - exp(-2.0*abs(sd))) * (0.8 + 0.2*cos(Unit*sd));
		if (abs(sd) < PI / Unit) col = Lerp(col, vec3(1, 1, 1), pow(cos(0.5*Unit*sd), 2));
		return *(COLORf*)&col;
	};
	for (int y = 0; y < clt_h; y++) {
		for (int x = 0; x < clt_w; x++) {
			COLORf col = colorf(SDF[y*clt_w + x]);
			img[y*clt_w + x] = toCOLORREF(col);
		}
	}


	dt = fsec(NTime::now() - t0).count();
	double u = Cursor.x / clt_w, v = Cursor.y / clt_h;
	vec3 P = O + u * X + v * Y; double sd = map(vec3(O + u * X + v * Y, cross_z));
	SetWindowTextA(HWnd, &(" Elapsed Time: " + fps2str(dt) + "secs  (" + fps2str(1 / dt) + "fps, " + fps2str(Mrps) + "Mrps)      "
		+ ((int(Cursor.x) >= 0 && int(Cursor.x) < clt_w && int(Cursor.y) >= 0 && int(Cursor.y) < clt_h) ?
		("sd(" + fps2str(P.x) + "," + fps2str(P.y) + "," + fps2str(cross_z) + ") = " + fps2str(sd)) : ""))[0]);


	delete SDF;


	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);
}

#endif	// Visualize_3D







bool mouse_down = false;

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {

	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, int w, int h, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)h : (long)h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = bmi.bmiColors[0].rgbGreen = bmi.bmiColors[0].rgbRed = bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};

	switch (message) {
	case WM_CREATE: {
		RECT Client; GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		break;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		RECT Client; GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		Unit *= sqrt((clt_w * clt_h) / (prev_w * prev_h));
		DeleteObject(HImg);
		InitializeClientBitmap(hWnd, HImg, img, clt_w, clt_h, false);
		render();
		break;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 300, lpMMI->ptMinTrackSize.y = 200;
		break;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HMem, HImg);
		BitBlt(hdc, 0, 0, clt_w, clt_h, HMem, 0, 0, SRCCOPY);
		SelectObject(HMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HMem);
		DeleteDC(hdc);
		break;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
#ifdef Visualize_3D
	case WM_MOUSEMOVE: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		if (mouse_down) {
			vec2 dC = 0.02 * (prevCursor - Cursor);
			Pos = RotationMatrix_z(dC.x) * prevPos;
			double a = acos(Pos.unitvec().z);
			if (a - dC.y < 0.001) dC.y = a - 0.001;
			if (a - dC.y > 3.141) dC.y = a - 3.141;
			Pos = RotationMatrix(cross(Pos, vec3(0, 0, 1)), dC.y) * Pos;
		}
		render();
		break;
	}
	case WM_MOUSEWHEEL: {
		double delta = GET_WHEEL_DELTA_WPARAM(wParam);
		double s = exp(-0.001*delta);
		if (Pos.mod()*s > 0.5*MAX_DIST) Pos = 0.5*MAX_DIST*Pos.unitvec();
		else if (Pos.mod()*s < 1) Pos /= Pos.mod();
		else Pos *= s;
		render();
		break;
	}
#else	// Visualize_3D
	case WM_MOUSEMOVE: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		if (mouse_down) {
			vec2 dC = (Cursor - prevCursor) / Unit;
			Pos = prevPos - dC;
		}
		render();
		break;
	}
	case WM_MOUSEWHEEL: {
		if (mouse_down) {
			cross_z += 0.001*GET_WHEEL_DELTA_WPARAM(wParam);
			render(); break;
		}
		double s = exp(0.001*GET_WHEEL_DELTA_WPARAM(wParam));
		if (Unit * s > 10000) s = 10000 / Unit;
		if (Unit * s < 1) s = 1 / Unit;
		vec3 P = (Cursor - 0.5*vec2(clt_w, clt_h)) / Unit + Pos;
		Pos = (Pos - P) / s + P;
		Unit *= s;
		render();
		break;
	}
	case WM_RBUTTONDOWN: {
		mouse_down = false;
		renderGradient ^= 1;
		render();
	}
#endif	// Visualize_3D
	case WM_LBUTTONDOWN: {
		mouse_down = true;
		prevPos = Pos, prevCursor = Cursor;
		SetCapture(hWnd);
		render();
		break;
	}
	case WM_LBUTTONUP: {
		ReleaseCapture();
		mouse_down = false;
		render();
		break;
	}
	}
	return DefWindowProc(hWnd, message, wParam, lParam);

}


int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {

	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = _T(WIN_NAME);
	if (!RegisterClassEx(&wc)) return -1;


	HWnd = CreateWindow(
		_T(WIN_NAME),
		_T(WIN_NAME),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		600, 400,
		NULL, NULL, hInstance, NULL
	);

	ShowWindow(HWnd, nCmdShow); UpdateWindow(HWnd);


	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	return (int)message.wParam;
}


