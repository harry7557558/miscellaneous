#pragma once

#ifndef _INC_RC_BASIC
#include "RC_basic.h"
#endif

class RT_Sphere : public RT_Object {
	double r2;
public:
	vec3 O; double r;
	virtual void init() {
		if (r < 0) r = -r;
		r2 = r * r;
	}
	virtual void debug_output(wostream& os) const {
		os << "Sphere(" << O << "," << r << ")";
	}

	RT_Sphere() {}
	RT_Sphere(cv3ref O, const double& r) :O(O), r(r) { r2 = r * r; }
	RT_Sphere(cv3ref O, const double& r, vec3 col) :O(O), r(r) { this->col = col, r2 = r * r; }
	RT_Sphere(const RT_Sphere &other) :O(other.O), r(other.r) { col = other.col; init(); }
	RT_Sphere& operator = (const RT_Sphere &other) { O = other.O, r = other.r, col = other.col; init(); return *this; }
	~RT_Sphere() {}

	virtual RT_BBox getMaxMin() const {
		return RT_BBox(O - vec3(r, r, r), O + vec3(r, r, r));
	}
	virtual bool intersect_old(cv3ref P, cv3ref d, double &t, vec3 &n) const {	// faster, but doesn't work when P is inside
		vec3 p = P - O; if (dot(p, d) >= 0) return false;
		double rd2 = cross(p, d).sqr(); if (rd2 >= r2) return false;
		t = sqrt(p.sqr() - rd2) - sqrt(r2 - rd2); if (t < RT_EPSILON) return false;
		n = (p + t * d) / r; return true;
	}
	virtual bool intersect(cv3ref P, cv3ref d, double &t, vec3 &n) const {
		vec3 p = P - O;
		double a = d.sqr(), b = dot(p, d), delta = b * b - a * (p.sqr() - r2);
		if (delta <= 0) return false;
		delta = sqrt(delta) / a, b /= -a;
		a = b + delta, b -= delta; if (a > b) delta = a, a = b, b = delta;
		if (a < RT_EPSILON) {
			if (b < RT_EPSILON) return false;
			t = b, n = (p + t * d) / r; return true;
		}
		else {
			if (b < RT_EPSILON) { t = a, n = (p + t * d) / r; return true; }
			t = min(a, b), n = (p + t * d) / r; return true;
		}
	}

};

