#pragma once

#ifndef _INC_RC_BASIC
#include "RC_basic.h"
#endif

class RT_Ellipsoid :public RT_Object {
	mat3 M, M_Invert;
	double a2, b2, c2;
	RT_BBox Border;
public:
	vec3 C; double a, b, c;
	virtual void init() {
		if (a < 0) a = -a; if (b < 0) b = -b; if (c < 0) c = -c;
		a2 = a * a, b2 = b * b, c2 = c * c;
		if (!(abs(M.det() - 1) < 1e-6)) M.init(), M_Invert.init();
		else M_Invert = M.invert();
		Border.Max = vec3(a, b, c), Border.Min = -Border.Max;
	}
	virtual void debug_output(wostream& os) const {
		mat3 T = M; for (int i = 0; i < 3; i++) T[i][0] *= a, T[i][1] *= b, T[i][2] *= c;
		os << "Surface(";
		for (int i = 0; i < 3; i++) os << noshowpos << T[i][0] << "*cos(u)*cos(v)" << showpos << T[i][1] << "*sin(u)*cos(v)" << showpos << T[i][2] << "*sin(v),";
		os << "u,0,2*pi,v,-pi,pi)";
	}

	RT_Ellipsoid(cv3ref C, cdref a, cdref b, cdref c) :C(C), a(a), b(b), c(c) { init(); }
	RT_Ellipsoid(cv3ref C, cdref a, cdref b, cdref c, vec3 col) :C(C), a(a), b(b), c(c) { this->col = col; init(); }
	RT_Ellipsoid(cv3ref C, vec3 x_axis, vec3 y_axis, cdref z_rad) :C(C), a(x_axis.mod()), b(y_axis.mod()), c(z_rad) {
		x_axis /= a, y_axis = (y_axis - dot(x_axis, y_axis)*x_axis).unitvec();
		vec3 z_axis = cross(x_axis, y_axis);
		M = mat3(x_axis.x, y_axis.x, z_axis.x, x_axis.y, y_axis.y, z_axis.y, x_axis.z, y_axis.z, z_axis.z);
		init();
	}
	RT_Ellipsoid(cv3ref C, vec3 x_axis, vec3 y_axis, cdref z_rad, vec3 col) :C(C), a(x_axis.mod()), b(y_axis.mod()), c(z_rad) {
		x_axis /= a, y_axis = (y_axis - dot(x_axis, y_axis)*x_axis).unitvec();
		vec3 z_axis = cross(x_axis, y_axis);
		M = mat3(x_axis.x, y_axis.x, z_axis.x, x_axis.y, y_axis.y, z_axis.y, x_axis.z, y_axis.z, z_axis.z);
		this->col = col; init();
	}
	RT_Ellipsoid(const RT_Ellipsoid &other) :C(other.C), a(other.a), b(other.b), c(other.c) { col = other.col; init(); }
	RT_Ellipsoid& operator = (const RT_Ellipsoid &other) { C = other.C, a = other.a, b = other.b, c = other.c, col = other.col; init(); }
	~RT_Ellipsoid() {}

	virtual RT_BBox getMaxMin() const {
		mat3 T = M; for (int i = 0; i < 3; i++) T[i][0] *= a, T[i][1] *= b, T[i][2] *= c;
		double u, v;
		RT_BBox R;
		u = atan(T[0][1] / T[0][0]), v = atan(T[0][2] / (T[0][0] * cos(u) + T[0][1] * sin(u)));
		R.Min.x = T[0][0] * cos(u)*cos(v) + T[0][1] * sin(u)*cos(v) + T[0][2] * sin(v);
		u += PI, v = -v;
		R.Max.x = T[0][0] * cos(u)*cos(v) + T[0][1] * sin(u)*cos(v) + T[0][2] * sin(v);
		u = atan(T[1][1] / T[1][0]), v = atan(T[1][2] / (T[1][0] * cos(u) + T[1][1] * sin(u)));
		R.Min.y = T[1][0] * cos(u)*cos(v) + T[1][1] * sin(u)*cos(v) + T[1][2] * sin(v);
		u += PI, v = -v;
		R.Max.y = T[1][0] * cos(u)*cos(v) + T[1][1] * sin(u)*cos(v) + T[1][2] * sin(v);
		u = atan(T[2][1] / T[2][0]), v = atan(T[2][2] / (T[2][0] * cos(u) + T[2][1] * sin(u)));
		R.Min.z = T[2][0] * cos(u)*cos(v) + T[2][1] * sin(u)*cos(v) + T[2][2] * sin(v);
		u += PI, v = -v;
		R.Max.z = T[2][0] * cos(u)*cos(v) + T[2][1] * sin(u)*cos(v) + T[2][2] * sin(v);
		R.Max += C, R.Min += C;
		R.init();
		return R;
	}
	virtual bool intersect(cv3ref P, cv3ref D, double &t, vec3 &n) const {
		vec3 p = M_Invert * (P - C), d = M_Invert * D;
		if (!Border.intersect(p, d)) return false;
		double a = d.x*d.x / a2 + d.y*d.y / b2 + d.z*d.z / c2, b = d.x*p.x / a2 + d.y*p.y / b2 + d.z*p.z / c2;
		double delta = b * b - a * (p.x*p.x / a2 + p.y*p.y / b2 + p.z*p.z / c2 - 1); if (delta <= 0) return false;
		delta = sqrt(delta) / a, b /= -a;
		a = b - delta, b += delta; if (a > b) delta = a, a = b, b = delta;
		if (a > RT_EPSILON) {
			if (b > RT_EPSILON) t = min(a, b);
			else t = a;
		}
		else if (b > RT_EPSILON) t = b;
		else return false;
		n = p + t * d; n.x /= a2, n.y /= b2, n.z /= c2; n = M * n.unitvec();
		return true;
	}

};


