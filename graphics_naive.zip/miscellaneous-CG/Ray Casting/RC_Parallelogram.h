#pragma once

#ifndef _INC_RC_BASIC
#include "RC_basic.h"
#endif

class RT_Parallelogram : public RT_Object {
	vec3 n, K;
public:
	vec3 O, A, B;	// O + u A + v B,  0 ≤ u,v < 1
	virtual void init() {
		K = cross(A, B);
		n = K.unitvec();
	}
	virtual void debug_output(wostream& os) const {
		os << "Surface(" << O << "+u*" << A << "+v*" << B << ",u,0,1,v,0,1)";
	}

	RT_Parallelogram() {}
	RT_Parallelogram(cv3ref O, cv3ref A, cv3ref B) :O(O), A(A), B(B) { init(); }
	RT_Parallelogram(cv3ref O, cv3ref A, cv3ref B, vec3 col) :O(O), A(A), B(B) { this->col = col; init(); }
	RT_Parallelogram(const RT_Parallelogram &other) :O(other.O), A(other.A), B(other.B) { col = other.col; init(); }
	RT_Parallelogram& operator = (const RT_Parallelogram &other) { O = other.O, A = other.A, B = other.B, col = other.col; init(); return *this; }
	~RT_Parallelogram() {}


	virtual RT_BBox getMaxMin() const {
		return RT_BBox(PMin(PMin(O, O + A + B), PMin(O + A, O + B)), PMax(PMax(O, O + A + B), PMax(O + A, O + B)));
	}
	virtual bool intersect(cv3ref P, cv3ref d, double &t, vec3 &n) const {
		vec3 S = P - O, N = cross(S, d);
		double det = -dot(K, d); if (abs(det) < RT_EPSILON) return false;
		double u = dot(N, B) / det; if (u < 0 || u > 1) return false;
		double v = -dot(N, A) / det; if (v < 0 || v > 1) return false;
		t = dot(K, S) / det; if (t < RT_EPSILON) return false;
		n = det > 0 ? this->n : -this->n; return true;
	}

};

