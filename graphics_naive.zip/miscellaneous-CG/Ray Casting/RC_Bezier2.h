#pragma once

#ifndef _INC_RC_BASIC
#include "RC_basic.h"
#endif


// Debugging


class RT_QuadraticBezierPatch : public RT_Object {
	vec3 K[3][3];	// Σ Σ K[i][j] u^i v^j
	RT_BBox Border;
public:
	vec3 P[3][3];
	virtual void init() {
		K[0][0] = P[0][0];
		K[0][1] = -2 * P[0][0] + 2 * P[0][1];
		K[0][2] = P[0][0] - 2 * P[0][1] + P[0][2];
		K[1][0] = -2 * P[0][0] + 2 * P[1][0];
		K[1][1] = 4 * P[0][0] - 4 * P[1][0] - 4 * P[0][1] + 4 * P[1][1];
		K[1][2] = -2 * P[0][0] + 4 * P[0][1] - 2 * P[0][2] + 2 * P[1][0] - 4 * P[1][1] + 2 * P[1][2];
		K[2][0] = P[0][0] - 2 * P[1][0] + P[2][0];
		K[2][1] = -2 * P[0][0] + 4 * P[1][0] - 2 * P[2][0] + 2 * P[0][1] - 4 * P[1][1] + 2 * P[2][1];
		K[2][2] = P[0][0] - 2 * P[1][0] + P[2][0] - 2 * P[0][1] + 4 * P[1][1] - 2 * P[2][1] + P[0][2] - 2 * P[1][2] + P[2][2];
		Border = this->getMaxMin();
	}
	virtual void debug_output(wostream& os) const {
		os << "Surface((1-v)^(2)*((1-u)^(2)*" << P[0][0] << "+2u*(1-u)*" << P[1][0] << "+u^(2)*" << P[2][0] << ")+2v*(1-v)*((1-u)^(2)*" << P[0][1] << "+2u*(1-u)*" << P[1][1] << "+u^(2)*" << P[2][1] << ")+v^(2)*((1-u)^(2)*" << P[0][2] << "+2u*(1-u)*" << P[1][2] << "+u^(2)*" << P[2][2] << "),u,0,1,v,0,1)";
		//os << "Surface(" << K[0][0] << "+" << K[1][0] << "*u+" << K[2][0] << "*u^(2)+" << K[0][1] << "*v+" << K[1][1] << "*u*v+" << K[2][1] << "*u^(2)v+" << K[0][2] << "*v^(2)+" << K[1][2] << "*u*v^(2)+" << K[2][2] << "*u^(2)v^(2),u,0,1,v,0,1)";
	}
	inline vec3 eval(double u, double v) const {
		return K[0][0] + u * K[1][0] + u * u * K[2][0] + v * K[0][1] + u * v * K[1][1] + u * u * v * K[2][1] + v * v * K[0][2] + u * v * v * K[1][2] + u * u * v * v * K[2][2];
	}
	inline vec3 partial_u(double u, double v) const {
		return K[1][0] + 2 * u * K[2][0] + v * K[1][1] + 2 * u * v * K[2][1] + v * v * K[1][2] + 2 * u * v * v * K[2][2];
	}
	inline vec3 partial_v(double u, double v) const {
		return K[0][1] + u * K[1][1] + u * u * K[2][1] + 2 * v * K[0][2] + 2 * u * v * K[1][2] + 2 * u * u * v * K[2][2];
	}

	RT_QuadraticBezierPatch(const vec3* const &v) { memcpy(&P[0][0], v, 9 * sizeof(vec3)); init(); }
	RT_QuadraticBezierPatch(const vec3* const &v, vec3 col) { memcpy(&P[0][0], v, 9 * sizeof(vec3)); this->col = col; init(); }
	RT_QuadraticBezierPatch(cv3ref P00, cv3ref P01, cv3ref P02, cv3ref P10, cv3ref P11, cv3ref P12, cv3ref P20, cv3ref P21, cv3ref P22) { P[0][0] = P00, P[0][1] = P01, P[0][2] = P02, P[1][0] = P10, P[1][1] = P11, P[1][2] = P12, P[2][0] = P20, P[2][1] = P21, P[2][2] = P22; init(); }
	RT_QuadraticBezierPatch(cv3ref P00, cv3ref P01, cv3ref P02, cv3ref P10, cv3ref P11, cv3ref P12, cv3ref P20, cv3ref P21, cv3ref P22, vec3 col) { P[0][0] = P00, P[0][1] = P01, P[0][2] = P02, P[1][0] = P10, P[1][1] = P11, P[1][2] = P12, P[2][0] = P20, P[2][1] = P21, P[2][2] = P22; this->col = col; init(); }
	RT_QuadraticBezierPatch(const RT_QuadraticBezierPatch &other) { memcpy(&P[0][0], &other.P[0][0], 9 * sizeof(vec3)); this->col = other.col; init(); }
	RT_QuadraticBezierPatch& operator = (const RT_QuadraticBezierPatch &other) { memcpy(&P[0][0], &other.P[0][0], 9 * sizeof(vec3)); this->col = other.col; init(); return *this; }
	~RT_QuadraticBezierPatch() {}

	virtual RT_BBox getMaxMin() const {
		//return RT_BBox();

		// vertexes
		RT_BBox R(PMin(PMin(P[0][0], P[0][2]), PMin(P[2][0], P[2][2])), PMax(PMax(P[0][0], P[0][2]), PMax(P[2][0], P[2][2])));

		// edge u=0
		vec3 M = 0.5*(P[0][0] + P[0][2]);
		double t = -K[0][1].x / (2 * K[0][2].x); if (t > 0 && t < 1) M.x = K[0][0].x + K[0][1].x*t + K[0][2].x*t*t;
		t = -K[0][1].y / (2 * K[0][2].y); if (t > 0 && t < 1) M.y = K[0][0].y + K[0][1].y*t + K[0][2].y*t*t;
		t = -K[0][1].z / (2 * K[0][2].z); if (t > 0 && t < 1) M.z = K[0][0].z + K[0][1].z*t + K[0][2].z*t*t;
		R.Max = PMax(R.Max, M), R.Min = PMin(R.Min, M);

		// edge v=0
		M = 0.5*(P[0][0] + P[2][0]);
		t = -K[1][0].x / (2 * K[2][0].x); if (t > 0 && t < 1) M.x = K[0][0].x + K[1][0].x*t + K[2][0].x*t*t;
		t = -K[1][0].y / (2 * K[2][0].y); if (t > 0 && t < 1) M.y = K[0][0].y + K[1][0].y*t + K[2][0].y*t*t;
		t = -K[1][0].z / (2 * K[2][0].z); if (t > 0 && t < 1) M.z = K[0][0].z + K[1][0].z*t + K[2][0].z*t*t;
		R.Max = PMax(R.Max, M), R.Min = PMin(R.Min, M);

		// edge u=1
		M = 0.5*(P[2][0] + P[2][2]);
		t = (P[2][0].x - P[2][1].x) / (P[2][2].x - 2 * P[2][1].x + P[2][0].x); if (t > 0 && t < 1) M.x = eval(1, t).x;
		t = (P[2][0].y - P[2][1].y) / (P[2][2].y - 2 * P[2][1].y + P[2][0].y); if (t > 0 && t < 1) M.y = eval(1, t).y;
		t = (P[2][0].z - P[2][1].z) / (P[2][2].z - 2 * P[2][1].z + P[2][0].z); if (t > 0 && t < 1) M.z = eval(1, t).z;
		R.Max = PMax(R.Max, M), R.Min = PMin(R.Min, M);

		// edge v=1
		M = 0.5*(P[0][2] + P[2][2]);
		t = (P[0][2].x - P[1][2].x) / (P[2][2].x - 2 * P[1][2].x + P[0][2].x); if (t > 0 && t < 1) M.x = eval(t, 1).x;
		t = (P[0][2].y - P[1][2].y) / (P[2][2].y - 2 * P[1][2].y + P[0][2].y); if (t > 0 && t < 1) M.y = eval(t, 1).y;
		t = (P[0][2].z - P[1][2].z) / (P[2][2].z - 2 * P[1][2].z + P[0][2].z); if (t > 0 && t < 1) M.z = eval(t, 1).z;
		R.Max = PMax(R.Max, M), R.Min = PMin(R.Min, M);

		// maximums on surface
		// Suppose M = K[2][0] + v K[2][1] + v^2 K[2][2], N = K[1][0] + v K[1][1] + v^2 K[1][2], \
			then u = -N / 2M, 4 M^2 K[0][1] - 2 MN K[1][1] + N^2 K[2][1] + 8 v M^2 K[0][2] - 4 v MN K[1][2] + 2 v N^2 K[2][2] = 0
		vec3 M2v4 = K[2][2] * K[2][2], M2v3 = 2 * K[2][1] * K[2][2], M2v2 = K[2][1] * K[2][1] + 2 * K[2][0] * K[2][2], M2v1 = 2 * K[2][0] * K[2][1], M2v0 = K[2][0] * K[2][0];
		vec3 MNv4 = K[1][2] * K[2][2], MNv3 = K[1][1] * K[2][2] + K[1][2] * K[2][1], MNv2 = K[1][0] * K[2][2] + K[1][1] * K[2][1] + K[1][2] * K[2][0], MNv1 = K[1][0] * K[2][1] + K[1][1] * K[2][0], MNv0 = K[1][0] * K[2][0];
		vec3 N2v4 = K[1][2] * K[1][2], N2v3 = 2 * K[1][1] * K[1][2], N2v2 = K[1][1] * K[1][1] + 2 * K[1][0] * K[1][2], N2v1 = 2 * K[1][0] * K[1][1], N2v0 = K[1][0] * K[1][0];

		vec3 C[6];
		C[5] = 8 * K[0][2] * M2v4 - 4 * K[1][2] * MNv4 + 2 * K[2][2] * N2v4;
		C[4] = 4 * K[0][1] * M2v4 - 2 * K[1][1] * MNv4 + K[2][1] * N2v4 + 8 * K[0][2] * M2v3 - 4 * K[1][2] * MNv3 + 2 * K[2][2] * N2v3;
		C[3] = 4 * K[0][1] * M2v3 - 2 * K[1][1] * MNv3 + K[2][1] * N2v3 + 8 * K[0][2] * M2v2 - 4 * K[1][2] * MNv2 + 2 * K[2][2] * N2v2;
		C[2] = 4 * K[0][1] * M2v2 - 2 * K[1][1] * MNv2 + K[2][1] * N2v2 + 8 * K[0][2] * M2v1 - 4 * K[1][2] * MNv1 + 2 * K[2][2] * N2v1;
		C[1] = 4 * K[0][1] * M2v1 - 2 * K[1][1] * MNv1 + K[2][1] * N2v1 + 8 * K[0][2] * M2v0 - 4 * K[1][2] * MNv0 + 2 * K[2][2] * N2v0;
		C[0] = 4 * K[0][1] * M2v0 - 2 * K[1][1] * MNv0 + K[2][1] * N2v0;
		double Cx[6], Cy[6], Cz[6]; for (int i = 0; i < 6; i++) Cx[i] = C[i].x, Cy[i] = C[i].y, Cz[i] = C[i].z;

		double V[15];
		int nx = solveQuintic(Cx, V), ny = solveQuintic(Cy, V + nx), nz = solveQuintic(Cz, V + nx + ny), nr = nx + ny + nz;
		for (int i = 0; i < nr; i++) {
			double v = V[i];
			vec3 U = -(K[1][0] + v * K[1][1] + v * v*K[1][2]) / (2 * (K[2][0] + v * K[2][1] + v * v*K[2][2])); double u = i < nx ? U.x : (i < ny ? U.y : U.z);
			if (v > 0 && v < 1 && u > 0 && u < 1) M = eval(u, v), R.Max = PMax(R.Max, M), R.Min = PMin(R.Min, M);
		}

		return R;
	}
	virtual bool intersect(cv3ref p, cv3ref d, double &t, vec3 &n) const {
		if (!Border.intersect(p, d)) return false;
		double M[3][3], N[3][3];
		for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++)
			M[i][j] = d.y*K[i][j].x - d.x*K[i][j].y, N[i][j] = d.z*K[i][j].x - d.x*K[i][j].z;
		M[0][0] += d.x*p.y - d.y*p.x, N[0][0] += d.x*p.z - d.z*p.x;		// Σ Σ M[i][j] u^i v^j = Σ Σ N[i][j] u^i v^j = 0, solve for u and v
		// I tried to solve using elimination and got a very nasty 12-degree polynomial.

		/*dout("\nF1(x,y)="); for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
			dout((i || j ? showpos : noshowpos) << setprecision(15) << M[i][j]); for (int u = 0; u < i; u++) dout("*x"); for (int v = 0; v < j; v++) dout("*y");
		}
		dout("\nF2(x,y)="); for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
			dout((i || j ? showpos : noshowpos) << setprecision(15) << N[i][j]); for (int u = 0; u < i; u++) dout("*x"); for (int v = 0; v < j; v++) dout("*y");
		}
		dout("\nfx1(x,y)="); for (int i = 1; i < 3; i++) for (int j = 0; j < 3; j++) {
			dout(((i - 1) || j ? showpos : noshowpos) << setprecision(15) << (i*M[i][j])); for (int u = 1; u < i; u++) dout("*x"); for (int v = 0; v < j; v++) dout("*y");
		}
		dout("\nfy1(x,y)="); for (int i = 0; i < 3; i++) for (int j = 1; j < 3; j++) {
			dout((i || (j - 1) ? showpos : noshowpos) << setprecision(15) << (j*M[i][j])); for (int u = 0; u < i; u++) dout("*x"); for (int v = 1; v < j; v++) dout("*y");
		}
		dout("\nfx2(x,y)="); for (int i = 1; i < 3; i++) for (int j = 0; j < 3; j++) {
			dout(((i - 1) || j ? showpos : noshowpos) << setprecision(15) << (i*N[i][j])); for (int u = 1; u < i; u++) dout("*x"); for (int v = 0; v < j; v++) dout("*y");
		}
		dout("\nfy2(x,y)="); for (int i = 0; i < 3; i++) for (int j = 1; j < 3; j++) {
			dout((i || (j - 1) ? showpos : noshowpos) << setprecision(15) << (j*N[i][j])); for (int u = 0; u < i; u++) dout("*x"); for (int v = 1; v < j; v++) dout("*y");
		}
		dout("\n\n");*/

		auto findRoot = [](vec2 X, double M[3][3], double N[3][3])->vec2 {
			vec2 Y; mat2 J;
			const int MAX_ITER = 20;
			int iter; for (iter = 0; iter < MAX_ITER; iter++) {
				Y.x = M[0][0] + X.x * M[1][0] + X.x * X.x * M[2][0] + X.y * M[0][1] + X.x * X.y * M[1][1] + X.x * X.x * X.y * M[2][1] + X.y * X.y * M[0][2] + X.x * X.y * X.y * M[1][2] + X.x * X.x * X.y * X.y * M[2][2];
				Y.y = N[0][0] + X.x * N[1][0] + X.x * X.x * N[2][0] + X.y * N[0][1] + X.x * X.y * N[1][1] + X.x * X.x * X.y * N[2][1] + X.y * X.y * N[0][2] + X.x * X.y * X.y * N[1][2] + X.x * X.x * X.y * X.y * N[2][2];
				J.a = M[1][0] + 2 * X.x * M[2][0] + X.y * M[1][1] + 2 * X.x * X.y * M[2][1] + X.y * X.y * M[1][2] + 2 * X.x * X.y * X.y * M[2][2];
				J.c = N[1][0] + 2 * X.x * N[2][0] + X.y * N[1][1] + 2 * X.x * X.y * N[2][1] + X.y * X.y * N[1][2] + 2 * X.x * X.y * X.y * N[2][2];
				J.b = M[0][1] + X.x * M[1][1] + X.x * X.x * M[2][1] + 2 * X.y * M[0][2] + X.x * 2 * X.y * M[1][2] + X.x * X.x * 2 * X.y * M[2][2];
				J.d = N[0][1] + X.x * N[1][1] + X.x * X.x * N[2][1] + 2 * X.y * N[0][2] + X.x * 2 * X.y * N[1][2] + X.x * X.x * 2 * X.y * N[2][2];
				Y = J.solve(Y), X -= Y;
				if (Y.sqr() < 1e-16) break;
			}
			if (iter == MAX_ITER) return vec2(NAN, NAN);
			return X;
		};
		vec2 R[9];
		R[0] = findRoot(vec2(0, 0), M, N), R[1] = findRoot(vec2(1, 1), M, N), R[2] = findRoot(vec2(0, 1), M, N), R[3] = findRoot(vec2(1, 0), M, N), R[4] = findRoot(vec2(0.5, 0.5), M, N),
			R[5] = findRoot(vec2(0.5, 0), M, N), R[6] = findRoot(vec2(1, 0.5), M, N), R[7] = findRoot(vec2(0.5, 1), M, N), R[8] = findRoot(vec2(0, 0.5), M, N);
		double min_t = INFINITY; vec3 min_n;
		for (int i = 0; i < 9; i++) {
			if (R[i].x > 0 && R[i].x < 1 && R[i].y > 0 && R[i].y < 1) {
				n = eval(R[i].x, R[i].y); t = (n.x - p.x) / d.x;
				if (t > RT_EPSILON && t < min_t) min_t = t, min_n = cross(partial_u(R[i].x, R[i].y), partial_v(R[i].x, R[i].y));
				// The probability of getting the wrong point is quite high
			}
		}
		if (isNaN(min_t)) return false;
		t = min_t, n = min_n / min_n.mod(); return true;
	}
	virtual bool intersect_new(cv3ref p, cv3ref d, double &t, vec3 &n) const {
		if (!Border.intersect(p, d)) return false;

		auto findRoot = [](vec3 X, vec3 P, vec3 D, const RT_QuadraticBezierPatch *p)->vec3 {
			vec3 Y; mat3 J;
			const int MAX_ITER = 20;
			int iter; for (iter = 0; iter < MAX_ITER; iter++) {
				Y = p->partial_u(X.x, X.y); J[0][0] = Y.x, J[1][0] = Y.y, J[2][0] = Y.z;
				Y = p->partial_v(X.x, X.y); J[0][1] = Y.x, J[1][1] = Y.y, J[2][1] = Y.z;
				J[0][2] = -D.x, J[1][2] = -D.y, J[2][2] = -D.z;
				Y = J.solve(p->eval(X.x, X.y) - D * X.z - P), X -= Y;
				if (Y.sqr() < 1e-16) break;
			}
			if (iter == MAX_ITER) return vec3(NAN, NAN, NAN);
			return X;
		};

		vec3 R;
		t = INFINITY;
		for (int i = 0; i < 9; i++) {
			R = findRoot(vec3((i / 3) / 2.0, (i % 3) / 2.0, (eval((i / 3) / 2.0, (i % 3) / 2.0).x - p.x) / d.x), p, d, this);
			if (R.x > 0 && R.x < 1 && R.y > 0 && R.y < 1 && R.z > RT_EPSILON && R.z < t) t = R.z, n = cross(partial_u(R.x, R.y), partial_v(R.x, R.y));
		}
		if (isNaN(t)) return false;
		n /= n.mod(); return true;
	}

};
typedef RT_QuadraticBezierPatch RT_Bezier2;



#ifdef _RT_DEBUG

#define F1(x,y) -0.799331111418397+1.85289683324708*y-0.556535737283476*y*y+1.1546734081837*x-3.75687303663343*x*y+3.01744351888673*x*y*y-0.201147816627732*x*x+2.67952279428942*x*x*y-2.28957682278887*x*x*y*y
#define F2(x,y) -1.40380318631762+1.9486808929854*y-2.06906411382514*y*y+3.04167564229636*x-0.506656192766183*x*y-0.163796300610921*x*y*y-1.64684550904505*x*x-1.49325716488865*x*x*y+2.19729236529342*x*x*y*y
#define fx1(x,y) 1.1546734081837-3.75687303663343*y+3.01744351888673*y*y-0.402295633255464*x+5.35904558857884*x*y-4.57915364557774*x*y*y
#define fy1(x,y) 1.85289683324708-1.11307147456695*y-3.75687303663343*x+6.03488703777347*x*y+2.67952279428942*x*x-4.57915364557774*x*x*y
#define fx2(x,y) 3.04167564229636-0.506656192766183*y-0.163796300610921*y*y-3.29369101809011*x-2.98651432977729*x*y+4.39458473058685*x*y*y
#define fy2(x,y) 1.9486808929854-4.13812822765028*y-0.506656192766183*x-0.327592601221842*x*y-1.49325716488865*x*x+4.39458473058685*x*x*y
void NewtonFractal() {
	const unsigned S = 500;
	COLORREF *img = new COLORREF[(S + 1)*(S + 1)];
	for (int i = 0; i <= S; i++) for (int j = 0; j <= S; j++) {
		vec2 x(i / double(S), j / double(S)), y; mat2 J;
		double n; for (n = 0; n < 100; n++) {
			y = vec2(F1(x.x, x.y), F2(x.x, x.y));
			J = mat2(fx1(x.x, x.y), fy1(x.x, x.y), fx2(x.x, x.y), fy2(x.x, x.y));
			y = J.solve(y); x -= y;
			if (y.sqr() < 1e-16) break;
		}
		n = exp(-0.5*(n - log2(-log(y.sqr())) + 2));
		COLORf col = (x.x > 0 && x.x < 1 && x.y > 0 && x.y < 1) ? RGBf(n*x.y, n*(1 - x.x), n*x.x) : RGBf(n, 0, 0);
		img[j*(S + 1) + i] = toCOLORREF(col);
	}
	saveBitmap(img, S + 1, S + 1, "C:\\Users\\harry\\Desktop\\Test\\Debug.bmp");
	delete img;
}
void Test() {
	NewtonFractal();
	vec2 x(0.5, 0), y; mat2 J;
	for (int i = 0; i < 100; i++) {
		dout("X_{" << i << "}=" << x << endl);
		y = vec2(F1(x.x, x.y), F2(x.x, x.y));
		J = mat2(fx1(x.x, x.y), fy1(x.x, x.y), fx2(x.x, x.y), fy2(x.x, x.y));
		y = J.solve(y); x -= y;
		if (y.sqr() < 1e-24) break;
	}
	dout("\nX=" << setprecision(15) << x << endl << endl);
}

#endif


