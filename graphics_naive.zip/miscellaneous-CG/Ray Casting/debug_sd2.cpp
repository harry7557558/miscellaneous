
#pragma warning(disable:4244 4018 4010 4305)

#include <Windows.h>
#include <windowsx.h>
#include <tchar.h>

using namespace std;

#include <chrono>
typedef chrono::high_resolution_clock NTime;
typedef chrono::duration<double> fsec;

#include "SDF_2D.h"

#include <string>
#include <vector>


#define WIN_NAME " SDF 2D"

HWND HWnd;
int clt_w, clt_h;
COLORREF *img; HBITMAP HImg;

vec2 Center(0, 0), prev_C;
double Unit = 100;
vec2 Cursor, prevCursor;

#define EPSILON 1e-6
bool renderGradient = false;



vec2 CP[256];
const double CP_R = 6;
enum CtrlPoints {	// name all control points there
	//A, B, C, D, E, F, G, H, I, J, K, L,
	NCtrlPoints
};
int CP_selected = -1; vec2 prev_CP;
void init() {	// initialize control points there
	for (int i = 0; i < NCtrlPoints; i++) CP[i] = vec2(0.1*i, 0);
}


// set sdf there
double map(cv2ref P) {
	double sd = INFINITY;
	{
		vec2 p = P;
		sd = min(sd, sd_Ellipse(1.6, 1.2, vec2(p.x, p.y + 0.2)));
		double ear = sd_Triangle(vec2(0.45, 0.76), vec2(1.26, 1.42), vec2(1.18, 0.36), vec2(abs(p.x), p.y)) - 0.15; sd = sd_OpSmoothedUnion(sd, ear, 0.2);
		double eye = sd_Circle(0.22, vec2(abs(p.x) - 0.63, p.y - 0.13)); sd = sd_OpSubtract(sd, eye);
		double beard = min(sd_Box(vec2(1.33, -0.39), vec2(2.02, -0.16), vec2(abs(p.x), p.y)),
			sd_Polygon({ vec2(1.37, -0.53), vec2(1.19, -0.81), vec2(1.90, -1.00), vec2(1.98, -0.82) }, vec2(abs(p.x), p.y))) - 0.03; sd = sd_OpSmoothedUnion(sd, beard, 0.05);
	}
	return sd;
}



void render() {
	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);


	double *SDF = new double[clt_w*clt_h];

	// record time
	auto t0 = NTime::now();

	// calculate sdf
	vec2 O(-0.5*vec2(clt_w, clt_h) / Unit + Center), X(0.5*vec2(clt_w, -clt_h) / Unit + Center - O), Y(0.5*vec2(-clt_w, clt_h) / Unit + Center - O);
	for (int y = 0; y < clt_h; y++) {
		for (int x = 0; x < clt_w; x++) {
			SDF[y*clt_w + x] = map(O + (x / double(clt_w)) * X + (y / double(clt_h)) * Y);
		}
	}

	// record elapsed time
	double dt = fsec(NTime::now() - t0).count();
	double Mrps = clt_w * clt_h / dt / 1e+6;

	// visualize sdf in window
	auto colorf = [](double sd) -> COLORf {
		if (isNaN(sd)) return RGBf(0, 0.25, 0);
		//return sd > 0 ? RGBf(0.9, 0.6, 0.3) : RGBf(0.1, 0.4, 0.7);
		vec3 col = vec3(1, 1, 1) - (sd > 0 ? 1 : -1)*vec3(0.1, 0.4, 0.7);
		col *= (1.0 - exp(-2.0*abs(sd))) * (0.8 + 0.2*cos(Unit*sd));
		if (abs(sd) < PI / Unit) col = Lerp(col, vec3(1, 1, 1), pow(cos(0.5*Unit*sd), 2));
		return *(COLORf*)&col;
	};
	for (int y = 0; y < clt_h; y++) {
		for (int x = 0; x < clt_w; x++) {
			COLORf col = colorf(SDF[y*clt_w + x]);
			img[y*clt_w + x] = toCOLORREF(col);
		}
	}

	// render axis
	vec2 P = -Center * Unit + 0.5*vec2(clt_w, clt_h);
	//drawLine(img, clt_w, clt_h, 0, P.y, clt_w, P.y, 4, _RGB(128, 128, 128));
	//drawLine(img, clt_w, clt_h, P.x, 0, P.x, clt_h, 4, _RGB(128, 128, 128));

	// visualize gradient
	if (renderGradient) {
		double dx, dy, grad = 0;
		for (int y = 0; y < clt_h; y++) {
			for (int x = 0; x < clt_w; x++) {
				vec2 p = O + (x / double(clt_w)) * X + (y / double(clt_h)) * Y;
				double e = EPSILON * max(abs(SDF[y*clt_w + x]), 1);
				dx = (map(p + vec2(e, 0)) - SDF[y*clt_w + x]) / e;
				dy = (map(p + vec2(0, e)) - SDF[y*clt_w + x]) / e;
				grad = sqrt(dx * dx + dy * dy);
				if (!isNaN(grad)) {
					COLORf col = toCOLORf(img[y*clt_w + x]);
					col.g *= 0.2;
					col.r = 1 / (exp(150 * (1.02 - grad)) + 1);
					col.b = 1 / (exp(8 * (grad - 0.5)) + 1);
					img[y*clt_w + x] = toCOLORREF(col);
				}
				else img[y*clt_w + x] = _RGB(32, 0, 16);
				SDF[y*clt_w + x] = grad;
			}
		}
	}

	// mark data on window title
	dt = fsec(NTime::now() - t0).count();
	auto fps2str = [](double a)->string {	// float to string
		bool sgn = a < 0; a = abs(a);
		if (a < 1e-5) return "0";
		if (a > 9999 || isNaN(a)) return "###";
		int e = 3;
		while (a < 100) a *= 10, e--;
		string r;
		while (a != 0) r = char('0' + int(a) % 10) + r, a = int(a) / 10;
		while (e <= 0) r = '0' + r, e++;
		if (e < 3) r.insert(r.begin() + e, '.');
		if (sgn) r = "-" + r;
		return r;
	};
	SetWindowTextA(HWnd, &(" Elapsed Time: " + fps2str(dt) + "secs  (" + fps2str(1 / dt) + "fps, " + fps2str(Mrps) + "Mrps)      "
		+ ((int(Cursor.x) >= 0 && int(Cursor.x) < clt_w && int(Cursor.y) >= 0 && int(Cursor.y) < clt_h) ? (string(renderGradient ? "grad" : "sd") + " = " + fps2str(SDF[int(Cursor.y)*clt_w + int(Cursor.x)])) : ""))[0]);

	delete SDF;


	// render control points
	for (int i = 0; i < NCtrlPoints; i++) {
		vec2 P = (CP[i] - Center)*Unit + 0.5*vec2(clt_w, clt_h);
		for (int x = P.x - CP_R - 1; x < P.x + CP_R + 1; x++) {
			for (int y = P.y - CP_R - 1; y < P.y + CP_R + 1; y++) {
				if (x >= 0 && x < clt_w && y >= 0 && y < clt_h) {
					// white circle
					double sd = CP_R - (vec2(x, y) - P).mod();
					if (sd > 0) {
						if (sd > 1) img[y*clt_w + x] = _RGB(255, 255, 255);
						else img[y*clt_w + x] = mix(img[y*clt_w + x], _RGB(255, 255, 255), sd);
					}
					// black border of circle
					sd = 1.2 - abs(sd);
					if (sd > 0) {
						if (sd > 1) img[y*clt_w + x] = 0;
						else img[y*clt_w + x] = mix(img[y*clt_w + x], 0, sd);
					}
				}
			}
		}
	}


	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);
}








bool mouse_down = false;

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {

	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, int w, int h, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)h : (long)h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};

	switch (message) {
	case WM_CREATE: {
		RECT Client; GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		break;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		RECT Client; GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		Unit *= sqrt((clt_w * clt_h) / (prev_w * prev_h));
		DeleteObject(HImg);
		InitializeClientBitmap(hWnd, HImg, img, clt_w, clt_h, false);
		render();
		break;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 300, lpMMI->ptMinTrackSize.y = 200;
		break;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HMem, HImg);
		BitBlt(hdc, 0, 0, clt_w, clt_h, HMem, 0, 0, SRCCOPY);
		SelectObject(HMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HMem);
		DeleteDC(hdc);
		break;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
	case WM_MOUSEMOVE: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		if (mouse_down) {
			vec2 dC = (Cursor - prevCursor) / Unit;
			if (CP_selected != -1) CP[CP_selected] = prev_CP + dC;
			else Center = prev_C - dC;
		}
		render();
		break;
	}
	case WM_MOUSEWHEEL: {
		double s = exp(0.001*GET_WHEEL_DELTA_WPARAM(wParam));
		if (Unit * s > 10000) s = 10000 / Unit;
		if (Unit * s < 1) s = 1 / Unit;
		vec3 P = (Cursor - 0.5*vec2(clt_w, clt_h)) / Unit + Center;
		Center = (Center - P) / s + P;
		Unit *= s;
		render();
		break;
	}
	case WM_LBUTTONDOWN: {
		mouse_down = true;
		SetCapture(hWnd);
		for (int i = NCtrlPoints - 1; i >= 0; i--) {
			if (((CP[i] - Center)*Unit + 0.5*vec2(clt_w, clt_h) - Cursor).mod() < CP_R) {
				CP_selected = i, prev_CP = CP[i]; break;
			}
		}
		prevCursor = Cursor, prev_C = Center;
		render();
		break;
	}
	case WM_LBUTTONUP: {
		ReleaseCapture();
		mouse_down = false;
		CP_selected = -1;
		render();
		break;
	}
	case WM_RBUTTONDOWN: {
		mouse_down = false;
		renderGradient ^= 1;
		render();
	}
	}
	return DefWindowProc(hWnd, message, wParam, lParam);

}


int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {

	for (int i = 0; i < 256; i++) CP[i] = vec2(NAN, NAN);
	init();

	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = _T(WIN_NAME);
	if (!RegisterClassEx(&wc)) return -1;


	HWnd = CreateWindow(
		_T(WIN_NAME),
		_T(WIN_NAME),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		600, 400,
		NULL, NULL, hInstance, NULL
	);

	ShowWindow(HWnd, nCmdShow); UpdateWindow(HWnd);


	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	return (int)message.wParam;
}


