#pragma once

#ifndef _INC_RC_BASIC
#include "RC_basic.h"
#endif

class RT_Cone : public RT_Object {	// without base
	mat3 M, M_invert;
	double k2;
public:
	vec3 C, dir; double h, r;	// vertex, direction vector, height, radius of base
	virtual void init() {
		if (h < 0) h = -h, dir = -dir;
		if (r < 0) r = -r; k2 = (r * r) / (h * h);
		dir /= dir.mod();
		double rz = atan2(dir.x, -dir.y), rx = atan2(hypot(dir.x, dir.y), dir.z);
		M.init(); M.rotate_zx(rz, rx);
		M_invert = M.invert();
	}
	virtual void debug_output(wostream& os) const {
		os << "Translate(Rotate(Rotate(Surface(" << r << "*v*cos(u)," << r << "*v*sin(u)," << h << "*v,u,0,2*pi,v,0,1)," << atan2(hypot(dir.x, dir.y), dir.z) << ",xAxis)," << atan2(dir.x, -dir.y) << ",zAxis),Vector(" << C << "))";
	}

	RT_Cone() {}
	RT_Cone(cv3ref C, cv3ref dir, cdref h, cdref r) : C(C), dir(dir), h(h), r(r) { init(); }
	RT_Cone(cv3ref C, cv3ref dir, cdref h, cdref r, vec3 col) : C(C), dir(dir), h(h), r(r) { this->col = col; init(); }
	RT_Cone(cv3ref V, cv3ref B, cdref r) : C(V), r(r) { dir = B - V, h = dir.mod(); init(); }
	RT_Cone(cv3ref V, cv3ref B, cdref r, vec3 col) : C(V), r(r) { dir = B - V, h = dir.mod(); this->col = col; init(); }
	RT_Cone(const RT_Cone &other) :C(other.C), dir(other.dir), h(other.h), r(other.r) { col = other.col; init(); }
	RT_Cone& operator = (const RT_Cone &other) { C = other.C, dir = other.dir, h = other.h, r = other.r, col = other.col; init(); return *this; }
	~RT_Cone() {}

	virtual RT_BBox getMaxMin() const {
		RT_BBox R;
		double rz = atan2(dir.x, -dir.y), rx = atan2(hypot(dir.x, dir.y), dir.z), u, v, e1, e2;
		u = -atan(cos(rx)*tan(rz));
		e1 = r * (cos(u)*cos(rz) - sin(u)*cos(rx)*sin(rz));
		u += PI; e2 = r * (cos(u)*cos(rz) - sin(u)*cos(rx)*sin(rz));
		v = h * sin(rx)*sin(rz);
		R.Max.x = e1 + v, R.Min.x = e2 + v;
		u = atan(cos(rx) / tan(rz));
		e1 = r * (cos(u)*sin(rz) + sin(u)*cos(rx)*cos(rz));
		u += PI; e2 = r * (cos(u)*sin(rz) + sin(u)*cos(rx)*cos(rz));
		v = h * sin(rx)*cos(rz);
		R.Max.y = e1 - v, R.Min.y = e2 - v;
		v = h * cos(rx);
		R.Max.z = r * sin(rx) + v, R.Min.z = -r * sin(rx) + v;
		R.init();
		if ((R.Max.x < 0) ^ (R.Min.x > 0)) R.Max.x < 0 ? R.Max.x = 0 : R.Min.x = 0;
		if ((R.Max.y < 0) ^ (R.Min.y > 0)) R.Max.y < 0 ? R.Max.y = 0 : R.Min.y = 0;
		if ((R.Max.z < 0) ^ (R.Min.z > 0)) R.Max.z < 0 ? R.Max.z = 0 : R.Min.z = 0;
		R.Max += C, R.Min += C;
		return R;
	}
	virtual bool intersect(cv3ref P, cv3ref d, double &t, vec3 &n) const {
		vec3 p = M_invert * (P - C), nd = M_invert * d;
		double a = nd.x*nd.x + nd.y*nd.y - k2 * nd.z*nd.z, b = nd.x*p.x + nd.y*p.y - k2 * nd.z*p.z;
		double delta = b * b - a * (p.x*p.x + p.y*p.y - k2 * p.z*p.z); if (delta <= 0) return false;
		delta = sqrt(delta) / a; b /= -a;
		a = b - delta, b += delta; if (a > b) delta = a, a = b, b = delta;
		t = a, delta = p.z + t * nd.z;
		if (t < RT_EPSILON || delta < 0 || delta > h) {
			t = b, delta = p.z + t * nd.z;
			if (t < RT_EPSILON || delta < 0 || delta > h) return false;
		}
		n = p + t * nd; n.z = -k2 * n.z; n /= n.mod(); n = M * n; //if (dot(d, n) > 0) n = -n;
		return true;
	}

};


