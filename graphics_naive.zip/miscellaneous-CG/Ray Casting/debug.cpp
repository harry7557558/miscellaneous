
#pragma warning(disable:4244 4018 4010 4305)

#include <Windows.h>
#include <windowsx.h>
#include <tchar.h>

using namespace std;

#include <chrono>
typedef chrono::high_resolution_clock NTime;
typedef chrono::duration<double> fsec;

#include "RC.h"

#include <string>
#include <vector>


#define WIN_NAME " raymarching demo"

HWND HWnd;
int clt_w, clt_h;
COLORREF *img; HBITMAP HImg;

vec3 Pos(12, 5, 6), prevPos;
double Unit = 300;
vec2 Cursor, prevCursor;

affine3 fromWorld;
void recalcMatrix() {
	fromWorld.init();
	fromWorld.translate(-Pos);
	double rz = atan2(-Pos.x, Pos.y), rx = atan2(hypot(Pos.x, Pos.y), -Pos.z);
	fromWorld.rotate_z(-rz); fromWorld.rotate_x(PI - rx); fromWorld.rotate_z(PI);
	fromWorld.translate(0, 0, 1);
	fromWorld.perspective(-1);
	fromWorld.scale(Unit);
	fromWorld.translate(0.5*clt_w, 0.5*clt_h);
}



vector<RT_Object*> Objs;
void model() {
	Objs.push_back(new RT_Triangle(vec3(-5, -5, 3), vec3(-6, -5, 0.2), vec3(-4, -5, 0.2), vec3(160, 82, 45) / 256));
	Objs.push_back(new RT_Circle(vec3(-5, 0, 1.8), vec3(1.2, 1.5, 2), 1.0, vec3(255, 165, 0) / 256));
	Objs.push_back(new RT_Parallelogram(vec3(-5, 5, 0.2), vec3(0.8, 0.5, 1.2), vec3(-0.6, -0.8, 1), vec3(160, 82, 45) / 256));
	Objs.push_back(new RT_Ellipsoid(vec3(0, -5, 1.6), vec3(0.6, 0, 0.5), vec3(0, 0.5, 0.6), 1.2, vec3(176, 224, 230) / 256));
	Objs.push_back(new RT_Torus(vec3(0, 0, 2.6), vec3(1, 0.7, 1), 1, 0.3, vec3(255, 235, 205) / 256));
	Objs.push_back(new RT_Sphere(vec3(0, 5, 1.8), 1, vec3(221, 160, 221) / 256));
	Objs.push_back(new RT_Cone(vec3(5, -5, 2.2), vec3(5, -5, 0.2), 1, vec3(238, 232, 170) / 256));
	Objs.push_back(new RT_Cylinder(vec3(5.6, -0.5, 0.8), vec3(4.4, 0.5, 1.6), 0.8, vec3(152, 251, 152) / 256));
	Objs.push_back(new RT_BilinearPatch(vec3(4, 6, 1.6), vec3(5.8, 5.8, 0.4), vec3(6, 4, 1.6), vec3(4.2, 4.2, 0.4), vec3(169, 169, 169) / 256));
	Objs.push_back(new RT_Bezier2(vec3(-3.5, -4, 0), vec3(0.1, -3.8, 1.3), vec3(3.8, -4.6, 0), vec3(-1.8, 0.4, 0), vec3(0.4, 1, 3.7), vec3(2.1, -0.4, 0), vec3(-3.9, 4.3, 0), vec3(1.3, 4, 1.6), vec3(4.8, 4.5, 0), vec3(255, 255, 255) / 256));
}

UINT64 Total_Ray = 0;
vec3 traceRay(cv3ref P, cv3ref d, int N) {
	if (N > 50) {
		double k = d.z; if (k < 0) k = 0;
		return vec3(k, k, k);
	}
	else Total_Ray++;

	double t, min_t; vec3 n, min_n; RT_Object* obj = 0;
	min_t = -P.z / d.z; if (min_t < RT_EPSILON) min_t = INFINITY;

	for (int i = 0; i < Objs.size(); i++) {
		if (Objs.at(i)->intersect(P, d, t, n) && t < min_t) min_t = t, min_n = n, obj = Objs.at(i);
	}
	t = min_t, n = min_n;

	if (obj) {
		vec3 p = P + t * d;
		vec3 col = traceRay(p, d - 2 * dot(d, n) * n, N + 1);
		return col * obj->col;
	}
	else {
		if (isNaN(t)) {		// intersect nothing
			double k = d.z; if (k < 0) k = 0;
			return vec3(k, k, k);
		}

		// intersect the plane
		vec3 p = P + t * d;
		vec3 col = traceRay(p, vec3(d.x, d.y, -d.z), N + 1);
		vec3 r = ((int(p.x) & 1) ^ (int(p.y) & 1)) ? vec3(135, 206, 250) / 256 : vec3(148, 166, 188) / 256;		// grid
		if (abs(p.y) < 0.05) r = 0.5 * (r + vec3(1, 0, 0));
		if (abs(p.x) < 0.05) r = 0.5 * (r + vec3(0, 0.5, 0));	// x and y axis
		return col * r;
	}
}



void render() {
	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);


	recalcMatrix();
	affine3 M = RotationMatrix_zx(atan2(-Pos.x, Pos.y), atan2(hypot(Pos.x, Pos.y), -Pos.z));
	vec3 O = M * vec3(0.5*clt_w / Unit, -0.5*clt_h / Unit, 1), A = M * vec3(-clt_w / Unit, 0), B = M * vec3(0, clt_h / Unit), P;

	auto t0 = NTime::now();
	Total_Ray = 0;

	for (int y = 0; y < clt_h; y++) {
		for (int x = 0; x < clt_w; x++) {
			vec3 d = (O + (x / double(clt_w))*A + (y / double(clt_h))*B).unitvec();
			COLORf col = *(COLORf*)&traceRay(Pos, d, 0);
			img[y*clt_w + x] = toCOLORREF(col);
		}
	}

	double dt = fsec(NTime::now() - t0).count();
	auto uint2str = [](unsigned n)->string {
		string r;
		while (n) r = char('0' + n % 10) + r, n /= 10;
		return r;
	};
	auto fps2str = [](double a)->string {
		if (a <= 0 || a > 2000 || isNaN(a)) return "###";
		int e = 3;
		while (a < 100) a *= 10, e--;
		string r;
		while (a != 0) r = char('0' + int(a) % 10) + r, a = int(a) / 10;
		while (e <= 0) r = '0' + r, e++;
		if (e < 3) r.insert(r.begin() + e, '.');
		return r;
	};
	SetWindowTextA(HWnd, &(" Elapsed Time: " + fps2str(dt) + "secs  (" + fps2str(1 / dt) + "fps, " + fps2str(Total_Ray / dt / 1e+6) + "Mrps)")[0]);

	// note that this demo only uses one core



	// axis on the top right corner
	M = fromWorld; M.translate(0.5*clt_w - 0.2*Unit, 0.5*clt_h - 0.2*Unit);
	double m = 0.15 * Pos.mod();
	O = M * vec3(0, 0, 0); vec3 I = M * vec3(m, 0, 0), J = M * vec3(0, m, 0), K = M * vec3(0, 0, m);
	drawLine(img, clt_w, clt_h, O.x, O.y, I.x, I.y, 0.006*Unit, _RGB(255, 0, 0));
	drawLine(img, clt_w, clt_h, O.x, O.y, J.x, J.y, 0.006*Unit, _RGB(0, 128, 0));
	drawLine(img, clt_w, clt_h, O.x, O.y, K.x, K.y, 0.006*Unit, _RGB(0, 0, 255));




	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);
}








bool mouse_down = false;

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {

	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, int w, int h, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)h : (long)h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};

	switch (message) {
	case WM_CREATE: {
		RECT Client; GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		model();
		break;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		RECT Client; GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		Unit *= sqrt((clt_w * clt_h) / (prev_w * prev_h));
		DeleteObject(HImg);
		InitializeClientBitmap(hWnd, HImg, img, clt_w, clt_h, false);
		render();
		break;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 300, lpMMI->ptMinTrackSize.y = 200;
		break;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HMem, HImg);
		BitBlt(hdc, 0, 0, clt_w, clt_h, HMem, 0, 0, SRCCOPY);
		SelectObject(HMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HMem);
		DeleteDC(hdc);
		break;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		for (int i = 0; i < Objs.size(); i++) delete Objs.at(i);
		Objs.clear();
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
	case WM_MOUSEMOVE: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		if (mouse_down) {
			vec2 dC = 5 * (prevCursor - Cursor) / Unit;
			Pos = RotationMatrix_z(dC.x) * prevPos;
			double a = acos(Pos.unitvec().z);
			if (a - dC.y < 1e-6) dC.y = a - 1e-6;
			if (a - dC.y > 1.5) dC.y = a - 1.5;
			Pos = RotationMatrix(cross(Pos, vec3(0, 0, 1)), dC.y) * Pos;
		}
		render();
		break;
	}
	case WM_MOUSEWHEEL: {
		int delta = GET_WHEEL_DELTA_WPARAM(wParam);
		Pos /= exp(0.0008 * delta);
		render();
		break;
	}
	case WM_LBUTTONDOWN: {
		mouse_down = true;
		SetCapture(hWnd);
		prevCursor = Cursor, prevPos = Pos;
		render();
		break;
	}
	case WM_LBUTTONUP: {
		ReleaseCapture();
		mouse_down = false;
		render();
		break;
	}
	}
	return DefWindowProc(hWnd, message, wParam, lParam);

}


int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {

	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = _T(WIN_NAME);
	if (!RegisterClassEx(&wc)) return -1;


	HWnd = CreateWindow(
		_T(WIN_NAME),
		_T(WIN_NAME),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		600, 400,
		NULL, NULL, hInstance, NULL
	);

	ShowWindow(HWnd, nCmdShow); UpdateWindow(HWnd);


	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	return (int)message.wParam;
}


