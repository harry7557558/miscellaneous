#pragma once

#ifndef _INC_RC_BASIC
#include "RC_basic.h"
#endif

class RT_Cylinder : public RT_Object {	// without base
	mat3 M, M_invert;
	double r2;
	double c_x2, c_y2, c_z2, c_xy, c_xz, c_yz;
public:
	vec3 C, dir; double h, r;	// center, direction vector, length, radius
	virtual void init() {
		if (h < 0) h = -h, dir = -dir;
		if (r < 0) r = -r; r2 = r * r;
		dir /= dir.mod();
		double rz = atan2(dir.x, -dir.y), rx = atan2(hypot(dir.x, dir.y), dir.z);
		M.init(); M.rotate_zx(rz, rx);
		M_invert = M.invert();

		auto cos2 = [](double t) {return cos(t)*cos(t); }; auto sin2 = [](double t) {return sin(t)*sin(t); };
		c_x2 = cos2(rz) + cos2(rx)*sin2(rz), c_y2 = sin2(rz) + cos2(rx)*cos2(rz), c_z2 = sin2(rx), \
			c_xy = 2 * sin2(rx)*sin(rz)*cos(rz), c_xz = -2 * sin(rx)*cos(rx)*sin(rz), c_yz = 2 * sin(rx)*cos(rx)*cos(rz);
	}
	virtual void debug_output(wostream& os) const {
		//os << "Cylinder(" << C << "," << (C + l * dir) << "," << r << ")";
		os << "Translate(Rotate(Rotate(Surface(" << r << "*cos(u)," << r << "*sin(u),v,u,0,2*pi,v,0," << h << ")," << atan2(hypot(dir.x, dir.y), dir.z) << ",xAxis)," << atan2(dir.x, -dir.y) << ",zAxis),Vector(" << C << "))";
	}

	RT_Cylinder() {}
	RT_Cylinder(cv3ref C, cv3ref dir, cdref h, cdref r) : C(C), dir(dir), h(h), r(r) { init(); }
	RT_Cylinder(cv3ref C, cv3ref dir, cdref h, cdref r, vec3 col) : C(C), dir(dir), h(h), r(r) { this->col = col; init(); }
	RT_Cylinder(cv3ref A, cv3ref B, cdref r) : C(A), r(r) { dir = B - A, h = dir.mod(); init(); }
	RT_Cylinder(cv3ref A, cv3ref B, cdref r, vec3 col) : C(A), r(r) { dir = B - A, h = dir.mod(); this->col = col; init(); }
	RT_Cylinder(const RT_Cylinder &other) :C(other.C), dir(other.dir), h(other.h), r(other.r) { col = other.col; init(); }
	RT_Cylinder& operator = (const RT_Cylinder &other) { C = other.C, dir = other.dir, h = other.h, r = other.r, col = other.col; init(); return *this; }
	~RT_Cylinder() {}

	virtual RT_BBox getMaxMin() const {
		RT_BBox R;
		double rz = atan2(dir.x, -dir.y), rx = atan2(hypot(dir.x, dir.y), dir.z), u, v, e1, e2;
		u = -atan(cos(rx)*tan(rz));
		e1 = r * (cos(u)*cos(rz) - sin(u)*cos(rx)*sin(rz));
		u += PI; e2 = r * (cos(u)*cos(rz) - sin(u)*cos(rx)*sin(rz));
		v = h * sin(rx)*sin(rz);
		R.Max.x = max(e1, e2) + max(0, v), R.Min.x = min(e1, e2) + min(0, v);
		u = atan(cos(rx) / tan(rz));
		e1 = r * (cos(u)*sin(rz) + sin(u)*cos(rx)*cos(rz));
		u += PI; e2 = r * (cos(u)*sin(rz) + sin(u)*cos(rx)*cos(rz));
		v = h * sin(rx)*cos(rz);
		R.Max.y = max(e1, e2) - min(0, v), R.Min.y = min(e1, e2) - max(0, v);
		v = h * cos(rx);
		R.Max.z = abs(r*sin(rx)) + max(0, v), R.Min.z = -abs(r*sin(rx)) + min(0, v);
		R.Max += C, R.Min += C;
		return R;
	}
	virtual bool intersect(cv3ref P, cv3ref d, double &t, vec3 &n) const {
		vec3 p = M_invert * (P - C), nd = M_invert * d;
		double a = nd.xy().sqr(), b = dot(p.xy(), nd.xy());
		double delta = b * b - a * (p.xy().sqr() - r2); if (delta <= 0) return false;
		delta = sqrt(delta) / a, b /= -a;
		a = b - delta, b += delta; if (a > b) delta = a, a = b, b = delta;
		t = a, delta = p.z + t * nd.z;
		if (t < RT_EPSILON || delta < 0 || delta > h) {
			t = b, delta = p.z + t * nd.z;
			if (t < RT_EPSILON || delta < 0 || delta > h) return false;
		}
		n = M * vec3((p.xy() + t * nd.xy()) / r); //if (dot(d, n) > 0) n = -n;
		return true;
	}
	virtual bool intersect_new(cv3ref P, cv3ref d, double &t, vec3 &n) const {	// doesn't make it faster
		vec3 p = P - C;
		double a = 2 * (c_x2 * d.x*d.x + c_y2 * d.y*d.y + c_z2 * d.z*d.z + c_xy * d.x*d.y + c_xz * d.x*d.z + c_yz * d.y*d.z);
		double b = c_x2 * 2 * d.x*p.x + c_y2 * 2 * d.y*p.y + c_z2 * 2 * d.z*p.z + c_xy * (d.x*p.y + d.y*p.x) + c_xz * (d.x*p.z + d.z*p.x) + c_yz * (d.y*p.z + d.z*p.y);
		double delta = b * b - 2 * a * (c_x2 * p.x*p.x + c_y2 * p.y*p.y + c_z2 * p.z*p.z + c_xy * p.x*p.y + c_xz * p.x*p.z + c_yz * p.y*p.z - r2); if (delta <= 0) return false;
		delta = sqrt(delta); delta /= a, b /= -a;
		a = b - delta, b += delta; if (a > b) delta = a, a = b, b = delta; if (b < RT_EPSILON) return false;
		if (a > RT_EPSILON) {
			t = a, n = p + t * d, a = dot(n, dir);
			if (a > 0 && a < h) {
				n -= a * dir; n /= r; return true;
			}
		}
		t = b, n = p + t * d, b = dot(n, dir);
		if (b < 0 || b > h) return false;
		n -= b * dir; n /= r; return true;
	}

};


