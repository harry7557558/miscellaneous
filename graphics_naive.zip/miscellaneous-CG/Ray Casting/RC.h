#pragma once

#ifndef _INC_RC_BASIC
#include "RC_basic.h"
#endif


#include "RC_Plane.h"
#include "RC_Triangle.h"
#include "RC_Parallelogram.h"
#include "RC_Circle.h"
#include "RC_Sphere.h"
#include "RC_Ellipsoid.h"
#include "RC_Cylinder.h"
#include "RC_Cone.h"
#include "RC_Bezier1.h"
#include "RC_Torus.h"
#include "RC_Bezier2.h"



wostream& operator << (wostream& os, const RT_Object &p) {
	p.debug_output(os);
	return os;
}



