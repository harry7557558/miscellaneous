# All supported vector objects:

<img src="https://github.com/Harry7557558/miscellaneous/blob/CG/Ray%20Casting/example.jpg?raw=true" alt=""></img>
<br/>1.2 secs to render, single thread, 1 sample per pixel

<hr/>


Include [RC_basic.h](RC_basic.h) for basic definations. 

Include RC_<i>object_name</i>.h for single object. 

Include [RC.h](RC.h) for all functions. 

<hr/>


# 2D object defined by SDF

<img src="https://github.com/Harry7557558/miscellaneous/blob/CG/Ray%20Casting/example_sdf2.png?raw=true" alt=""></img>
<br/>L: 15 mins solving the rendering equation; &ensp; R: real-time visualization;

<br/>

View [SDF_2D.h](SDF_2D.h) for details; Create new SDFs and operations of your own.




