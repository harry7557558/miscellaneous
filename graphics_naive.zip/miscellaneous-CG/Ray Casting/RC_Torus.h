#pragma once

#ifndef _INC_RC_BASIC
#include "RC_basic.h"
#endif

class RT_Torus : public RT_Object {
	mat3 M, M_Invert;
	double _4R2, R2pr2, R2mr2;
	RT_BBox Border;
public:
	vec3 C, n; double R, r;
	// (x² + y² + z² + R² - r²)² - 4R² (x² + y²) = 0
	// or { cos(u) (R + r cos(v)), sin(u) (R + r cos(v)), r sin(v) }, 0 < u < 2π, 0 < v < 2π
	virtual void init() {
		if (R < 0) R = -R; if (r < 0) r = -r;
		_4R2 = 4 * R * R, R2pr2 = R * R + r * r, R2mr2 = R * R - r * r;
		n /= n.mod();
		M = RotationMatrix_zx(atan2(n.x, -n.y), atan2(hypot(n.x, n.y), n.z)), M_Invert = M.invert();
		Border.Max = vec3(R + r, R + r, r), Border.Min = -Border.Max;
	}
	virtual void debug_output(wostream& os) const {
		os << "Translate(Rotate(Rotate(Surface(cos(u)*(" << noshowpos << R << showpos << r << "*cos(v)),sin(u)*(" << noshowpos << R << showpos << r << "*cos(v))," << noshowpos << r << "*sin(v),u,0,2*pi,v,0,2*pi),"
			<< atan2(hypot(n.x, n.y), n.z) << ",xAxis)," << atan2(n.x, -n.y) << ",zAxis),Vector(" << C << "))";
	}

	RT_Torus(cv3ref C, cdref R, cdref r) :C(C), R(R), r(r), n(0, 0, 1) { init(); }
	RT_Torus(cv3ref C, cdref R, cdref r, vec3 col) :C(C), R(R), r(r), n(0, 0, 1) { this->col = col; init(); }
	RT_Torus(cv3ref C, cv3ref n, cdref R, cdref r) :C(C), n(n), R(R), r(r) { init(); }
	RT_Torus(cv3ref C, cv3ref n, cdref R, cdref r, vec3 col) :C(C), n(n), R(R), r(r) { this->col = col; init(); }
	RT_Torus(const RT_Torus &other) :C(other.C), R(other.R), r(other.r), n(other.n) { this->col = other.col; init(); }
	RT_Torus& operator = (const RT_Torus &other) { C = other.C, R = other.R, r = other.r, n = other.n, col = other.col; init(); return *this; }
	~RT_Torus() {}

	virtual RT_BBox getMaxMin() const {
		double u, v;
		RT_BBox Res;
		u = atan(M[0][1] / M[0][0]), v = atan(M[0][2] / (M[0][0] * cos(u) + M[0][1] * sin(u)));
		Res.Min.x = M[0][0] * cos(u)*(R + r * cos(v)) + M[0][1] * sin(u)*(R + r * cos(v)) + M[0][2] * r * sin(v);
		u += PI, v = -v;
		Res.Max.x = M[0][0] * cos(u)*(R + r * cos(v)) + M[0][1] * sin(u)*(R + r * cos(v)) + M[0][2] * r * sin(v);
		u = atan(M[1][1] / M[1][0]), v = atan(M[1][2] / (M[1][0] * cos(u) + M[1][1] * sin(u)));
		Res.Min.y = M[1][0] * cos(u)*(R + r * cos(v)) + M[1][1] * sin(u)*(R + r * cos(v)) + M[1][2] * r * sin(v);
		u += PI, v = -v;
		Res.Max.y = M[1][0] * cos(u)*(R + r * cos(v)) + M[1][1] * sin(u)*(R + r * cos(v)) + M[1][2] * r * sin(v);
		u = atan(M[2][1] / M[2][0]), v = atan(M[2][2] / (M[2][0] * cos(u) + M[2][1] * sin(u)));
		Res.Min.z = M[2][0] * cos(u)*(R + r * cos(v)) + M[2][1] * sin(u)*(R + r * cos(v)) + M[2][2] * r * sin(v);
		u += PI, v = -v;
		Res.Max.z = M[2][0] * cos(u)*(R + r * cos(v)) + M[2][1] * sin(u)*(R + r * cos(v)) + M[2][2] * r * sin(v);
		Res.Max += C, Res.Min += C;
		Res.init();
		return Res;
	}
	virtual bool intersect(cv3ref P, cv3ref D, double &t, vec3 &n) const {
		vec3 p = M_Invert * (P - C), d = M_Invert * D;
		double c0 = p.sqr() + R2mr2, c1 = 2 * dot(p, d), c2 = d.sqr();
		if (c0*c0 > _4R2*p.xy().sqr()) if (!Border.intersect(p, d)) return false;
		double c[5] = { c0 * c0 - _4R2 * p.xy().sqr(), 2 * c0*c1 - _4R2 * 2 * dot(d.xy(),p.xy()), 2 * c0 * c2 + c1 * c1 - _4R2 * d.xy().sqr(), 2 * c1 * c2, c2 * c2 };
		double s[4]; int N; if (!(N = SolveQuartic(c, s))) return false;
		t = INFINITY; for (int i = 0; i < N; i++) if (s[i] > RT_EPSILON && s[i] < t) t = s[i];
		if (isNaN(t)) return false;
		p = p + t * d; c2 = p.sqr(), c0 = c2 - R2pr2, c1 = c2 + R2mr2;
		n = M * vec3(p.x*c0, p.y*c0, p.z*c1); n /= n.mod();
		return true;
	}
};


