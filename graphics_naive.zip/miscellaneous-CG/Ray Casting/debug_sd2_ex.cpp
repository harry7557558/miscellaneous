// non-realtime debugger, without window, directly write to file

#pragma warning(disable:4244 4018 4010 4305)
//#pragma optimize("",off)

#include "Windows.h"
#include "SDF_2D.h"

using namespace std;


// light source
const vec3 CBulb(5, 5, 5);
const double RBulb = 2;
const double LBulb = 2;


inline double map(cv2ref P) {
	double sd = INFINITY;
	{
		vec2 p = P;
		sd = min(sd, sd_Ellipse(1.6, 1.2, vec2(p.x, p.y + 0.2)));
		double ear = sd_Triangle(vec2(0.45, 0.76), vec2(1.26, 1.42), vec2(1.18, 0.36), vec2(abs(p.x), p.y)) - 0.15; sd = sd_OpSmoothedUnion(sd, ear, 0.2);
		double eye = sd_Circle(0.22, vec2(abs(p.x) - 0.63, p.y - 0.13)); sd = sd_OpSubtract(sd, eye);
		double beard = min(sd_Box(vec2(1.33, -0.39), vec2(2.02, -0.16), vec2(abs(p.x), p.y)),
			sd_Polygon({ vec2(1.37, -0.53), vec2(1.19, -0.81), vec2(1.90, -1.00), vec2(1.98, -0.82) }, vec2(abs(p.x), p.y))) - 0.03; sd = sd_OpSmoothedUnion(sd, beard, 0.05);
	}
	//sd = P.mod() - 1;
	//sd = sd_Box(vec2(-1.618, -1), vec2(1.618, 1), P);
	return 0.999 * min(sd, sd_Circle(RBulb, P - CBulb));
}


#define EPSILON 1e-6
inline vec2 calcNormal(cv2ref p) {
	vec2 r;
	r.x = (map(vec2(p.x + EPSILON, p.y)) - map(vec2(p.x - EPSILON, p.y))) / EPSILON;
	r.y = (map(vec2(p.x, p.y + EPSILON)) - map(vec2(p.x, p.y - EPSILON))) / EPSILON;
	return r.unitvec();
}

#define INDEX 1.5
bool calcRefract(vec2 s, vec2 n, double c, vec2 &t, double &r) {		// ray in, normal, index, ray out, rate of reflection
	if (dot(s, n) > 0) n = -n;
	vec2 m(n.y, -n.x);
	double a1 = dot(s, m), a2 = c * a1; if (a1 < 0) a1 = -a1, a2 = -a2, m = -m;
	if (a2 > 1) return false;
	t = a2 * m - sqrt(1 - a2 * a2)*n; t /= t.mod();
	a1 = asin(a1), a2 = asin(a2);
	double rs = sin(a1 - a2) / sin(a1 + a2), rp = tan(a1 - a2) / tan(a1 + a2);
	r = 0.5*(rs * rs + rp * rp);
	return true;
}



#define MAX_STEP 64
#define MAX_RCSN 4
double traceRay(vec2 p, vec2 d, int N) {
	if (N > MAX_RCSN) return 0;
	double t = N ? 100 * EPSILON : 0.0, dt;
	bool sgn = signbit(map(p + t * d));
	for (int i = 0; i < MAX_STEP; i++) {
		dt = abs(map(p + t * d));
		t += dt;
		if (dt < EPSILON) {
			p += t * d;
			if ((p - CBulb).mod() - RBulb <= EPSILON) return LBulb;
			if (sgn) {
				vec2 n = calcNormal(p);
				vec2 s; double r;
				if (calcRefract(d, n, INDEX, s, r)) return r * traceRay(p, d - 2 * dot(d, n)*n, N + 1) + (1 - r) * traceRay(p, s, N + 1);
				else return traceRay(p, d - 2 * dot(d, n)*n, N + 1);
			}
			else {
				vec2 n = calcNormal(p);
				vec2 s; double r;
				calcRefract(d, n, 1 / INDEX, s, r);
				return r * traceRay(p, d - 2 * dot(d, n)*n, N + 1) + (1 - r) * traceRay(p, s, N + 1);
			}
		}
		if (dt > 10) return 0;
	}
	return 0;
}



#define NSample 256
double sample(vec2 p) {		// Monte Carlo method
	if ((p - CBulb).sqr() < RBulb*RBulb) return LBulb;
	double sum = 0;
	for (int i = 0; i < NSample; i++) {
		double a = 2 * PI * (i + pick_random(1)) / NSample;
		sum += traceRay(p, vec2(cos(a), sin(a)), 0);
	}
	return sum / NSample;
}




#include <thread>

#define W 600
#define H 400
#define S 80.0
int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
	traceRay(vec2(0, 0), vec2(1, 1).unitvec(), 0);
	//exit(0);

	COLORREF *img = new COLORREF[W*H];

	unsigned L = W * H;
	const unsigned MAX_THREADS = thread::hardware_concurrency();
	const unsigned ppt = 0x1000;
	const unsigned N = L / ppt;

	bool* fn = new bool[MAX_THREADS]; for (int i = 0; i < MAX_THREADS; i++) fn[i] = false;
	thread** T = new thread*[MAX_THREADS]; for (int i = 0; i < MAX_THREADS; i++) T[i] = NULL;

	unsigned released = 0, finished = 0;
	while (finished < N) {
		for (int i = 0; i < MAX_THREADS; i++) {
			if (fn[i]) {
				fn[i] = false;
				delete T[i]; T[i] = 0;
				if (++finished >= N) break;
				dout(finished << " of total " << N << " threads have finished. " << endl);
			}
			if (!fn[i] && !T[i] && released < N) {
				T[i] = new thread([&](unsigned beg, unsigned end, bool* sig) {
					COLORf col; double c;
					for (unsigned i = beg; i < end; i++) {
						c = sample((vec2(i % W, i / W) - 0.5*vec2(W, H)) / S);
						col = RGBf(c, c, c);
						img[i] = toCOLORREF(col);
					}
					*sig = true;
				}, ppt * released, ppt * (released + 1), fn + i);
				T[i]->detach();
				released++;
			}
		}
		Sleep(1);
	}

	COLORf col; double c;
	for (unsigned i = N * ppt; i < L; i++) {
		c = sample((vec2(i % W, i / W) - 0.5*vec2(W, H)) / S);
		col = RGBf(c, c, c);
		img[i] = toCOLORREF(col);
	}

	delete fn;
	delete T;


	saveBitmap(img, W, H, "C:\\Users\\harry\\Desktop\\Test\\debug.bmp");
	delete img;
	return 0;
}


