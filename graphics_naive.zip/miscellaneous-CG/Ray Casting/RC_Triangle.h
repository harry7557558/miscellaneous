#pragma once

#ifndef _INC_RC_BASIC
#include "RC_basic.h"
#endif

class RT_Triangle : public RT_Object {
	vec3 n, K, E1, E2;
public:
	vec3 A, B, C;	// O + u A + v B,  0 ≤ u,v < 1
	virtual void init() {
		E1 = B - A, E2 = C - A;
		K = cross(E1, E2);
		n = K.unitvec();
	}
	virtual void debug_output(wostream& os) const {
		os << "Surface(" << (C - B) << "*u*v+" << (B - A) << "*u+" << A << ",u,0,1,v,0,1)";
	}

	RT_Triangle() {}
	RT_Triangle(cv3ref A, cv3ref B, cv3ref C) :A(A), B(B), C(C) { init(); }
	RT_Triangle(cv3ref A, cv3ref B, cv3ref C, vec3 col) :A(A), B(B), C(C) { this->col = col; init(); }
	RT_Triangle(const RT_Triangle &other) :A(other.A), B(other.B), C(other.C) { col = other.col; init(); }
	RT_Triangle& operator = (const RT_Triangle &other) { A = other.A, B = other.B, C = other.C, col = other.col; init(); return *this; }
	~RT_Triangle() {}


	virtual RT_BBox getMaxMin() const {
		return RT_BBox(PMin(A, PMin(B, C)), PMax(A, PMax(B, C)));
	}
	virtual bool intersect(cv3ref P, cv3ref d, double &t, vec3 &n) const {
		vec3 S = P - A, N = cross(S, d);
		double det = -dot(K, d); if (abs(det) < RT_EPSILON) return false;
		double u = dot(N, E2) / det; if (u < 0 || u > 1) return false;
		double v = -dot(N, E1) / det; if (v < 0 || u + v > 1) return false;
		t = dot(K, S) / det; if (t < RT_EPSILON) return false;
		n = det > 0 ? this->n : -this->n; return true;
	}

};

