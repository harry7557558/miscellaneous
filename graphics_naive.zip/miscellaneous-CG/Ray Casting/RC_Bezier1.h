#pragma once

#ifndef _INC_RC_BASIC
#include "RC_basic.h"
#endif

class RT_BilinearPatch : public RT_Object {
	vec3 K, M, N;
	RT_BBox Border;
public:
	vec3 A, B, C, D;	//  (1-u) (1-v) A + u (1-v) B + u v C + (1-u) v D, or  K u v + M u + N v + A

	virtual void init() {
		K = A - B + C - D, M = B - A, N = D - A;
		Border = getMaxMin();
	}
	virtual void debug_output(wostream& os) const {
		os << "Surface((1-u)*(1-v)*" << A << "+u*(1-v)*" << B << "+u*v*" << C << "+(1-u)*v*" << D << ",u,0,1,v,0,1)";
	}

	RT_BilinearPatch(cv3ref A, cv3ref B, cv3ref C, cv3ref D) :A(A), B(B), C(C), D(D) { init(); }
	RT_BilinearPatch(cv3ref A, cv3ref B, cv3ref C, cv3ref D, vec3 col) :A(A), B(B), C(C), D(D) { this->col = col; init(); }
	RT_BilinearPatch(const RT_BilinearPatch &other) :A(other.A), B(other.B), C(other.C), D(other.D) { col = other.col; init(); }
	RT_BilinearPatch& operator = (const RT_BilinearPatch &other) { A = other.A, B = other.B, C = other.C, D = other.D, col = other.col; init(); return *this; }
	~RT_BilinearPatch() {}

	virtual RT_BBox getMaxMin() const {
		return RT_BBox(PMax(PMax(A, B), PMax(C, D)), PMin(PMin(A, B), PMin(C, D)));
	}
	virtual bool intersect(cv3ref P, cv3ref D, double &t, vec3 &n) const {
		// algorithm: see http://www.sci.utah.edu/~kpotter/publications/ramsey-2004-RBPI.pdf
		if (!Border.intersect(P, D)) return false;
		vec3 R = P - A;		// K u v + M u + N v - t D - R = 0
		double a1 = D.y * K.x - D.x * K.y, b1 = D.y * M.x - D.x * M.y, c1 = D.y * N.x - D.x * N.y, d1 = D.x * R.y - D.y * R.x; 	// a1 u v + b1 u + c1 v + d1 = 0
		double a2 = D.z * K.x - D.x * K.z, b2 = D.z * M.x - D.x * M.z, c2 = D.z * N.x - D.x * N.z, d2 = D.x * R.z - D.z * R.x; 	// a2 u v + b2 u + c2 v + d2 = 0
		double v = 2 * (a2 * c1 - a1 * c2), v_ = a1 * d2 - a2 * d1 + b1 * c2 - b2 * c1, delta = v_ * v_ - 2 * v * (b2 * d1 - b1 * d2);
		if (delta < 0) return false;
		delta = sqrt(delta) / v, v_ /= v; v = v_ - delta, v_ += delta;
		double u, u_;

		u = (v*(c1 - c2) + (d1 - d2)) / (v*(a2 - a1) + (b2 - b1));
		u_ = (v_*(c1 - c2) + (d1 - d2)) / (v_*(a2 - a1) + (b2 - b1));	// Note: some are not necessary to be calculated
		t = (K.x*u*v + M.x*u + N.x*v - R.x) / D.x;
		delta = (K.x*u_*v_ + M.x*u_ + N.x*v_ - R.x) / D.x;
		if (v > 0 && v < 1 && u > 0 && u < 1 && t > RT_EPSILON) {
			if (v_ > 0 && v_ < 1 && u_ > 0 && u_ < 1 && delta > RT_EPSILON) {
				if (t > delta) t = delta, u = u_, v = v_;
			}
		}
		else {
			if (v_ > 0 && v_ < 1 && u_ > 0 && u_ < 1 && delta > RT_EPSILON) {
				t = delta, u = u_, v = v_;
			}
			else return false;
		}

		n = cross(K*v + M, K*u + N); n /= n.mod();
		return true;
	}

};
typedef RT_BilinearPatch RT_Bezier1;


