#pragma once


#include <cmath>
#include <algorithm>
using namespace std;


#pragma region Macros

#ifndef PI
#define PI 3.1415926535897932384626433832795029
#endif

#define isNaN(x) (0.0*(x)!=0.0)	// works for inf
#define Cbrt(x) ((x)>0?std::pow(x,1./3):-std::pow(-(x),1./3))

#define Floor(x) ((x)>0?int(x):int((x)-0.999999))
#define Ceil(x) ((x)>0?int((x)+0.999999):int(x))
#define Clamp(x,a,b) (((x)<(a))?(a):(((x)>(b))?(b):(x)))	// a<b
#define Lerp(x,y,a) ((1-(a))*(x)+(a)*(y))	// 0<a<1


#ifdef _INC_WINDOWS
#include <Windows.h>
#endif

#pragma endregion



#pragma region matrix, vector, quaternion

class vec2;
class vec3;
class vec4;
class mat2;
class mat3;
class affine2;
class affine3;
class complex;
class quaternion;


#define cdref const double&
#define cv3ref const vec3&
#define cv2ref const vec2&

class vec2 {
public:
	double x, y;
	friend bool isnan(const vec2 &p) { return isNaN(p.x*p.y); }

#pragma region constructors
	vec2();
	template<typename T, typename t> vec2(T x, t y);
	vec2(const vec2 &other);
	vec2(const vec3 &other);
	vec2& operator = (const vec2 &other);
	vec2& operator = (const vec3 &other);
	~vec2();
#pragma endregion

#pragma region operations
	inline double mod() const;
	inline bool operator == (const vec2 &p) const;
	inline bool operator != (const vec2 &p) const;
	inline vec2 operator + (const vec2 &p) const;
	inline void operator += (const vec2 &p);
	inline vec2 operator - () const;
	inline vec2 operator - (const vec2 &p) const;
	inline void operator -= (const vec2 &p);
	inline friend vec2 operator * (const double &c, const vec2 &p);
	inline vec2 operator * (const double &c) const;
	inline void operator *= (const double &c);
	inline vec2 operator / (const double &c) const;
	inline void operator /= (const double &c);
	inline double sqr() const;
	inline friend double dot(const vec2 &P, const vec2 &Q);
	inline friend vec3 cross(const vec2 &P, const vec2 &Q);
	inline friend double det(const vec2 &A, const vec2 &B);
#pragma endregion

#pragma region derivatives
	vec2 unitvec() const;
	vec2 xx() const; vec2 yy() const; vec2 xy() const; vec2 yx() const;		// These functions sometimes pretty useful
	vec3 xxx() const; vec3 xxy() const; vec3 xyx() const; vec3 xyy() const;
	vec3 yxx() const; vec3 yxy() const; vec3 yyx() const; vec3 yyy() const;
#pragma endregion

};

class vec3 {
public:
	double x, y, z;
	friend bool isnan(const vec3 &p) { return isNaN(p.x*p.y*p.z); }

#pragma region constructors
	vec3();
	template<typename t1, typename t2> vec3(t1 x, t2 y);
	template<typename t1, typename t2, typename t3> vec3(t1 x, t2 y, t3 z);
	vec3(double x, double y, double z) :x(x), y(y), z(z) {}
	vec3(const vec2 &other);
	vec3(const vec2 &other, const double &c);
	vec3(const double &c, const vec2 &other);
	vec3(const vec3 &other);
	vec3(const vec4 &other);
	vec3& operator = (const vec2 &other);
	vec3& operator = (const vec3 &other);
	vec3& operator = (const vec4 &other);
	~vec3();
#pragma endregion

#pragma region operations
	inline double mod() const;
	inline bool operator == (const vec3 &P) const;
	inline bool operator != (const vec3 &P) const;
	inline vec3 operator + (const vec3 &p) const;
	inline void operator += (const vec3 &p);
	inline vec3 operator - () const;
	inline vec3 operator - (const vec3 &p) const;
	inline void operator -= (const vec3 &p);
	inline friend vec3 operator * (const double &c, const vec3 &p);
	inline vec3 operator * (const double &c) const;
	inline void operator *= (const double &c);
	inline vec3 operator / (const double &c) const;
	inline void operator /= (const double &c);
	inline double sqr() const;
	inline friend double dot(const vec3 &P, const vec3 &Q);
	inline friend vec3 cross(const vec3 &P, const vec3 &Q);
	inline friend double det(const vec3 &A, const vec3 &B, const vec3 &C);
#pragma endregion

#pragma region derivatives
	inline vec3 unitvec() const;
	vec2 xx() const; vec2 xy() const; vec2 xz() const; vec2 yx() const; vec2 yy() const; vec2 yz() const; vec2 zx() const; vec2 zy() const; vec2 zz() const;
	vec3 xxx() const; vec3 xxy() const; vec3 xxz() const; vec3 xyx() const; vec3 xyy() const; vec3 xyz() const; vec3 xzx() const; vec3 xzy() const; vec3 xzz() const;
	vec3 yxx() const; vec3 yxy() const; vec3 yxz() const; vec3 yyx() const; vec3 yyy() const; vec3 yyz() const; vec3 yzx() const; vec3 yzy() const; vec3 yzz() const;
	vec3 zxx() const; vec3 zxy() const; vec3 zxz() const; vec3 zyx() const; vec3 zyy() const; vec3 zyz() const; vec3 zzx() const; vec3 zzy() const; vec3 zzz() const;
#pragma endregion

#pragma region non-standard
	vec3 operator * (const vec3 &a) const { return vec3(x*a.x, y*a.y, z*a.z); }
	vec3 operator / (const vec3 &a) const { return vec3(x / a.x, y / a.y, z / a.z); }
#pragma region apply to components

};

class vec4 {	// 3D vector used in affine transform
public:
	double x, y, z, s;
	vec4(double x, double y, double z, double s) :x(x), y(y), z(z), s(s) {}
	friend bool isnan(const vec4 &p) { return isNaN(p.x*p.y*p.z / p.s); }

#pragma region constructors
	vec4();
	template<typename t1, typename t2> vec4(t1 x, t2 y);
	template<typename t1, typename t2, typename t3> vec4(t1 x, t2 y, t3 z);
	vec4(const vec2 &other);
	vec4(const vec3 &other);
	vec4(const vec4 &other);
	vec4& operator = (const vec2 &other);
	vec4& operator = (const vec3 &other);
	vec4& operator = (const vec4 &other);
	~vec4();
#pragma endregion

#pragma region operations
	double mod() const;
	bool operator == (const vec4 &P) const;
	bool operator != (const vec4 &P) const;
	vec4 operator + (const vec4 &p) const;
	void operator += (const vec4 &p);
	vec4 operator - () const;
	vec4 operator - (const vec4 &p) const;
	void operator -= (const vec4 &p);
	friend vec4 operator * (const double &c, const vec4 &p);
	vec4 operator * (const double &c) const;
	void operator *= (const double &c);
	vec4 operator / (const double &c) const;
	void operator /= (const double &c);
#pragma endregion

};

class mat2 {
	friend class mat3;
	friend class affine2;
	friend class affine3;
public:
	double a, b, c, d;
	bool isnan() const { return isNaN(a*b*c*d); }
	double& _00() { return a; } double& _01() { return b; } double& _10() { return c; } double& _11() { return d; }
	double _00() const { return a; } double _01() const { return b; } double _10() const { return c; } double _11() const { return d; }
	void init() { a = d = 1, b = c = 0; }

#pragma region constructors
	mat2();
	mat2(cdref _00, cdref _01, cdref _10, cdref _11);
	mat2(const mat2 &m);
	mat2(const mat3 &m);
	mat2& operator = (const mat2 &m);
	mat2& operator = (const mat3 &m);
	~mat2();
#pragma endregion

#pragma region operations
	double det() const;
	mat2 invert() const;
	int rank() const;
	mat2 operator * (const double &k) const;
	mat2 operator / (const double &k) const;
	void operator *= (const double &k);
	void operator /= (const double &k);
	mat2 operator * (const mat2 &m);
	vec2 operator * (const vec2 &p);
	vec3 operator * (const vec3 &p);
#pragma endregion

#pragma region transformations
	void rotate(double theta);
	void shear_x(double r); void shear_y(double r); void shear(double x, double y);
	void reflect_x(); void reflect_y();
	void scale(double s); void scale(double x, double y);
#pragma endregion

	vec2 solve(const vec2 &x) const {
		double det = a * d - b * c;
		return vec2((x.x*d - b * x.y) / det, (a*x.y - x.x*c) / det);
	}

};

class mat3 {
	double _p[3][3];
	friend class mat2;
	friend class affine2;
	friend class affine3;
public:
	bool isnan() const { return isNaN(_p[0][0] * _p[1][1] * _p[2][2]) || isNaN(_p[0][1] * _p[0][2] * _p[1][2]) || isNaN(_p[1][0] * _p[2][0] * _p[2][1]); }
	double* operator [] (const int &k) { return &_p[k][0]; }
	const double* operator [] (const int &k) const { return &_p[k][0]; }
	inline void init() { _p[0][0] = _p[1][1] = _p[2][2] = 1, _p[0][1] = _p[0][2] = _p[1][0] = _p[1][2] = _p[2][0] = _p[2][1] = 0; }

#pragma region constructors
	mat3();
	mat3(cdref _00, cdref _01, cdref _02, cdref _10, cdref _11, cdref _12, cdref _20, cdref _21, cdref _22);
	mat3(const mat3 &m);
	mat3(const mat2 &m);
	mat3(const affine3 &m);
	mat3& operator = (const mat3 &m);
	mat3& operator = (const mat2 &m);
	mat3& operator = (const affine3 &m);
	~mat3();
#pragma endregion

#pragma region operations
	double det() const;
	mat3 invert() const;
	mat3 operator * (const double &k) const;
	mat3 operator / (const double &k) const;
	void operator *= (const double &k);
	void operator /= (const double &k);
	mat3 operator * (const mat3 &m) const;
	inline vec2 operator * (const vec2 &p) const;
	inline vec3 operator * (const vec3 &p) const;
	vec4 operator * (const vec4 &p) const;
#pragma endregion

#pragma region transformations
	mat3 unitMat() const;
	void scale(double s); void scale(double x, double y, double z);
	void rotate_x(double x); void rotate_y(double y); void rotate_z(double z);
	void rotate_zx(double z, double x); void rotate_xz(double x, double z);
	void rotate(double x, double y, double z);
	void rotate(vec3 u, double theta);
	void getRotationAngle(double &x, double &y, double &z);
#pragma endregion

	vec3 solve(const vec3 &x) const {
		double det = _p[0][0] * (_p[1][1] * _p[2][2] - _p[1][2] * _p[2][1]) - _p[0][1] * (_p[1][0] * _p[2][2] - _p[1][2] * _p[2][0]) + _p[0][2] * (_p[1][0] * _p[2][1] - _p[1][1] * _p[2][0]);
		return vec3(
			(x.x * (_p[1][1] * _p[2][2] - _p[1][2] * _p[2][1]) - _p[0][1] * (x.y * _p[2][2] - _p[1][2] * x.z) + _p[0][2] * (x.y * _p[2][1] - _p[1][1] * x.z)) / det,
			(_p[0][0] * (x.y * _p[2][2] - _p[1][2] * x.z) - x.x * (_p[1][0] * _p[2][2] - _p[1][2] * _p[2][0]) + _p[0][2] * (_p[1][0] * x.z - x.y * _p[2][0])) / det,
			(_p[0][0] * (_p[1][1] * x.z - x.y * _p[2][1]) - _p[0][1] * (_p[1][0] * x.z - x.y * _p[2][0]) + x.x * (_p[1][0] * _p[2][1] - _p[1][1] * _p[2][0])) / det
		);
	}

};

class affine2 {};

class affine3 {
	double _p[4][4];
	friend class mat2;
	friend class mat3;
	friend class affine2;
public:
	bool isnan() const { return isNaN(_p[0][0] * _p[1][1] * _p[2][2]) || isNaN(_p[0][1] * _p[0][2] * _p[1][2]) || isNaN(_p[1][0] * _p[2][0] * _p[2][1]) || isNaN(_p[0][3] * _p[1][3] * _p[2][3]) || isNaN(_p[3][0] * _p[3][1] * _p[3][2]) || isNaN(_p[3][3]); }
	double* operator [] (const int &k) { return &_p[k][0]; }
	const double* operator [] (const int &k) const { return &_p[k][0]; }
	inline void init() { for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) _p[i][j] = i == j ? 1 : 0; }

#pragma region constructors
	affine3();
	affine3(cdref _00, cdref _01, cdref _02, cdref _10, cdref _11, cdref _12, cdref _20, cdref _21, cdref _22);
	affine3(cdref _00, cdref _01, cdref _02, cdref _03, cdref _10, cdref _11, cdref _12, cdref _13, cdref _20, cdref _21, cdref _22, cdref _23, cdref _30, cdref _31, cdref _32, cdref _33);
	affine3(const double* c);
	affine3(const affine3 &m);
	affine3(const mat3 &m);
	affine3& operator = (const affine3 &m);
	affine3& operator = (const mat3 &m);
	~affine3();
#pragma endregion

#pragma region operations
	double det() const;
	affine3 invert() const;
	affine3 operator * (const affine3 &m) const;
	inline vec3 operator * (const vec3 &p) const;
	vec4 operator * (const vec4 &p) const;
#pragma endregion

#pragma region transformations
	affine3 unitMat() const;
	void translate(double x, double y); void translate(double x, double y, double z); void translate(vec2 v); void translate(vec3 v);
	void scale(double s); void scale(double x, double y, double z);
	void rotate_x(double x); void rotate_y(double y); void rotate_z(double z);
	void rotate_zx(double z, double x); void rotate_xz(double x, double z);
	void rotate(double x, double y, double z);
	void rotate(vec3 u, double theta);	// axis angle
	void getRotationAngle(double &x, double &y, double &z);
	void perspective(double zd);
#pragma endregion

};

class complex {
public:
	double re, im;
	complex() {}
	template<typename T, typename t> complex(const T &re, const t &im) :re(re), im(im) {}
	template<typename T> complex(const T &c) : re(c) {}
	complex(const complex &other) :re(other.re), im(other.im) {}
	~complex() {}

#pragma region basic operations
	double mod() const { return sqrt(re*re + im * im); }
	double arg() const { return atan2(im, re); }
	complex conj() const { return complex(re, -im); }
	complex inv() const { double m = re * re + im * im; return complex(re / m, -im / m); }
	complex operator + (const complex &c) const { return complex(re + c.re, im + c.im); }
	void operator += (const complex &c) { re += c.re, im += c.im; }
	complex operator - () const { return complex(-re, -im); }
	complex operator - (const complex &c) const { return complex(re - c.re, im - c.im); }
	void operator -= (const complex &c) { re -= c.re, im -= c.im; }
	template<typename t> complex operator * (const t &c) const { return complex(re*c, im*c); }
	template<typename t> friend complex operator * (const t &c, const complex &z) { return complex(c*z.re, c*z.im); }
	template<typename t> void operator *= (const t &c) { re *= c, im *= c; }
	complex operator * (const complex &c) const { return complex(re*c.re - im * c.im, re*c.im + im * c.re); }
	void operator *= (const complex &c) { *this = *this * c; }
	template<typename t> complex operator / (const t &c) const { return complex(re / c, im / c); }
	template<typename t> void operator /= (const t &c) { re /= c, im /= c; }
	complex operator / (const complex &c) const { double m = c.re*c.re + c.im*c.im; return complex((re*c.re + im * c.im) / m, (im*c.re - re * c.im) / m); }
	void operator /= (const complex &c) { *this = *this / c; }
#pragma endregion
};

class quaternion {};


#pragma region vec2 implementation

#pragma region constructors
vec2::vec2() {}
template<typename T, typename t> vec2::vec2(T x, t y) :x((double)x), y((double)y) {}
vec2::vec2(const vec2 &other) { x = other.x, y = other.y; }
vec2::vec2(const vec3 &other) { x = other.x, y = other.y; }
vec2& vec2::operator = (const vec2 &other) { x = other.x, y = other.y; return *this; }
vec2& vec2::operator = (const vec3 &other) { x = other.x, y = other.y; return *this; }
vec2::~vec2() {}
#pragma endregion

#pragma region operations
inline double vec2::mod() const { return sqrt(x * x + y * y); }
inline bool vec2::operator == (const vec2 &p) const { return x == p.x && y == p.y; }
inline bool vec2::operator != (const vec2 &p) const { return x != p.x || y != p.y; }
inline vec2 vec2::operator + (const vec2 &p) const { return vec2(x + p.x, y + p.y); }
inline void vec2::operator += (const vec2 &p) { x += p.x, y += p.y; }
inline vec2 vec2::operator - () const { return vec2(-x, -y); }
inline vec2 vec2::operator - (const vec2 &p) const { return vec2(x - p.x, y - p.y); }
inline void vec2::operator -= (const vec2 &p) { x -= p.x, y -= p.y; }
inline vec2 operator * (const double &c, const vec2 &p) { return vec2(c*p.x, c*p.y); }
inline vec2 vec2::operator * (const double &c) const { return vec2(x*c, y*c); }
inline void vec2::operator *= (const double &c) { x *= c, y *= c; }
inline vec2 vec2::operator / (const double &c) const { return vec2(x / c, y / c); }
inline void vec2::operator /= (const double &c) { x /= c, y /= c; }
inline double vec2::sqr() const { return x * x + y * y; }
inline double dot(const vec2 &P, const vec2 &Q) { return P.x*Q.x + P.y*Q.y; }
inline vec3 cross(const vec2 &P, const vec2 &Q) { return vec3(0, 0, P.x*Q.y - P.y*Q.x); }
inline double det(const vec2 &A, const vec2 &B) { return A.x*B.y - A.y*B.x; }
#pragma endregion

#pragma region derivatives
vec2 vec2::unitvec() const { return *this / mod(); }
vec2 vec2::xx() const { return vec2(x, x); } vec2 vec2::yy() const { return vec2(y, y); } vec2 vec2::xy() const { return vec2(x, y); } vec2 vec2::yx() const { return vec2(y, x); }
vec3 vec2::xxx() const { return vec3(x, x, x); } vec3 vec2::xxy() const { return vec3(x, x, y); } vec3 vec2::xyx() const { return vec3(x, y, x); } vec3 vec2::xyy() const { return vec3(x, y, y); }
vec3 vec2::yxx() const { return vec3(y, x, x); } vec3 vec2::yxy() const { return vec3(y, x, y); } vec3 vec2::yyx() const { return vec3(y, y, x); } vec3 vec2::yyy() const { return vec3(y, y, y); }
#pragma endregion

#pragma endregion

#pragma region vec3 implementation

#pragma region constructors
vec3::vec3() {}
template<typename t1, typename t2> vec3::vec3(t1 x, t2 y) :x((double)x), y((double)y), z(0) {}
template<typename t1, typename t2, typename t3> vec3::vec3(t1 x, t2 y, t3 z) : x((double)x), y((double)y), z((double)z) {}
vec3::vec3(const vec2 &other) : x(other.x), y(other.y), z(0) {}
vec3::vec3(const vec2 &other, const double &c) : x(other.x), y(other.y), z(c) {}
vec3::vec3(const double &c, const vec2 &other) : x(c), y(other.x), z(other.y) {}
vec3::vec3(const vec3 &other) : x(other.x), y(other.y), z(other.z) {}
vec3::vec3(const vec4 & other) : x(other.x / other.s), y(other.y / other.s), z(other.z / other.s) {}
vec3& vec3::operator = (const vec2 &other) { x = other.x, y = other.y, z = 0; return *this; }
vec3& vec3::operator = (const vec3 &other) { x = other.x, y = other.y, z = other.z; return *this; }
vec3& vec3::operator = (const vec4 &other) { x = other.x / other.s, y = other.y / other.s, z = other.z / other.s; return *this; }
vec3::~vec3() {}
#pragma endregion

#pragma region operations
inline double vec3::mod() const { return sqrt(x * x + y * y + z * z); }
inline bool vec3::operator == (const vec3 &P) const { return x == P.x && y == P.y && z == P.z; }
inline bool vec3::operator != (const vec3 &P) const { return x != P.x || y != P.y || z != P.z; }
inline vec3 vec3::operator + (const vec3 &p) const { return vec3(x + p.x, y + p.y, z + p.z); }
inline void vec3::operator += (const vec3 &p) { x += p.x, y += p.y, z += p.z; }
inline vec3 vec3::operator - () const { return vec3(-x, -y, -z); }
inline vec3 vec3::operator - (const vec3 &p) const { return vec3(x - p.x, y - p.y, z - p.z); }
inline void vec3::operator -= (const vec3 &p) { x -= p.x, y -= p.y, z -= p.z; }
inline vec3 operator * (const double &c, const vec3 &p) { return vec3(c*p.x, c*p.y, c*p.z); }
inline vec3 vec3::operator * (const double &c) const { return vec3(x*c, y*c, z*c); }
inline void vec3::operator *= (const double &c) { x *= c, y *= c, z *= c; }
inline vec3 vec3::operator / (const double &c) const { return vec3(x / c, y / c, z / c); }
inline void vec3::operator /= (const double &c) { x /= c, y /= c, z /= c; }
inline double vec3::sqr() const { return x * x + y * y + z * z; }
inline double dot(const vec3 &P, const vec3 &Q) { return P.x*Q.x + P.y*Q.y + P.z*Q.z; }
inline vec3 cross(const vec3 &P, const vec3 &Q) { return vec3(P.y*Q.z - P.z*Q.y, P.z*Q.x - P.x*Q.z, P.x*Q.y - P.y*Q.x); }
inline double det(const vec3 &A, const vec3 &B, const vec3 &C) { return A.x*(B.y*C.z - B.z*C.y) - A.y*(B.x*C.z - B.z*C.x) + A.z*(B.x*C.y - B.y*C.x); }
#pragma endregion

#pragma region derivatives
inline vec3 vec3::unitvec() const { return *this / mod(); }
vec2 vec3::xx() const { return vec2(x, x); } vec2 vec3::xy() const { return vec2(x, y); } vec2 vec3::xz() const { return vec2(x, z); }
vec2 vec3::yx() const { return vec2(y, x); } vec2 vec3::yy() const { return vec2(y, y); } vec2 vec3::yz() const { return vec2(y, z); }
vec2 vec3::zx() const { return vec2(z, x); } vec2 vec3::zy() const { return vec2(z, y); } vec2 vec3::zz() const { return vec2(z, z); }
vec3 vec3::xxx() const { return vec3(x, x, x); } vec3 vec3::xxy() const { return vec3(x, x, y); } vec3 vec3::xxz() const { return vec3(x, x, z); }
vec3 vec3::xyx() const { return vec3(x, y, x); } vec3 vec3::xyy() const { return vec3(x, y, y); } vec3 vec3::xyz() const { return vec3(x, y, z); }
vec3 vec3::xzx() const { return vec3(x, z, x); } vec3 vec3::xzy() const { return vec3(x, z, y); } vec3 vec3::xzz() const { return vec3(x, z, z); }
vec3 vec3::yxx() const { return vec3(y, x, x); } vec3 vec3::yxy() const { return vec3(y, x, y); } vec3 vec3::yxz() const { return vec3(y, x, z); }
vec3 vec3::yyx() const { return vec3(y, y, x); } vec3 vec3::yyy() const { return vec3(y, y, y); } vec3 vec3::yyz() const { return vec3(y, y, z); }
vec3 vec3::yzx() const { return vec3(y, z, x); } vec3 vec3::yzy() const { return vec3(y, z, y); } vec3 vec3::yzz() const { return vec3(y, z, z); }
vec3 vec3::zxx() const { return vec3(z, x, x); } vec3 vec3::zxy() const { return vec3(z, x, y); } vec3 vec3::zxz() const { return vec3(z, x, z); }
vec3 vec3::zyx() const { return vec3(z, y, x); } vec3 vec3::zyy() const { return vec3(z, y, y); } vec3 vec3::zyz() const { return vec3(z, y, z); }
vec3 vec3::zzx() const { return vec3(z, z, x); } vec3 vec3::zzy() const { return vec3(z, z, y); } vec3 vec3::zzz() const { return vec3(z, z, z); }
#pragma endregion

#pragma endregion

#pragma region vec4 implementation

#pragma region constructors
vec4::vec4() :s(1) {}
template<typename t1, typename t2> vec4::vec4(t1 x, t2 y) : x(x), y(y), z(0), s(1) {}
template<typename t1, typename t2, typename t3> vec4::vec4(t1 x, t2 y, t3 z) : x(x), y(y), z(z), s(1) {}
vec4::vec4(const vec2 &other) : x(other.x), y(other.y), z(0), s(1) {}
vec4::vec4(const vec3 &other) : x(other.x), y(other.y), z(other.z), s(1) {}
vec4::vec4(const vec4 &other) : x(other.x), y(other.y), z(other.z), s(other.s) {}
vec4& vec4::operator = (const vec2 &other) { x = other.x, y = other.y, z = 0, s = 1; return *this; }
vec4& vec4::operator = (const vec3 &other) { x = other.x, y = other.y, z = other.z, s = 1; return *this; }
vec4& vec4::operator = (const vec4 &other) { x = other.x, y = other.y, z = other.z, s = other.s; return *this; }
vec4::~vec4() {}
#pragma endregion

#pragma region operations
double vec4::mod() const { return sqrt(x * x + y * y + z * z) / s; }
bool vec4::operator == (const vec4 &P) const { return x / s == P.x / P.s && y / s == P.y / P.s && z / s == P.z / P.s; }
bool vec4::operator != (const vec4 &P) const { return x / s != P.x / P.s || y / s != P.y / P.s || z / s != P.z / P.s; }
vec4 vec4::operator + (const vec4 &p) const { return vec4(x / s + p.x / p.s, y / s + p.y / p.s, z / s + p.z / p.s); }
void vec4::operator += (const vec4 &p) { *this = vec4(x / s + p.x / p.s, y / s + p.y / p.s, z / s + p.z / p.s); }
vec4 vec4::operator - () const { return vec4(x, y, z, -s); }
vec4 vec4::operator - (const vec4 &p) const { return vec4(x / s - p.x / p.s, y / s - p.y / p.s, z / s - p.z / p.s); }
void vec4::operator -= (const vec4 &p) { *this = vec4(x / s - p.x / p.s, y / s - p.y / p.s, z / s - p.z / p.s); }
vec4 operator * (const double &c, const vec4 &p) { return vec4(p.x, p.y, p.z, p.s / c); }
vec4 vec4::operator * (const double &c) const { return vec4(x, y, z, s / c); }
void vec4::operator *= (const double &c) { s /= c; }
vec4 vec4::operator / (const double &c) const { return vec4(x, y, z, s * c); }
void vec4::operator /= (const double &c) { s *= c; }
#pragma endregion

#pragma endregion

#pragma region mat2 implementation

#pragma region constructors
mat2::mat2() { a = d = 1, b = c = 0; }
mat2::mat2(cdref _00, cdref _01, cdref _10, cdref _11) :a(_00), b(_01), c(_10), d(_11) {}
mat2::mat2(const mat2 &m) : a(m.a), b(m.b), c(m.c), d(m.d) {}
mat2::mat2(const mat3 &m) : a(m[0][0] / m[2][2]), b(m[0][1] / m[2][2]), c(m[1][0] / m[2][2]), d(m[1][1] / m[2][2]) {}
mat2& mat2::operator = (const mat2 &m) { a = m.a, b = m.b, c = m.c, d = m.d; return *this; }
mat2& mat2::operator = (const mat3 &m) { a = m[0][0] / m[2][2], b = m[0][1] / m[2][2], c = m[1][0] / m[2][2], d = m[1][1] / m[2][2]; return *this; }
mat2::~mat2() {}
#pragma endregion

#pragma region operations
double mat2::det() const { return a * d - b * c; }
mat2 mat2::invert() const { double m = a * d - b * c; return mat2(d / m, -b / m, -c / m, a / m); }
int mat2::rank() const { return a * d - b * c != 0 ? 2 : (a == 0 && b == 0 && c == 0 && d == 0) ? 0 : isNaN(a*b*c*d) ? -1 : 1; }
mat2 mat2::operator * (const double &k) const { return mat2(k*a, k*b, k*c, k*d); }
mat2 mat2::operator / (const double &k) const { return mat2(a / k, b / k, c / k, d / k); }
void mat2::operator *= (const double &k) { a *= k, b *= k, c *= k, d *= k; }
void mat2::operator /= (const double &k) { a /= k, b /= k, c /= k, d /= k; }
mat2 mat2::operator * (const mat2 &m) { return mat2(a*m.a + b * m.c, a*m.b + b * m.d, c*m.a + d * m.c, c*m.b + d * m.d); }
vec2 mat2::operator * (const vec2 &p) { return vec2(a*p.x + b * p.y, c*p.x + d * p.y); }
vec3 mat2::operator * (const vec3 &p) { return vec3(a*p.x + b * p.y, c*p.x + d * p.y, p.z); }
#pragma endregion

#pragma region transformations
void mat2::rotate(double theta) { *this = mat2(cos(theta), -sin(theta), sin(theta), cos(theta))*(*this); }
void mat2::shear_x(double r) { *this = mat2(1, r, 0, 1)*(*this); }
void mat2::shear_y(double r) { *this = mat2(1, 0, r, 1)*(*this); }
void mat2::shear(double x, double y) { *this = mat2(1, x, y, 1)*(*this); }
void mat2::reflect_x() { c = -c, d = -d; }
void mat2::reflect_y() { a = -a, b = -b; }
void mat2::scale(double s) { a *= s, b *= s, c *= s, d *= s; }
void mat2::scale(double x, double y) { a *= x, b *= x, c *= y, d *= y; }
#pragma endregion

#pragma endregion

#pragma region mat3 implementation

#pragma region constructors
mat3::mat3() { init(); }
mat3::mat3(cdref _00, cdref _01, cdref _02, cdref _10, cdref _11, cdref _12, cdref _20, cdref _21, cdref _22) {
	_p[0][0] = _00, _p[0][1] = _01, _p[0][2] = _02, _p[1][0] = _10, _p[1][1] = _11, _p[1][2] = _12, _p[2][0] = _20, _p[2][1] = _21, _p[2][2] = _22;
}
mat3::mat3(const mat3 &m) { memcpy(&_p[0][0], &m._p[0][0], 9 * sizeof(double)); }
mat3::mat3(const mat2 &m) { _p[0][0] = m.a, _p[0][1] = m.b, _p[1][0] = m.c, _p[1][1] = m.d; _p[0][2] = _p[1][2] = _p[2][0] = _p[2][1] = 0, _p[2][2] = 1; }
mat3::mat3(const affine3 &m) { for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) _p[i][j] = m._p[i][j] / m._p[3][3]; }	// not working
mat3& mat3::operator = (const mat3 &m) { memcpy(&_p[0][0], &m._p[0][0], 9 * sizeof(double)); return *this; }
mat3& mat3::operator = (const mat2 &m) { _p[0][0] = m.a, _p[0][1] = m.b, _p[1][0] = m.c, _p[1][1] = m.d; _p[0][2] = _p[1][2] = _p[2][0] = _p[2][1] = 0, _p[2][2] = 1; return *this; }
mat3& mat3::operator = (const affine3 &m) { for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) _p[i][j] = m._p[i][j] / m._p[3][3]; return *this; }
mat3::~mat3() {}
#pragma endregion

#pragma region operations
double mat3::det() const { return _p[0][0] * (_p[1][1] * _p[2][2] - _p[1][2] * _p[2][1]) - _p[0][1] * (_p[1][0] * _p[2][2] - _p[1][2] * _p[2][0]) + _p[0][2] * (_p[1][0] * _p[2][1] - _p[1][1] * _p[2][0]); }
mat3 mat3::invert() const {
	mat3 R;
	R._p[0][0] = _p[1][1] * _p[2][2] - _p[1][2] * _p[2][1], R._p[0][1] = _p[0][2] * _p[2][1] - _p[0][1] * _p[2][2], R._p[0][2] = _p[0][1] * _p[1][2] - _p[0][2] * _p[1][1];
	R._p[1][0] = _p[1][2] * _p[2][0] - _p[1][0] * _p[2][2], R._p[1][1] = _p[0][0] * _p[2][2] - _p[0][2] * _p[2][0], R._p[1][2] = _p[0][2] * _p[1][0] - _p[0][0] * _p[1][2];
	R._p[2][0] = _p[1][0] * _p[2][1] - _p[1][1] * _p[2][0], R._p[2][1] = _p[0][1] * _p[2][0] - _p[0][0] * _p[2][1], R._p[2][2] = _p[0][0] * _p[1][1] - _p[0][1] * _p[1][0];
	double d = _p[0][0] * R._p[0][0] + _p[0][1] * R._p[1][0] + _p[0][2] * R._p[2][0];
	R._p[0][0] /= d, R._p[0][1] /= d, R._p[0][2] /= d, R._p[1][0] /= d, R._p[1][1] /= d, R._p[1][2] /= d, R._p[2][0] /= d, R._p[2][1] /= d, R._p[2][2] /= d;
	return R;
}
mat3 mat3::operator * (const double &k) const { mat3 R(*this); for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) R._p[i][j] *= k; return R; }
mat3 mat3::operator / (const double &k) const { mat3 R(*this); for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) R._p[i][j] /= k; return R; }
void mat3::operator *= (const double &k) { for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) _p[i][j] *= k; }
void mat3::operator /= (const double &k) { for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) _p[i][j] /= k; }
mat3 mat3::operator * (const mat3 &m) const {
	return mat3(
		_p[0][0] * m._p[0][0] + _p[0][1] * m._p[1][0] + _p[0][2] * m._p[2][0], _p[0][0] * m._p[0][1] + _p[0][1] * m._p[1][1] + _p[0][2] * m._p[2][1], _p[0][0] * m._p[0][2] + _p[0][1] * m._p[1][2] + _p[0][2] * m._p[2][2],
		_p[1][0] * m._p[0][0] + _p[1][1] * m._p[1][0] + _p[1][2] * m._p[2][0], _p[1][0] * m._p[0][1] + _p[1][1] * m._p[1][1] + _p[1][2] * m._p[2][1], _p[1][0] * m._p[0][2] + _p[1][1] * m._p[1][2] + _p[1][2] * m._p[2][2],
		_p[2][0] * m._p[0][0] + _p[2][1] * m._p[1][0] + _p[2][2] * m._p[2][0], _p[2][0] * m._p[0][1] + _p[2][1] * m._p[1][1] + _p[2][2] * m._p[2][1], _p[2][0] * m._p[0][2] + _p[2][1] * m._p[1][2] + _p[2][2] * m._p[2][2]
	);
}
inline vec2 mat3::operator * (const vec2 &p) const { return vec2(_p[0][0] * p.x + _p[0][1] * p.y, _p[1][0] * p.x + _p[1][1] * p.y) / _p[2][2]; }
inline vec3 mat3::operator * (const vec3 &p) const { return vec3(_p[0][0] * p.x + _p[0][1] * p.y + _p[0][2] * p.z, _p[1][0] * p.x + _p[1][1] * p.y + _p[1][2] * p.z, _p[2][0] * p.x + _p[2][1] * p.y + _p[2][2] * p.z); }
vec4 mat3::operator * (const vec4 & p) const { return vec4(_p[0][0] * p.x + _p[0][1] * p.y + _p[0][2] * p.z, _p[1][0] * p.x + _p[1][1] * p.y + _p[1][2] * p.z, _p[2][0] * p.x + _p[2][1] * p.y + _p[2][2] * p.z, p.s); }
#pragma endregion

#pragma region transformations
mat3 mat3::unitMat() const { return (*this) / Cbrt(this->det()); }
void mat3::scale(double s) { for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) _p[i][j] *= s; }
void mat3::scale(double x, double y, double z) { for (int i = 0; i < 3; i++) _p[0][i] *= x, _p[1][i] *= y, _p[2][i] *= z; }
void mat3::rotate_x(double x) { *this = mat3(1, 0, 0, 0, cos(x), -sin(x), 0, sin(x), cos(x)) * (*this); }
void mat3::rotate_y(double y) { *this = mat3(cos(y), 0, sin(y), 0, 1, 0, -sin(y), 0, cos(y)) * (*this); }
void mat3::rotate_z(double z) { *this = mat3(cos(z), -sin(z), 0, sin(z), cos(z), 0, 0, 0, 1) * (*this); }
void mat3::rotate_zx(double z, double x) { *this = mat3(cos(z), -cos(x)*sin(z), sin(x)*sin(z), sin(z), cos(x)*cos(z), -sin(x)*cos(z), 0, sin(x), cos(x))*(*this); }
void mat3::rotate_xz(double x, double z) { *this = mat3(cos(z), -sin(z), 0, cos(x)*sin(z), cos(x)*cos(z), -sin(x), sin(x)*sin(z), sin(x)*cos(z), cos(x))*(*this); }
void mat3::rotate(double x, double y, double z) {
	*this = mat3(
		cos(y)*cos(z), sin(x)*sin(y)*cos(z) - cos(x)*sin(z), cos(x)*sin(y)*cos(z) + sin(x)*sin(z),
		cos(y)*sin(z), sin(x)*sin(y)*sin(z) + cos(x)*cos(z), cos(x)*sin(y)*sin(z) - sin(x)*cos(z),
		-sin(y), sin(x)*cos(y), cos(x)*cos(y)) * (*this);
}
void mat3::rotate(vec3 u, double theta) {	// axis-angle
	u /= u.mod(); double ct = cos(theta), st = sin(theta);
	*this = mat3(
		ct + u.x*u.x*(1 - ct), u.x*u.y*(1 - ct) - u.z*st, u.x*u.z*(1 - ct) + u.y*st,
		u.y*u.x*(1 - ct) + u.z*st, ct + u.y*u.y*(1 - ct), u.y*u.z*(1 - ct) - u.x*st,
		u.z*u.x*(1 - ct) - u.y*st, u.z*u.y*(1 - ct) + u.x*st, ct + u.z*u.z*(1 - ct))*(*this);
}
void mat3::getRotationAngle(double &x, double &y, double &z) {	// must be rotation matrix
	x = atan2(_p[2][1], _p[2][2]), z = atan2(_p[1][0], _p[0][0]), y = atan2(-_p[2][0], sqrt(_p[2][1] * _p[2][1] + _p[2][2] * _p[2][2]));
}
#pragma endregion

mat3 RotationMatrix_x(double x) { return mat3(1, 0, 0, 0, cos(x), -sin(x), 0, sin(x), cos(x)); }
mat3 RotationMatrix_y(double y) { return mat3(cos(y), 0, sin(y), 0, 1, 0, -sin(y), 0, cos(y)); }
mat3 RotationMatrix_z(double z) { return mat3(cos(z), -sin(z), 0, sin(z), cos(z), 0, 0, 0, 1); }
mat3 RotationMatrix_zx(double z, double x) { return mat3(cos(z), -cos(x)*sin(z), sin(x)*sin(z), sin(z), cos(x)*cos(z), -sin(x)*cos(z), 0, sin(x), cos(x)); }
mat3 RotationMatrix_xz(double x, double z) { return mat3(cos(z), -sin(z), 0, cos(x)*sin(z), cos(x)*cos(z), -sin(x), sin(x)*sin(z), sin(x)*cos(z), cos(x)); }
mat3 RotationMatrix(double x, double y, double z) {
	return mat3(
		cos(y)*cos(z), sin(x)*sin(y)*cos(z) - cos(x)*sin(z), cos(x)*sin(y)*cos(z) + sin(x)*sin(z),
		cos(y)*sin(z), sin(x)*sin(y)*sin(z) + cos(x)*cos(z), cos(x)*sin(y)*sin(z) - sin(x)*cos(z),
		-sin(y), sin(x)*cos(y), cos(x)*cos(y));
}
mat3 RotationMatrix(vec3 u, double theta) {	// axis-angle
	u /= u.mod(); double ct = cos(theta), st = sin(theta);
	return mat3(
		ct + u.x*u.x*(1 - ct), u.x*u.y*(1 - ct) - u.z*st, u.x*u.z*(1 - ct) + u.y*st,
		u.y*u.x*(1 - ct) + u.z*st, ct + u.y*u.y*(1 - ct), u.y*u.z*(1 - ct) - u.x*st,
		u.z*u.x*(1 - ct) - u.y*st, u.z*u.y*(1 - ct) + u.x*st, ct + u.z*u.z*(1 - ct));
}

#pragma endregion

#pragma region affine3 implementation

#pragma region constructors
affine3::affine3() { init(); }
affine3::affine3(cdref _00, cdref _01, cdref _02, cdref _10, cdref _11, cdref _12, cdref _20, cdref _21, cdref _22) {
	_p[0][0] = _00, _p[0][1] = _01, _p[0][2] = _02, _p[1][0] = _10, _p[1][1] = _11, _p[1][2] = _12, _p[2][0] = _20, _p[2][1] = _21, _p[2][2] = _22;
	_p[0][3] = _p[1][3] = _p[2][3] = _p[3][0] = _p[3][1] = _p[3][2] = 0; _p[3][3] = 1;
}
affine3::affine3(cdref _00, cdref _01, cdref _02, cdref _03, cdref _10, cdref _11, cdref _12, cdref _13, cdref _20, cdref _21, cdref _22, cdref _23, cdref _30, cdref _31, cdref _32, cdref _33) {
	_p[0][0] = _00, _p[0][1] = _01, _p[0][2] = _02, _p[0][3] = _03, _p[1][0] = _10, _p[1][1] = _11, _p[1][2] = _12, _p[1][3] = _13,
		_p[2][0] = _20, _p[2][1] = _21, _p[2][2] = _22, _p[2][3] = _23, _p[3][0] = _30, _p[3][1] = _31, _p[3][2] = _32, _p[3][3] = _33;
}
affine3::affine3(const double* c) { memcpy(&_p[0][0], c, 16 * sizeof(double)); }
affine3::affine3(const affine3 &m) { memcpy(&_p[0][0], &m._p[0][0], 16 * sizeof(double)); }
affine3::affine3(const mat3 &m) { for (int i = 0; i < 3; i++) { for (int j = 0; j < 3; j++) _p[i][j] = m._p[i][j]; _p[i][3] = 0; } for (int j = 0; j < 3; j++) _p[3][j] = 0; _p[3][3] = 1; }
affine3& affine3::operator = (const affine3 &m) { memcpy(&_p[0][0], &m._p[0][0], 16 * sizeof(double)); return *this; }
affine3& affine3::operator = (const mat3 &m) { memcpy(&_p[0][0], &m._p[0][0], 16 * sizeof(double)); _p[0][3] = _p[1][3] = _p[2][3] = 0, _p[3][0] = _p[3][1] = _p[3][2] = 0, _p[3][3] = 1; return *this; }
affine3::~affine3() {}
#pragma endregion

#pragma region operations
double affine3::det() const {
	double r = _p[3][3] * (_p[0][0] * (_p[1][1] * _p[2][2] - _p[1][2] * _p[2][1]) - _p[0][1] * (_p[1][0] * _p[2][2] - _p[1][2] * _p[2][0]) + _p[0][2] * (_p[1][0] * _p[2][1] - _p[1][1] * _p[2][0]));
	if (_p[3][2] != 0) r -= _p[3][2] * (_p[0][0] * (_p[1][1] * _p[2][3] - _p[1][3] * _p[2][1]) - _p[0][1] * (_p[1][0] * _p[2][3] - _p[1][3] * _p[2][0]) + _p[0][3] * (_p[1][0] * _p[2][1] - _p[1][1] * _p[2][0]));
	if (_p[3][1] != 0) r += _p[3][1] * (_p[0][0] * (_p[1][2] * _p[2][3] - _p[1][3] * _p[2][2]) - _p[0][2] * (_p[1][0] * _p[2][3] - _p[1][3] * _p[2][0]) + _p[0][3] * (_p[1][0] * _p[2][2] - _p[1][2] * _p[2][0]));
	if (_p[3][0] != 0) r -= _p[3][0] * (_p[0][1] * (_p[1][2] * _p[2][3] - _p[1][3] * _p[2][2]) - _p[0][2] * (_p[1][1] * _p[2][3] - _p[1][3] * _p[2][1]) + _p[0][3] * (_p[1][1] * _p[2][2] - _p[1][2] * _p[2][1]));
	return r;
}
affine3 affine3::invert() const {
	affine3 R;
	R._p[0][0] = _p[1][1] * _p[2][2] * _p[3][3] - _p[1][1] * _p[2][3] * _p[3][2] - _p[2][1] * _p[1][2] * _p[3][3] + _p[2][1] * _p[1][3] * _p[3][2] + _p[3][1] * _p[1][2] * _p[2][3] - _p[3][1] * _p[1][3] * _p[2][2];
	R._p[1][0] = -_p[1][0] * _p[2][2] * _p[3][3] + _p[1][0] * _p[2][3] * _p[3][2] + _p[2][0] * _p[1][2] * _p[3][3] - _p[2][0] * _p[1][3] * _p[3][2] - _p[3][0] * _p[1][2] * _p[2][3] + _p[3][0] * _p[1][3] * _p[2][2];
	R._p[2][0] = _p[1][0] * _p[2][1] * _p[3][3] - _p[1][0] * _p[2][3] * _p[3][1] - _p[2][0] * _p[1][1] * _p[3][3] + _p[2][0] * _p[1][3] * _p[3][1] + _p[3][0] * _p[1][1] * _p[2][3] - _p[3][0] * _p[1][3] * _p[2][1];
	R._p[3][0] = -_p[1][0] * _p[2][1] * _p[3][2] + _p[1][0] * _p[2][2] * _p[3][1] + _p[2][0] * _p[1][1] * _p[3][2] - _p[2][0] * _p[1][2] * _p[3][1] - _p[3][0] * _p[1][1] * _p[2][2] + _p[3][0] * _p[1][2] * _p[2][1];
	R._p[0][1] = -_p[0][1] * _p[2][2] * _p[3][3] + _p[0][1] * _p[2][3] * _p[3][2] + _p[2][1] * _p[0][2] * _p[3][3] - _p[2][1] * _p[0][3] * _p[3][2] - _p[3][1] * _p[0][2] * _p[2][3] + _p[3][1] * _p[0][3] * _p[2][2];
	R._p[1][1] = _p[0][0] * _p[2][2] * _p[3][3] - _p[0][0] * _p[2][3] * _p[3][2] - _p[2][0] * _p[0][2] * _p[3][3] + _p[2][0] * _p[0][3] * _p[3][2] + _p[3][0] * _p[0][2] * _p[2][3] - _p[3][0] * _p[0][3] * _p[2][2];
	R._p[2][1] = -_p[0][0] * _p[2][1] * _p[3][3] + _p[0][0] * _p[2][3] * _p[3][1] + _p[2][0] * _p[0][1] * _p[3][3] - _p[2][0] * _p[0][3] * _p[3][1] - _p[3][0] * _p[0][1] * _p[2][3] + _p[3][0] * _p[0][3] * _p[2][1];
	R._p[3][1] = _p[0][0] * _p[2][1] * _p[3][2] - _p[0][0] * _p[2][2] * _p[3][1] - _p[2][0] * _p[0][1] * _p[3][2] + _p[2][0] * _p[0][2] * _p[3][1] + _p[3][0] * _p[0][1] * _p[2][2] - _p[3][0] * _p[0][2] * _p[2][1];
	R._p[0][2] = _p[0][1] * _p[1][2] * _p[3][3] - _p[0][1] * _p[1][3] * _p[3][2] - _p[1][1] * _p[0][2] * _p[3][3] + _p[1][1] * _p[0][3] * _p[3][2] + _p[3][1] * _p[0][2] * _p[1][3] - _p[3][1] * _p[0][3] * _p[1][2];
	R._p[1][2] = -_p[0][0] * _p[1][2] * _p[3][3] + _p[0][0] * _p[1][3] * _p[3][2] + _p[1][0] * _p[0][2] * _p[3][3] - _p[1][0] * _p[0][3] * _p[3][2] - _p[3][0] * _p[0][2] * _p[1][3] + _p[3][0] * _p[0][3] * _p[1][2];
	R._p[2][2] = _p[0][0] * _p[1][1] * _p[3][3] - _p[0][0] * _p[1][3] * _p[3][1] - _p[1][0] * _p[0][1] * _p[3][3] + _p[1][0] * _p[0][3] * _p[3][1] + _p[3][0] * _p[0][1] * _p[1][3] - _p[3][0] * _p[0][3] * _p[1][1];
	R._p[3][2] = -_p[0][0] * _p[1][1] * _p[3][2] + _p[0][0] * _p[1][2] * _p[3][1] + _p[1][0] * _p[0][1] * _p[3][2] - _p[1][0] * _p[0][2] * _p[3][1] - _p[3][0] * _p[0][1] * _p[1][2] + _p[3][0] * _p[0][2] * _p[1][1];
	R._p[0][3] = -_p[0][1] * _p[1][2] * _p[2][3] + _p[0][1] * _p[1][3] * _p[2][2] + _p[1][1] * _p[0][2] * _p[2][3] - _p[1][1] * _p[0][3] * _p[2][2] - _p[2][1] * _p[0][2] * _p[1][3] + _p[2][1] * _p[0][3] * _p[1][2];
	R._p[1][3] = _p[0][0] * _p[1][2] * _p[2][3] - _p[0][0] * _p[1][3] * _p[2][2] - _p[1][0] * _p[0][2] * _p[2][3] + _p[1][0] * _p[0][3] * _p[2][2] + _p[2][0] * _p[0][2] * _p[1][3] - _p[2][0] * _p[0][3] * _p[1][2];
	R._p[2][3] = -_p[0][0] * _p[1][1] * _p[2][3] + _p[0][0] * _p[1][3] * _p[2][1] + _p[1][0] * _p[0][1] * _p[2][3] - _p[1][0] * _p[0][3] * _p[2][1] - _p[2][0] * _p[0][1] * _p[1][3] + _p[2][0] * _p[0][3] * _p[1][1];
	R._p[3][3] = _p[0][0] * _p[1][1] * _p[2][2] - _p[0][0] * _p[1][2] * _p[2][1] - _p[1][0] * _p[0][1] * _p[2][2] + _p[1][0] * _p[0][2] * _p[2][1] + _p[2][0] * _p[0][1] * _p[1][2] - _p[2][0] * _p[0][2] * _p[1][1];
	double det = _p[0][0] * R._p[0][0] + _p[0][1] * R._p[1][0] + _p[0][2] * R._p[2][0] + _p[0][3] * R._p[3][0];
	for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) R._p[i][j] /= det;
	return R;
}
affine3 affine3::operator * (const affine3 &M) const {
	affine3 R;
	for (int m = 0; m < 4; m++) for (int n = 0; n < 4; n++) {
		R._p[m][n] = 0;
		for (int i = 0; i < 4; i++) R._p[m][n] += _p[m][i] * M._p[i][n];
	}
	return R;
}
inline vec3 affine3::operator * (const vec3 &P) const {
	double m = _p[3][0] * P.x + _p[3][1] * P.y + _p[3][2] * P.z + _p[3][3];
	return vec3((_p[0][0] * P.x + _p[0][1] * P.y + _p[0][2] * P.z + _p[0][3]) / m,
		(_p[1][0] * P.x + _p[1][1] * P.y + _p[1][2] * P.z + _p[1][3]) / m, (_p[2][0] * P.x + _p[2][1] * P.y + _p[2][2] * P.z + _p[2][3]) / m);
}
vec4 affine3::operator * (const vec4 &p) const {
	return vec4(
		_p[0][0] * p.x + _p[0][1] * p.y + _p[0][2] * p.z + _p[0][3] * p.s,
		_p[1][0] * p.x + _p[1][1] * p.y + _p[1][2] * p.z + _p[1][3] * p.s,
		_p[2][0] * p.x + _p[2][1] * p.y + _p[2][2] * p.z + _p[2][3] * p.s,
		_p[3][0] * p.x + _p[3][1] * p.y + _p[3][2] * p.z + _p[3][3] * p.s
	);
}
#pragma endregion

#pragma region transformations
affine3 affine3::unitMat() const { affine3 R(*this); for (int i = 0; i < 3; i++) R._p[i][3] = 0, R._p[3][i] /= R._p[3][3]; R._p[3][3] = 1; R.scale(1 / Cbrt(R.det())); return R; }	// doesn't work well
void affine3::translate(double x, double y) { *this = affine3(1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, 0, 0, 0, 0, 1)*(*this); }
void affine3::translate(double x, double y, double z) { *this = affine3(1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z, 0, 0, 0, 1)*(*this); }
void affine3::translate(vec2 v) { *this = affine3(1, 0, 0, v.x, 0, 1, 0, v.y, 0, 0, 1, 0, 0, 0, 0, 1)*(*this); }
void affine3::translate(vec3 v) { *this = affine3(1, 0, 0, v.x, 0, 1, 0, v.y, 0, 0, 1, v.z, 0, 0, 0, 1)*(*this); }
void affine3::scale(double s) { *this = affine3(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 / s)*(*this); }
void affine3::scale(double x, double y, double z) { *this = affine3(x, 0, 0, 0, y, 0, 0, 0, z)*(*this); }
void affine3::rotate_x(double x) { *this = affine3(1, 0, 0, 0, cos(x), -sin(x), 0, sin(x), cos(x)) * (*this); }
void affine3::rotate_y(double y) { *this = affine3(cos(y), 0, sin(y), 0, 1, 0, -sin(y), 0, cos(y)) * (*this); }
void affine3::rotate_z(double z) { *this = affine3(cos(z), -sin(z), 0, sin(z), cos(z), 0, 0, 0, 1) * (*this); }
void affine3::rotate_zx(double z, double x) { *this = affine3(cos(z), -cos(x)*sin(z), sin(x)*sin(z), sin(z), cos(x)*cos(z), -sin(x)*cos(z), 0, sin(x), cos(x))*(*this); }
void affine3::rotate_xz(double x, double z) { *this = affine3(cos(z), -sin(z), 0, cos(x)*sin(z), cos(x)*cos(z), -sin(x), sin(x)*sin(z), sin(x)*cos(z), cos(x))*(*this); }
void affine3::rotate(double x, double y, double z) {
	*this = affine3(
		cos(y)*cos(z), sin(x)*sin(y)*cos(z) - cos(x)*sin(z), cos(x)*sin(y)*cos(z) + sin(x)*sin(z),
		cos(y)*sin(z), sin(x)*sin(y)*sin(z) + cos(x)*cos(z), cos(x)*sin(y)*sin(z) - sin(x)*cos(z),
		-sin(y), sin(x)*cos(y), cos(x)*cos(y)) * (*this);
}
void affine3::rotate(vec3 u, double theta) {	// axis-angle
	u /= u.mod(); double ct = cos(theta), st = sin(theta);
	*this = affine3(
		ct + u.x*u.x*(1 - ct), u.x*u.y*(1 - ct) - u.z*st, u.x*u.z*(1 - ct) + u.y*st,
		u.y*u.x*(1 - ct) + u.z*st, ct + u.y*u.y*(1 - ct), u.y*u.z*(1 - ct) - u.x*st,
		u.z*u.x*(1 - ct) - u.y*st, u.z*u.y*(1 - ct) + u.x*st, ct + u.z*u.z*(1 - ct))*(*this);
}
void affine3::getRotationAngle(double &x, double &y, double &z) { x = atan2(_p[2][1], _p[2][2]), z = atan2(_p[1][0], _p[0][0]), y = atan2(-_p[2][0], sqrt(_p[2][1] * _p[2][1] + _p[2][2] * _p[2][2])); }
void affine3::perspective(double z) { *this = affine3(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1 / z, 1) * (*this); }	// camera at (0,0,-z)
#pragma endregion

#pragma endregion affine3 implementation

#pragma region complex variables functions
template<typename t> complex pow(const complex &e, const t &t) { double a = e.arg(), r = log(e.mod()), c = exp(r * t.re), s = a * t.re; return complex(c * cos(s), c * sin(s)); }
complex pow(const complex &e, const complex &t) { double a = e.arg(), r = log(e.mod()), c = exp(t.re * r - t.im * a), s = t.re * a + t.im * r; return complex(c * cos(s), c * sin(s)); }
complex sqrt(const complex &e) { double m = e.mod(); return e.im > 0 ? (complex(sqrt(0.5 * (m + e.re)), sqrt(0.5 * (m - e.re)))) : (complex(sqrt(0.5 * (m + e.re)), -sqrt(0.5 * (m - e.re)))); }
complex exp(const complex &e) { double c = exp(e.re); return complex(c * cos(e.im), c * sin(e.im)); }
complex sin(const complex &e) { return complex(sin(e.re) * cosh(e.im), cos(e.re) * sinh(e.im)); }
complex cos(const complex &e) { return complex(cos(e.re) * cosh(e.im), -sin(e.re) * sinh(e.im)); }
complex tan(const complex &e) { double a = 2 * e.re, b = 2 * e.im, d = cos(a) + cosh(b); return complex(sin(a) / d, sinh(b) / d); }
complex sinh(const complex &e) { return complex(sinh(e.re) * cos(e.im), cosh(e.re) * sin(e.im)); }
complex cosh(const complex &e) { return complex(cosh(e.re) * cos(e.im), sinh(e.re) * sin(e.im)); }
complex tanh(const complex &e) { double a = 2 * e.re, b = 2 * e.im, d = cosh(a) + cos(b); return complex(sinh(a) / d, sin(b) / d); }
complex log(const complex &e) { return complex(log(e.mod()), e.arg()); }
complex asin(const complex &e) { double a = e.re, b = e.im; complex t1 = sqrt(complex(b * b - a * a + 1, -2 * a * b)), t2 = log(complex(t1.re - b, t1.im + a)); return complex(t2.im, -t2.re); }
complex acos(const complex &e) { double a = e.re, b = e.im; complex t1 = sqrt(complex(b * b - a * a + 1, -2 * a * b)), t2 = log(complex(t1.re - b, t1.im + a)); return complex(PI / 2 - t2.im, t2.re); }
complex atan(const complex &e) { double a = e.re, b = e.im, d = a * a + (1.0 - b) * (1.0 - b); complex t1 = log(complex((1 - b * b - a * a) / d, -2 * a / d)); return complex(-0.5 * t1.im, 0.5 * t1.re); }
complex asinh(const complex &e) { complex res = asin(complex(e.im, -e.re)); return complex(-res.im, res.re); }
complex acosh(const complex &e) { complex res = acos(e); if (res.im <= 0) { return complex(-res.im, res.re); } else { return complex(res.im, -res.re); } }
complex compExp(const double &c) { return complex(cos(c), sin(c)); }
#pragma endregion



#pragma endregion




#pragma region random

// linear congruence producing random float values
extern double RAND_LCG_SEED = 0.36787944117;	// seed
#define RAND_LCG_TMS 1335.7170284377952		// problems may occur if this is too small
#define RAND_LCG_ADD 85.147098480789738
void setRandomNumberSeed(double t) { RAND_LCG_SEED = t; }
inline double pick_random(double max) {
	RAND_LCG_SEED = fmod(RAND_LCG_SEED * RAND_LCG_TMS + RAND_LCG_ADD, max);
	return RAND_LCG_SEED;
}
inline double pick_random(double min, double max) {
	RAND_LCG_SEED = fmod(RAND_LCG_SEED * RAND_LCG_TMS + RAND_LCG_ADD, max - min);
	return RAND_LCG_SEED + min;
}
inline double randnor(double median, double variance) {		// produce random normal-distributed values with given median and variance
	auto erfinv = [](double x)->double {	// an approximation of inverse error function
		double n = log(1 - x * x);
		double t = 0.5 * n + 2 / (PI*0.147);
		if (x < 0) return -sqrt(-t + sqrt(t*t - n / 0.147));
		return sqrt(-t + sqrt(t*t - n / 0.147));
	};
	return erfinv(pick_random(-1, 1))*sqrt(2)*variance + median;
}
#undef RAND_LCG_TMS
#undef RAND_LCG_ADD

vec2 random_vec2() {	// unit vector
	vec2 r; do {
		r.x = pick_random(-1, 1), r.y = pick_random(-1, 1);
	} while (r.x * r.x + r.y * r.y > 1);
	return r.unitvec();
}
vec3 random_vec3() {	// unit vector
	vec3 r; do {
		r.x = pick_random(-1, 1), r.y = pick_random(-1, 1), r.z = pick_random(-1, 1);
	} while (r.x * r.x + r.y * r.y + r.z * r.z > 1);
	return r.unitvec();
}

#pragma endregion



#define _RGB(r,g,b) ((COLORREF)(((BYTE)(b)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(r))<<16)))
//#define _RGBA(r,g,b,a) ((COLORREF)(((BYTE)(b)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(r))<<16)|(((DWORD)(BYTE)(a))<<24)))
inline COLORREF mix(COLORREF a, COLORREF b, float r) { return _RGB((1.0f - r)*((BYTE*)&a)[2] + r * ((BYTE*)&b)[2], (1.0f - r)*((BYTE*)&a)[1] + r * ((BYTE*)&b)[1], (1.0f - r)*(BYTE)a + r * (BYTE)b); }
typedef struct { double r, g, b; } COLORf;	// one recommand using vec3 instead of this color structure
#define toCOLORREF(col) _RGB(255*Clamp(col.r,0,1),255*Clamp(col.g,0,1),255*Clamp(col.b,0,1))
COLORf toCOLORf(COLORREF col) { COLORf R; R.b = (BYTE)col / 256.0, R.g = (BYTE)(col >> 8) / 256.0, R.r = (BYTE)(col >> 16) / 256.0; return R; }
COLORf sqrt(COLORf col) { COLORf R; R.r = sqrt(col.r), R.g = sqrt(col.g), R.b = sqrt(col.b); return R; }	// make lighter, but lose some reality
COLORf pow(COLORf col, double e) { COLORf R; R.r = pow(col.r, e), R.g = pow(col.g, e), R.b = pow(col.b, e); return R; }
COLORf RGBf(const double &r, const double &g, const double &b) { COLORf c; c.r = r, c.g = g, c.b = b; return c; }
COLORf RGBf(const double &g) { COLORf c; c.r = c.g = c.b = g; return c; }
COLORf operator + (const COLORf &a, const COLORf &b) { return RGBf(a.r + b.r, a.g + b.g, a.b + b.b); }
void operator += (COLORf &a, const COLORf &b) { a.r += b.r, a.g += b.g, a.b += b.b; }
COLORf operator - (const COLORf &a, const COLORf &b) { return RGBf(a.r - b.r, a.g - b.g, a.b - b.b); }
void operator -= (COLORf &a, const COLORf &b) { a.r -= b.r, a.g -= b.g, a.b -= b.b; }
COLORf operator * (const double &a, const COLORf &b) { return RGBf(a*b.r, a*b.g, a*b.b); }
void operator *= (COLORf &col, const double &c) { col.r *= c, col.g *= c, col.b *= c; }
COLORf operator / (const COLORf &c, const double &k) { return RGBf(c.r / k, c.g / k, c.b / k); }
void operator /= (COLORf &col, const double &c) { col.r /= c, col.g /= c, col.b /= c; }



#include <fstream>
bool saveBitmap(COLORREF *data, unsigned w, unsigned h, string FilePath) {
	if (data == 0) return 0;
	if (w == 0 || h == 0) return 0;
	int padding = 4 - (w * 24 / 8) % 4;
	if (w * 24 % 8 != 0) padding--;
	padding %= 4;
	ofstream _Image(FilePath, ios_base::out | ios_base::binary);
	if (_Image.fail()) return false;
	_Image << "BM";	// Signature, BM
	unsigned size = w * h * 24 / 8 + h * padding + 54;
	unsigned os;
	_Image.write((char*)&size, 4);	// File Size
	os = 0; _Image.write((char*)&os, 4);	// reserved
	os = 0x36; _Image.write((char*)&os, 4);	// Full header size, usually 54 byte
	os = 0x28; _Image.write((char*)&os, 4);	// DIB header size, 40 byte
	_Image.write((char*)&w, 4);	// width
	_Image.write((char*)&h, 4);	// height
	os = 1; _Image.write((char*)&os, 2);	// planes, always 1
	os = 24; _Image.write((char*)&os, 2);	// bits per pixel
	os = 0; _Image.write((char*)&os, 4);	// compression
	size -= 54; _Image.write((char*)&size, 4);	// Image Size
	size = 0;
	_Image.write((char*)&os, 4);	// X pixels per meter
	_Image.write((char*)&os, 4);	// Y pixels per meter
	_Image.write((char*)&os, 4);
	_Image.write((char*)&os, 4);
	COLORREF *b = data;
	for (unsigned i = 0; i < h; i++) {
		for (unsigned j = 0; j < w; j++) {
			_Image.write((char*)b, 3), b++;
		}
		_Image.write((char*)&size, padding);	// Pad row size to a multiple of 4
	}
	_Image.close();
	return true;
}



/* Software Rasterization */

class segment {
public:
	double cz;
	vec3 A, B;
	COLORf col;
	segment() {}
	segment(const vec3 &E1, const vec3 &E2) { A = E1, B = E2, cz = 0.5*(E1.z + E2.z); }
	segment(const vec3 &E1, const vec3 &E2, const COLORf &col) { A = E1, B = E2, cz = 0.5*(E1.z + E2.z), this->col = col; }
	segment(const segment &other) { A = other.A, B = other.B, cz = other.cz, col = other.col; }
	segment& operator = (const segment &other) { A = other.A, B = other.B, cz = other.cz, col = other.col; return *this; }
	~segment() {}
};

#pragma region Draw Line Macros
#define SecurityCheck_yx \
	if (x1 > x2) swap(x1, x2), swap(y1, y2); \
	if (x2 < 0 || (y1 < 0 && y2 < 0)) return; \
	if (x1 > int(w) || (y1 > int(h) && y2 > int(h))) return; \
	double Slope = double(y2 - y1) / (x2 - x1); \
	double Intercept = y1 - x1 * Slope; \
	if (x1 < 0) x1 = 0, y1 = Intercept; \
	if (x2 > w) x2 = w, y2 = w * Slope + Intercept; \
	if (x1*Slope + Intercept < 0) x1 = -Intercept / Slope, y1 = 0; \
	else if (x1*Slope + Intercept >= h) x1 = (h - Intercept) / Slope, y1 = h - 1; \
	if (x2*Slope + Intercept < 0) x2 = -Intercept / Slope, y2 = 0; \
	else if (x2*Slope + Intercept >= h) x2 = (h - Intercept) / Slope, y2 = h - 1; \
	slope = (float)Slope, intercept = (float)Intercept;
#define SecurityCheck_xy \
	if (y1 > y2) swap(x1, x2), swap(y1, y2); \
	if (y2 < 0 || (x1 < 0 && x2 < 0)) return; \
	if (y1 > int(h) || (x1 > int(w) && x2 > int(w))) return; \
	double Slope = double(x2 - x1) / (y2 - y1); \
	double Intercept = x1 - y1 * Slope; \
	if (y1 < 0) y1 = 0, x1 = Intercept; \
	if (y2 >= h) y2 = h - 1, x2 = h * Slope + Intercept; \
	if (int(y1*Slope + Intercept) < 0) y1 = -Intercept / Slope, x1 = 0; \
	else if (int(y1*Slope + Intercept) >= w) y1 = (w - Intercept) / Slope, x1 = w - 1; \
	if (int(y2*Slope + Intercept) < 0) y2 = -Intercept / Slope, x2 = 0; \
	else if (int(y2*Slope + Intercept) >= w) y2 = (w - Intercept) / Slope, x2 = w - 1; \
	slope = (float)Slope, intercept = (float)Intercept;
#define fix(x,min,max) { if (x<min) x=min; if (x>=max) x=max-1.0f; }
#define init \
	float dx = x2 - x1, dy = y2 - y1; \
	float m = sqrt(dx*dx + dy * dy); dx /= m, dy /= m; \
	float a = -dy, b = dx, c = -(a*x1 + b * y1); \
	int x_min = min(x1, x2) - width, y_min = min(y1, y2) - width, x_max = max(x1, x2) + width, y_max = max(y1, y2) + width; \
	fix(x_min, 0.0f, w); fix(x_max, 0.0f, w); fix(y_min, 0.0f, h); fix(y_max, 0.0f, h); \
	float width_2 = 0.5f * width; width = ceil(width); \
	float sd, ds;
#pragma endregion

void drawLine(COLORREF* img, unsigned w, unsigned h, int x1, int y1, int x2, int y2, COLORREF fill) {	// widthless segment
	float slope, intercept; int d;
	if (abs(y2 - y1) < abs(x2 - x1)) {
		SecurityCheck_yx;
		for (int i = x1; i < x2; i++) {
			d = i * slope + intercept;
			if (d >= 0 && d < h) img[d * w + i] = fill;
		}
	}
	else {
		SecurityCheck_xy;
		for (int i = y1; i < y2; i++) {
			d = i * slope + intercept;
			if (d >= 0 && d < w) img[i * w + d] = fill;
		}
	}
}

void drawLine_p(COLORREF* data, int w, int h, double x1, double y1, double x2, double y2, float width, COLORREF fill) {	// width security check and anti-aliasing
	float dx = x2 - x1, dy = y2 - y1;
	float m = sqrt(dx*dx + dy * dy); dx /= m, dy /= m;		// components of direction vector
	float a = -dy, b = dx, c = -(a*x1 + b * y1);	// ax+by+c=0
	int x_min = min(x1, x2) - width, y_min = min(y1, y2) - width, x_max = max(x1, x2) + width, y_max = max(y1, y2) + width;
	x_min -= ceil(width), x_max += ceil(width), y_min -= ceil(width), y_max += ceil(width);
	fix(x_min, 0, w); fix(x_max, 0, w); fix(y_min, 0, h); fix(y_max, 0, h);
	width /= 2.0f; float sd, ds;
	for (int y = y_min; y < y_max; y++) {
		for (int x = x_min; x < x_max; x++) {
			ds = (x - x1) * dx + (y - y1) * dy;
			if (ds > 0 && ds < m) {
				sd = abs(a*x + b * y + c);
				sd = 0.5f - (sd - width);	// width can be zero or negative
				if (sd > 1.0f) data[y*w + x] = fill;
				else if (sd > 0.0f) data[y*w + x] = mix(data[y*w + x], fill, sd);
			}
		}
	}
}
void drawLine(COLORREF* data, int w, int h, double x1, double y1, double x2, double y2, float width, COLORREF fill) {
	// Call "drawLine_p" for parallel or verticle lines or short lines
	float slope, intercept; int d;
	if (abs(y2 - y1) < abs(x2 - x1)) {
		SecurityCheck_yx;
		init;
		for (int i = x1 - width; i < x2 + width + 0.5; i++) {
			if (i >= 0 && i < w) {
				d = i * slope + intercept + width;
				for (int j = d - 2.0f * width - 1; j < d + 0.5; j++) {
					if (j >= 0 && j < h) {
						ds = (i - x1) * dx + (j - y1) * dy;
						if (ds > 0 && ds < m) {
							sd = a * i + b * j + c;
							sd = 0.5f - ((sd > 0 ? sd : -sd) - width_2);
							if (sd >= 1) data[j*w + i] = fill;
							else if (sd > 0) data[j*w + i] = mix(data[j*w + i], fill, sd);
							//data[j*w + i] = mix(data[j*w + i], _RGB(255, 255, 0), 0.2);
						}
					}
				}
			}
		}
	}
	else {
		SecurityCheck_xy;
		init;
		for (int i = y1 - width; i < y2 + width + 0.5; i++) {
			if (i >= 0 && i < h) {
				d = i * slope + intercept + width;
				for (int j = d - 2.0f * width - 1; j < d + 0.5; j++) {
					if (j >= 0 && j < w) {
						ds = (j - x1) * dx + (i - y1) * dy;
						if (ds > 0 && ds < m) {
							sd = a * j + b * i + c;
							sd = 0.5f - ((sd > 0 ? sd : -sd) - width_2);
							if (sd >= 1) data[i*w + j] = fill;
							else if (sd > 0) data[i*w + j] = mix(data[i*w + j], fill, sd);
							//data[j*w + i] = mix(data[j*w + i], _RGB(255, 0, 0), 0.2);
						}
					}
				}
			}
		}
	}
}

void drawLineInZBuffer_p(COLORREF* data, int w, int h, double x1, double y1, double x2, double y2, double width, COLORREF fill) {	// width security check and anti-aliasing
	double dx = x2 - x1, dy = y2 - y1;
	double m = sqrt(dx*dx + dy * dy); dx /= m, dy /= m;		// components of direction vector
	double a = -dy, b = dx, c = -(a*x1 + b * y1);	// ax+by+c=0
	int x_min = min(x1, x2) - width, y_min = min(y1, y2) - width, x_max = max(x1, x2) + width, y_max = max(y1, y2) + width;
	x_min -= ceil(width), x_max += ceil(width), y_min -= ceil(width), y_max += ceil(width);
	fix(x_min, 0, w); fix(x_max, 0, w); fix(y_min, 0, h); fix(y_max, 0, h);
	width /= 2; double sd, ds;
	for (int y = y_min; y < y_max; y++) {
		for (int x = x_min; x < x_max; x++) {
			ds = (x - x1) * dx + (y - y1) * dy;
			if (ds > 0 && ds < m) {
				sd = abs(a*x + b * y + c);
				sd = 0.5 - (sd - width);	// width can be zero or negative
				if (sd > 1) data[y*w + x] = fill;
				else if (sd > 0) data[y*w + x] = mix(data[y*w + x], fill, sd);
			}
		}
	}
}
void drawLineInZBuffer(COLORREF* data, int w, int h, double x1, double y1, double x2, double y2, double width, COLORREF fill) {
	// Call "drawLineInZBuffer_p" for parallel or verticle lines or short lines
	double slope, intercept; int d;
	if (abs(y2 - y1) < abs(x2 - x1)) {
		SecurityCheck_yx;
		init;
		for (int i = x1 - width; i < x2 + width; i++) {
			if (i >= 0 && i < w) {
				d = ceil(i * slope + intercept + width);
				for (int j = d - 2 * width - 1; j <= d; j++) {
					if (j >= 0 && j < h) {
						ds = (i - x1) * dx + (j - y1) * dy;
						if (ds > 0 && ds < m) {
							sd = abs(a*i + b * j + c);
							sd = 0.5 - (sd - width_2);
							if (sd > 1) data[j*w + i] = fill;
							else if (sd > 0) data[j*w + i] = mix(data[j*w + i], fill, sd);
						}
					}
				}
			}
		}
	}
	else {
		if (y1 > y2) swap(x1, x2), swap(y1, y2);
		if (y2 < 0 || (x1 < 0 && x2 < 0)) return;
		if (y1 > int(h) || (x1 > int(w) && x2 > int(w))) return;
		slope = double(x2 - x1) / (y2 - y1);
		intercept = x1 - y1 * slope;
		if (y1 < 0) y1 = 0, x1 = intercept;
		if (y2 >= h) y2 = h - 1, x2 = h * slope + intercept;
		if (int(y1*slope + intercept) < 0) y1 = -intercept / slope, x1 = 0;
		else if (int(y1*slope + intercept) >= w) y1 = (w - intercept) / slope, x1 = w - 1;
		if (int(y2*slope + intercept) < 0) y2 = -intercept / slope, x2 = 0;
		else if (int(y2*slope + intercept) >= w) y2 = (w - intercept) / slope, x2 = w - 1;
		init;
		for (int i = y1 - width; i < y2 + width; i++) {
			if (i >= 0 && i < h) {
				d = ceil(i * slope + intercept + width);
				for (int j = d - 2 * width - 1; j <= d; j++) {
					if (j >= 0 && j < w) {
						ds = (j - x1) * dx + (i - y1) * dy;
						if (ds > 0 && ds < m) {
							sd = abs(a*j + b * i + c);
							sd = 0.5 - (sd - width_2);
							if (sd > 1) data[i*w + j] = fill;
							else if (sd > 0) data[i*w + j] = mix(data[i*w + j], fill, sd);
						}
					}
				}
			}
		}
	}
}

#undef init
#undef fix



class polygon {
public:
	vec3 n;	// normal, make sure all vertexes are coplane
	vec3* ns;	// if different vertices use different normals, this is non-zero
	COLORf col;
	virtual int type() const = 0 {}
	virtual bool createNS() = 0 {}
	virtual bool removeNS() = 0 {}

	virtual ~polygon() = 0 {}
	virtual void operator += (const vec3 &v) = 0 {}
	virtual vec3& applyMatrix(const mat3 &M) = 0 {}
	virtual vec3& applyMatrix(const affine3 &M) = 0 {}
	virtual vec3 transformedNormal(const affine3 &M) const = 0 {}
	virtual void fillInZBuffer(COLORREF* img, int w, int h, double* ZB, COLORREF Col) = 0 {}
	virtual void fillInZBuffer(const mat3 &M, COLORREF* img, int w, int h, double* ZB, COLORREF Col) = 0 {}
	virtual void fillInZBuffer(const affine3 &M, COLORREF* img, int w, int h, double* ZB, COLORREF Col) = 0 {}
	virtual void GouraudShadeInZBuffer(COLORREF* img, int w, int h, double* ZB, initializer_list<COLORf> Cols) = 0 {}
	virtual void GouraudShadeInZBuffer(COLORREF* img, int w, int h, double* ZB, initializer_list<COLORf> Cols, double min_z, double max_z) = 0 {}
	virtual void GouraudShadeInZBuffer(const affine3 &M, COLORREF* img, int w, int h, double* ZB, initializer_list<COLORf> Cols) = 0 {}

	virtual bool IntersectionTest(const vec3 &p, const vec3 &d, vec3 &I, double &t) const = 0 {}	// return distance, d must be an unit vector
};

class triangle : public polygon {
#define PLG_TRIANGLE 1
	friend void fillTrigInZBuffer(COLORREF* img, int w, int h, double* ZB, const triangle &T, COLORREF fill);
	friend void GouraudShadeTrigInZBuffer(COLORREF* img, int w, int h, double* ZB, const triangle &T, COLORf c1, COLORf c2, COLORf c3, double min_z, double max_z);
public:
	vec3 A, B, C;
	virtual int type() const { return PLG_TRIANGLE; }
	vec3& nA() { return ns == 0 ? n : ns[0]; } vec3& nB() { return ns == 0 ? n : ns[1]; } vec3& nC() { return ns == 0 ? n : ns[2]; }
	vec3 nA() const { return ns == 0 ? n : ns[0]; } vec3 nB() const { return ns == 0 ? n : ns[1]; } vec3 nC() const { return ns == 0 ? n : ns[2]; }
	//inline void recalc() { n = cross(B - A, C - A).unitvec(); }
	virtual bool createNS() { if (ns != 0) return 0; ns = new vec3[3]; return 1; }
	virtual bool removeNS() { if (ns == 0) return 0; delete[] ns; ns = 0; return 1; }

	triangle() { ns = 0; }
	triangle(cv3ref V1, cv3ref V2, cv3ref V3) :A(V1), B(V2), C(V3) { n = cross(B - A, C - A).unitvec(); ns = 0; }		// counter-clockwise
	triangle(cv3ref V1, cv3ref V2, cv3ref V3, const COLORf &col) :A(V1), B(V2), C(V3) { n = cross(B - A, C - A).unitvec(); this->col = col; ns = 0; }
	triangle(cv3ref A, cv3ref B, cv3ref C, cv3ref nA, cv3ref nB, cv3ref nC) :A(A), B(B), C(C) {
		n = cross(B - A, C - A).unitvec(); ns = new vec3[3];
		ns[0] = nA.unitvec(), ns[1] = nB.unitvec(), ns[2] = nC.unitvec();
	}
	triangle(cv3ref A, cv3ref B, cv3ref C, cv3ref nA, cv3ref nB, cv3ref nC, const COLORf &col) :A(A), B(B), C(C) {
		this->col = col; n = cross(B - A, C - A).unitvec(); ns = new vec3[3];
		ns[0] = nA.unitvec(), ns[1] = nB.unitvec(), ns[2] = nC.unitvec();
	}
	triangle(const triangle &other) :A(other.A), B(other.B), C(other.C) {
		n = other.n, col = other.col;
		if (other.ns != 0) ns = new vec3[3], memcpy(ns, other.ns, 3 * sizeof(vec3));
		else ns = 0;
	}
	triangle& operator = (const triangle &other) {
		A = other.A, B = other.B, C = other.C, n = other.n, col = other.col;
		if (other.ns != 0) ns = new vec3[3], memcpy(ns, other.ns, 3 * sizeof(vec3));
		else ns = 0;
		return *this;
	}
	~triangle() { if (ns != 0) delete[] ns; ns = 0; }

	virtual void operator += (const vec3 &v) { A += v, B += v, C += v; }
	virtual vec3& applyMatrix(const mat3 &M) {
		A = M * A, B = M * B, C = M * C, n = M * n;
		if (ns != 0) ns[0] = M * ns[0], ns[1] = M * ns[1], ns[2] = M * ns[2];
		//if (ns != 0) ns[0] = M * (A + ns[0]) - M * A, ns[1] = M * (B + ns[1]) - M * B, ns[2] = M * (C + ns[2]) - M * C;
		return n;
	}
	virtual vec3& applyMatrix(const affine3 &M) {
		A = M * A, B = M * B, C = M * C; n = M * n;
		//if (ns != 0) ns[0] = M * ns[0], ns[1] = M * ns[1], ns[2] = M * ns[2];
		if (ns != 0) ns[0] = M * (A + ns[0]) - M * A, ns[1] = M * (B + ns[1]) - M * B, ns[2] = M * (C + ns[2]) - M * C;
		return n;
	}
	virtual vec3 transformedNormal(const affine3 &M) const { vec3 _A = M * A; return cross(M * B - _A, M * C - _A).unitvec(); }
	virtual void fillInZBuffer(COLORREF* img, int w, int h, double* ZB, COLORREF Col) { fillTrigInZBuffer(img, w, h, ZB, *this, Col); }
	virtual void fillInZBuffer(const mat3 &M, COLORREF* img, int w, int h, double* ZB, COLORREF Col) { fillTrigInZBuffer(img, w, h, ZB, triangle(M*A, M*B, M*C), Col); }
	virtual void fillInZBuffer(const affine3 &M, COLORREF* img, int w, int h, double* ZB, COLORREF Col) { fillTrigInZBuffer(img, w, h, ZB, triangle(M*A, M*B, M*C), Col); }

	virtual void GouraudShadeInZBuffer(COLORREF* img, int w, int h, double* ZB, initializer_list<COLORf> Cols) {
		GouraudShadeTrigInZBuffer(img, w, h, ZB, *this, Cols.begin()[0], Cols.begin()[1], Cols.begin()[2], -INFINITY, INFINITY);
	}
	virtual void GouraudShadeInZBuffer(const affine3 &M, COLORREF* img, int w, int h, double* ZB, initializer_list<COLORf> Cols) {
		GouraudShadeTrigInZBuffer(img, w, h, ZB, triangle(M*A, M*B, M*C), Cols.begin()[0], Cols.begin()[1], Cols.begin()[2], -INFINITY, INFINITY);
	}
	virtual void GouraudShadeInZBuffer(COLORREF* img, int w, int h, double* ZB, initializer_list<COLORf> Cols, double min_z, double max_z) {
		GouraudShadeTrigInZBuffer(img, w, h, ZB, *this, Cols.begin()[0], Cols.begin()[1], Cols.begin()[2], min_z, max_z);
	}

	virtual bool IntersectionTest(const vec3 &p, const vec3 &d, vec3 &I, double &t) const {
		vec3 E1 = B - A, E2 = C - A, S = p - A, K = cross(E1, E2), N = cross(S, d);
		double det = -dot(K, d); if (abs(det) < 1e-6) return false;
		double u = dot(N, E2) / det; if (u < 0 || u > 1) return false;
		double v = -dot(N, E1) / det; if (v < 0 || u + v > 1) return false;
		t = dot(K, S) / det; if (t < 0) return false;
		I = p + t * d;	// or (1-u-v)*A + u*B + v*C
		return true;
	}
};

class quadrilateral : public polygon {
#define PLG_QUAD 2
	friend void fillQuadInZBuffer(COLORREF* img, int w, int h, double* ZB, const quadrilateral &Q, COLORREF fill);
	friend void GouraudShadeQuadInZBuffer(COLORREF* img, int w, int h, double* ZB, const quadrilateral &Q, COLORf c1, COLORf c2, COLORf c3, COLORf c4, double min_z, double max_z);
public:
	vec3 A, B, C, D;
	virtual int type() const { return PLG_QUAD; }
	vec3& nA() { return ns == 0 ? n : ns[0]; } vec3& nB() { return ns == 0 ? n : ns[1]; } vec3& nC() { return ns == 0 ? n : ns[2]; } vec3& nD() { return ns == 0 ? n : ns[3]; }
	vec3 nA() const { return ns == 0 ? n : ns[0]; } vec3 nB() const { return ns == 0 ? n : ns[1]; } vec3 nC() const { return ns == 0 ? n : ns[2]; } vec3 nD() const { return ns == 0 ? n : ns[3]; }
	//inline void recalc() { n = cross(B - A, D - A).unitvec(); }
	virtual bool createNS() { if (ns != 0) return 0; ns = new vec3[4]; return 1; }
	virtual bool removeNS() { if (ns == 0) return 0; delete[] ns; ns = 0; return 1; }

	quadrilateral() {}
	quadrilateral(cv3ref O, cv3ref A, cv3ref B) : A(O), B(O + A), C(O + A + B), D(O + B) { n = cross(A, B).unitvec(); ns = 0; }		// parallelogram
	quadrilateral(cv3ref O, cv3ref A, cv3ref B, const COLORf &col) : A(O), B(O + A), C(O + A + B), D(O + B) { n = cross(A, B).unitvec(); this->col = col; ns = 0; }
	quadrilateral(cv3ref A, cv3ref B, cv3ref C, cv3ref D) : A(A), B(B), C(C), D(D) { n = cross(B - A, D - A).unitvec(); ns = 0; }	// counter-clockwise
	quadrilateral(cv3ref A, cv3ref B, cv3ref C, cv3ref D, const COLORf &col) : A(A), B(B), C(C), D(D) { n = cross(B - A, D - A).unitvec(); this->col = col; ns = 0; }
	quadrilateral(const quadrilateral &other) :A(other.A), B(other.B), C(other.C), D(other.D) {
		n = other.n, col = other.col;
		if (other.ns != 0) ns = new vec3[4], memcpy(ns, other.ns, 4 * sizeof(vec3));
		else ns = 0;
	}
	quadrilateral& operator = (const quadrilateral &other) {
		A = other.A, B = other.B, C = other.C, D = other.D, n = other.n, col = other.col;
		if (other.ns != 0) ns = new vec3[4], memcpy(ns, other.ns, 4 * sizeof(vec3));
		else ns = 0;
		return *this;
	}
	~quadrilateral() { if (ns != 0) delete[] ns; ns = 0; }

	virtual void operator += (const vec3 &v) { A += v, B += v, C += v, D += v; }
	virtual vec3& applyMatrix(const mat3 &M) {
		A = M * A, B = M * B, C = M * C, D = M * D; n = M * n;
		if (ns != 0) ns[0] = M * ns[0], ns[1] = M * ns[1], ns[2] = M * ns[2], ns[3] = M * ns[3];
		return n;
	}
	virtual vec3& applyMatrix(const affine3 &M) {
		A = M * A, B = M * B, C = M * C, D = M * D; n = M * n;
		if (ns != 0) ns[0] = M * ns[0], ns[1] = M * ns[1], ns[2] = M * ns[2], ns[3] = M * ns[3];
		//if (ns != 0) ns[0] = M * (A + ns[0]) - M * A, ns[1] = M * (B + ns[1]) - M * B, ns[2] = M * (C + ns[2]) - M * C, ns[3] = M * (D + ns[3]) - M * D;
		return n;
	}
	virtual vec3 transformedNormal(const affine3 &M) const { vec3 _A = M * A; return cross(M * B - _A, M * D - _A).unitvec(); }
	virtual void fillInZBuffer(COLORREF* img, int w, int h, double* ZB, COLORREF Col) { fillQuadInZBuffer(img, w, h, ZB, *this, Col); }
	virtual void fillInZBuffer(const mat3 &M, COLORREF* img, int w, int h, double* ZB, COLORREF Col) { fillQuadInZBuffer(img, w, h, ZB, quadrilateral(M*A, M*B, M*C, M*D), Col); }
	virtual void fillInZBuffer(const affine3 &M, COLORREF* img, int w, int h, double* ZB, COLORREF Col) { fillQuadInZBuffer(img, w, h, ZB, quadrilateral(M*A, M*B, M*C, M*D), Col); }

	virtual void GouraudShadeInZBuffer(COLORREF* img, int w, int h, double* ZB, initializer_list<COLORf> Cols) {
		GouraudShadeQuadInZBuffer(img, w, h, ZB, *this, Cols.begin()[0], Cols.begin()[1], Cols.begin()[2], Cols.begin()[3], -INFINITY, INFINITY);
	}
	virtual void GouraudShadeInZBuffer(const affine3 &M, COLORREF* img, int w, int h, double* ZB, initializer_list<COLORf> Cols) {
		GouraudShadeQuadInZBuffer(img, w, h, ZB, quadrilateral(M*A, M*B, M*C, M*D), Cols.begin()[0], Cols.begin()[1], Cols.begin()[2], Cols.begin()[3], -INFINITY, INFINITY);
	}
	virtual void GouraudShadeInZBuffer(COLORREF* img, int w, int h, double* ZB, initializer_list<COLORf> Cols, double min_z, double max_z) {
		GouraudShadeQuadInZBuffer(img, w, h, ZB, *this, Cols.begin()[0], Cols.begin()[1], Cols.begin()[2], Cols.begin()[3], min_z, max_z);
	}

	virtual bool IntersectionTest(const vec3 &p, const vec3 &d, vec3 &I, double &t) const {
		return triangle(A, B, C).IntersectionTest(p, d, I, t) ? true : triangle(B, C, D).IntersectionTest(p, d, I, t);
	}
};
typedef quadrilateral quad;



#define inTriangle(px, py, x1, y1, x2, y2, x3, y3) \
	(!((((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py) >= 0) + ((x2 - px) * (y3 - py) - (x3 - px) * (y2 - py) >= 0) + ((x3 - px) * (y1 - py) - (x1 - px) * (y3 - py) >= 0)) % 3))

#define oinTriangle(x1, y1, x2, y2, x3, y3) (!(((x1 * y2 - x2 * y1 >= 0) + (x2 * y3 - x3 * y2 >= 0) + (x3 * y1 - x1 * y3 >= 0)) % 3))

#define inConvexQuad(px, py, x1, y1, x2, y2, x3, y3, x4, y4) \
	(!((((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py) >= 0) + ((x2 - px) * (y3 - py) - (x3 - px) * (y2 - py) >= 0) \
		+ ((x3 - px) * (y4 - py) - (x4 - px) * (y3 - py) >= 0) + ((x4 - px) * (y1 - py) - (x1 - px) * (y4 - py) >= 0)) & 3))

void fillTrigInZBuffer(COLORREF* img, int w, int h, double* ZB, const triangle &T, COLORREF fill) {
	if (T.n.z == 0) return;
	double x1 = T.A.x, y1 = T.A.y, x2 = T.B.x, y2 = T.B.y, x3 = T.C.x, y3 = T.C.y;
	double _x1, _y1, _x2, _y2, _x3, _y3;
	double a = -T.n.x / T.n.z, b = -T.n.y / T.n.z, c = (T.n.x*T.A.x + T.n.y*T.A.y) / T.n.z + T.A.z;		// triangle's plane's equation is z=ax+by+c

	if (y1 > y2) swap(x1, x2), swap(y1, y2); if (y2 > y3) swap(x2, x3), swap(y2, y3); if (y1 > y2) swap(x1, x2), swap(y1, y2);	// y1<y2<y3

	double xm = x1 + ((x3 - x1) / (y3 - y1)) * (y2 - y1);
	double mind, maxd; int x_min, y_min, x_max, y_max, x, y, dr;
	if (y1 != y2) {
		double invslope1 = (x2 - x1) / (y2 - y1), invslope2 = (xm - x1) / (y2 - y1);
		if (invslope1 > invslope2) swap(invslope1, invslope2);
		double curx1 = x1, curx2 = x1;
		y_min = Floor(y1), y_max = Ceil(y2); if (y_min < 0) y_min = 0; if (y_max >= h) y_max = h - 1;
		mind = y_min - y1; curx1 += mind * invslope1, curx2 += mind * invslope2;
		for (y = y_min, _y1 = y1 - y, _y2 = y2 - y, _y3 = y3 - y; y <= y_max; y++, _y1--, _y2--, _y3--) {
			x_min = Floor(curx1), x_max = Ceil(curx2); if (x_min < 0) x_min = 0; if (x_max >= w) x_max = w - 1;
			for (_x1 = x1 - x_min, _x2 = x2 - x_min, _x3 = x3 - x_min; x_min <= x_max; x_min++, _x1--, _x2--, _x3--) {
				if (oinTriangle(_x1, _y1, _x2, _y2, _x3, _y3)) {
					double z = a * x_min + b * y + c; dr = y * w + x_min;
					if (z > ZB[dr]) img[dr] = fill, ZB[dr] = z;
					break;
				}
			}
			for (_x1 = x1 - x_max, _x2 = x2 - x_max, _x3 = x3 - x_max; x_max > x_min; x_max--, _x1++, _x2++, _x3++) {
				if (oinTriangle(_x1, _y1, _x2, _y2, _x3, _y3)) {
					double z = a * x_max + b * y + c; dr = y * w + x_max;
					if (z > ZB[dr]) img[dr] = fill, ZB[dr] = z;
					break;
				}
			}
			for (x = x_min, dr = y * w + x_min; x <= x_max; x++, dr++) {
				double z = a * x + b * y + c;
				if (z > ZB[dr]) img[dr] = fill, ZB[dr] = z;
			}
			curx1 += invslope1, curx2 += invslope2;
		}
	}
	if (y2 != y3) {
		double invslope1 = (x3 - x2) / (y3 - y2), invslope2 = (x3 - xm) / (y3 - y2);
		if (invslope1 < invslope2) swap(invslope1, invslope2);
		double curx1 = x3, curx2 = x3;
		y_min = Floor(y2), y_max = Ceil(y3); if (y_min < 0) y_min = 0; if (y_max >= h) y_max = h - 1;
		maxd = y_max - y3; curx1 += maxd * invslope1, curx2 += maxd * invslope2;
		for (y = y_max, _y1 = y1 - y, _y2 = y2 - y, _y3 = y3 - y; y >= y_min; y--, _y1++, _y2++, _y3++) {
			x_min = Floor(curx1), x_max = Ceil(curx2);
			if (x_min < 0) x_min = 0; if (x_max >= w) x_max = w - 1;
			for (_x1 = x1 - x_min, _x2 = x2 - x_min, _x3 = x3 - x_min; x_min <= x_max; x_min++, _x1--, _x2--, _x3--) {
				if (oinTriangle(_x1, _y1, _x2, _y2, _x3, _y3)) {
					double z = a * x_min + b * y + c;
					if (z > ZB[y*w + x_min]) img[y*w + x_min] = fill, ZB[y*w + x_min] = z;
					break;
				}
			}
			for (_x1 = x1 - x_max, _x2 = x2 - x_max, _x3 = x3 - x_max; x_max > x_min; x_max--, _x1++, _x2++, _x3++) {
				if (oinTriangle(_x1, _y1, _x2, _y2, _x3, _y3)) {
					double z = a * x_max + b * y + c;
					if (z > ZB[y*w + x_max]) img[y*w + x_max] = fill, ZB[y*w + x_max] = z;
					break;
				}
			}
			for (x = x_min, dr = y * w + x_min; x <= x_max; x++, dr++) {
				double z = a * x + b * y + c;
				if (z > ZB[dr]) img[dr] = fill, ZB[dr] = z;
			}
			curx1 -= invslope1, curx2 -= invslope2;
		}
	}

}

void GouraudShadeTrigInZBuffer_1(COLORREF* img, int w, int h, double* ZB, const triangle &T, COLORf c1, COLORf c2, COLORf c3, double min_z, double max_z) {
	if (T.n.z == 0) return;
	double x1 = T.A.x, y1 = T.A.y, x2 = T.B.x, y2 = T.B.y, x3 = T.C.x, y3 = T.C.y;
	double a = -T.n.x / T.n.z, b = -T.n.y / T.n.z, c = (T.n.x*T.A.x + T.n.y*T.A.y) / T.n.z + T.A.z;		// triangle's plane's equation is z=ax+by+c
	double min_x = min(x1, min(x2, x3)), max_x = max(x1, max(x2, x3)), min_y = min(y1, min(y2, y3)), max_y = max(y1, max(y2, y3));
	int x_min = Floor(min_x), x_max = Ceil(max_x); if (x_min < 0) x_min = 0; if (x_max >= w) x_max = w - 1;
	int y_min = Floor(min_y), y_max = Ceil(max_y); if (y_min < 0) y_min = 0; if (y_max >= h) y_max = h - 1;

	COLORf col;
	mat2 M = mat2(x1 - x2, x2 - x3, y1 - y2, y2 - y3).invert(); vec2 uv; double u, v;
	for (int y = y_min; y <= y_max; y++) {
		for (int x = x_min, dr = y * w + x; x <= x_max; x++, dr++) {
			if (inTriangle(x, y, x1, y1, x2, y2, x3, y3)) {
				double z = a * x + b * y + c;
				if (z > ZB[dr] && z > min_z && z < max_z) {
					uv = M * vec2(x1 - x, y1 - y); u = uv.x, v = uv.y / uv.x;
					col = (1 - u)*c1 + u * ((1 - v)*c2 + v * c3);
					img[dr] = toCOLORREF(col), ZB[dr] = z;
				}
			}
		}
	}
}
void GouraudShadeTrigInZBuffer_2(COLORREF* img, int w, int h, double* ZB, const triangle &T, COLORf c1, COLORf c2, COLORf c3, double min_z, double max_z) {
	if (T.n.z == 0) return;
	double x1 = T.A.x, y1 = T.A.y, x2 = T.B.x, y2 = T.B.y, x3 = T.C.x, y3 = T.C.y;
	double a = -T.n.x / T.n.z, b = -T.n.y / T.n.z, c = (T.n.x*T.A.x + T.n.y*T.A.y) / T.n.z + T.A.z;		// triangle's plane's equation is z=ax+by+c

	if (y1 > y2) swap(x1, x2), swap(y1, y2), swap(c1, c2); if (y2 > y3) swap(x2, x3), swap(y2, y3), swap(c2, c3); if (y1 > y2) swap(x1, x2), swap(y1, y2), swap(c1, c2);	// y1<y2<y3

	COLORf col;
	double xm = x1 + ((x3 - x1) / (y3 - y1)) * (y2 - y1);
	mat2 M = mat2(x1 - x2, x2 - x3, y1 - y2, y2 - y3).invert(); vec2 uv;
	double mind, maxd; int x_min, y_min, x_max, y_max;
	double u, v;	// interpolation: (1-u) a + u [(1-v) b + v c]
	if (y1 != y2) {
		double invslope1 = (x2 - x1) / (y2 - y1), invslope2 = (xm - x1) / (y2 - y1);
		if (invslope1 > invslope2) swap(invslope1, invslope2);
		double curx1 = x1, curx2 = x1;
		y_min = Floor(y1), y_max = Ceil(y2); if (y_min < 0) y_min = 0; if (y_max >= h) y_max = h - 1;
		mind = y_min - y1; curx1 += mind * invslope1, curx2 += mind * invslope2;
		for (int y = y_min; y <= y_max; y++) {
			x_min = Floor(curx1), x_max = Ceil(curx2); if (x_min < 0) x_min = 0; if (x_max >= w) x_max = w - 1;
			for (int x = x_min, dr = y * w + x_min; x <= x_max; x++, dr++) {
				if ((x != x_min && y != y_min && x != x_max && y != y_max) || inTriangle(x, y, x1, y1, x2, y2, x3, y3)) {
					double z = a * x + b * y + c;
					if (z > ZB[dr] && z > min_z && z < max_z) {
						uv = M * vec2(x1 - x, y1 - y); u = uv.x, v = uv.y / uv.x;
						col = (1 - u)*c1 + u * ((1 - v)*c2 + v * c3);
						img[dr] = toCOLORREF(col), ZB[dr] = z;
					}
				}
			}
			curx1 += invslope1, curx2 += invslope2;
		}
	}
	if (y2 != y3) {
		double invslope1 = (x3 - x2) / (y3 - y2), invslope2 = (x3 - xm) / (y3 - y2);
		if (invslope1 < invslope2) swap(invslope1, invslope2);
		double curx1 = x3, curx2 = x3;
		y_min = Floor(y2), y_max = Ceil(y3); if (y_min < 0) y_min = 0; if (y_max >= h) y_max = h - 1;
		maxd = y_max - y3; curx1 += maxd * invslope1, curx2 += maxd * invslope2;
		for (int y = y_max; y >= y_min; y--) {
			x_min = Floor(curx1), x_max = Ceil(curx2);
			if (x_min < 0) x_min = 0; if (x_max >= w) x_max = w - 1;
			for (int x = x_min, dr = y * w + x_min; x <= x_max; x++, dr++) {
				if ((x != x_min && y != y_min && x != x_max && y != y_max) || inTriangle(x, y, x1, y1, x2, y2, x3, y3)) {
					double z = a * x + b * y + c;
					if (z > ZB[dr] && z > min_z && z < max_z) {
						uv = M * vec2(x1 - x, y1 - y); u = uv.x, v = uv.y / uv.x;
						col = (1 - u)*c1 + u * ((1 - v)*c2 + v * c3);
						img[dr] = toCOLORREF(col), ZB[dr] = z;
					}
				}
			}
			curx1 -= invslope1, curx2 -= invslope2;
		}
	}

}
void GouraudShadeTrigInZBuffer_3(COLORREF* img, int w, int h, double* ZB, const triangle &T, COLORf c1, COLORf c2, COLORf c3, double min_z, double max_z) {
	if (T.n.z == 0) return;
	double x1 = T.A.x, y1 = T.A.y, x2 = T.B.x, y2 = T.B.y, x3 = T.C.x, y3 = T.C.y;
	double _x1, _y1, _x2, _y2, _x3, _y3;
	double a = -T.n.x / T.n.z, b = -T.n.y / T.n.z, c = (T.n.x*T.A.x + T.n.y*T.A.y) / T.n.z + T.A.z;		// triangle's plane's equation is z=ax+by+c

	if (y1 > y2) swap(x1, x2), swap(y1, y2), swap(c1, c2); if (y2 > y3) swap(x2, x3), swap(y2, y3), swap(c2, c3); if (y1 > y2) swap(x1, x2), swap(y1, y2), swap(c1, c2);	// y1<y2<y3

	COLORf col;
	double xm = x1 + ((x3 - x1) / (y3 - y1)) * (y2 - y1);
	mat2 M = mat2(x1 - x2, x2 - x3, y1 - y2, y2 - y3).invert(); vec2 uv;
	double mind, maxd; int x_min, y_min, x_max, y_max, x, y, dr;
	double u, v;	// interpolation: (1-u) a + u [(1-v) b + v c]
	if (y1 != y2) {
		double invslope1 = (x2 - x1) / (y2 - y1), invslope2 = (xm - x1) / (y2 - y1);
		if (invslope1 > invslope2) swap(invslope1, invslope2);
		double curx1 = x1, curx2 = x1;
		y_min = Floor(y1), y_max = Ceil(y2); if (y_min < 0) y_min = 0; if (y_max >= h) y_max = h - 1;
		mind = y_min - y1; curx1 += mind * invslope1, curx2 += mind * invslope2;
		for (y = y_min, _y1 = y1 - y, _y2 = y2 - y, _y3 = y3 - y; y <= y_max; y++, _y1--, _y2--, _y3--) {
			x_min = Floor(curx1), x_max = Ceil(curx2); if (x_min < 0) x_min = 0; if (x_max >= w) x_max = w - 1;
			for (_x1 = x1 - x_min, _x2 = x2 - x_min, _x3 = x3 - x_min; x_min <= x_max; x_min++, _x1--, _x2--, _x3--) {
				if (oinTriangle(_x1, _y1, _x2, _y2, _x3, _y3)) {
					double z = a * x_min + b * y + c; dr = y * w + x_min;
					if (z > ZB[dr] && z > min_z && z < max_z) {
						uv = M * vec2(x1 - x_min, y1 - y); u = uv.x, v = uv.y / uv.x;
						col = (1 - u)*c1 + u * ((1 - v)*c2 + v * c3);
						img[dr] = toCOLORREF(col), ZB[dr] = z;
					}
					break;
				}
			}
			for (_x1 = x1 - x_max, _x2 = x2 - x_max, _x3 = x3 - x_max; x_max > x_min; x_max--, _x1++, _x2++, _x3++) {
				if (oinTriangle(_x1, _y1, _x2, _y2, _x3, _y3)) {
					double z = a * x_max + b * y + c; dr = y * w + x_max;
					if (z > ZB[dr] && z > min_z && z < max_z) {
						uv = M * vec2(x1 - x_max, y1 - y); u = uv.x, v = uv.y / uv.x;
						col = (1 - u)*c1 + u * ((1 - v)*c2 + v * c3);
						img[dr] = toCOLORREF(col), ZB[dr] = z;
					}
					break;
				}
			}
			for (x = x_min, dr = y * w + x_min; x <= x_max; x++, dr++) {
				double z = a * x + b * y + c;
				if (z > ZB[dr] && z > min_z && z < max_z) {
					uv = M * vec2(x1 - x, y1 - y); u = uv.x, v = uv.y / uv.x;
					col = (1 - u)*c1 + u * ((1 - v)*c2 + v * c3);
					img[dr] = toCOLORREF(col), ZB[dr] = z;
				}
			}
			curx1 += invslope1, curx2 += invslope2;
		}
	}
	if (y2 != y3) {
		double invslope1 = (x3 - x2) / (y3 - y2), invslope2 = (x3 - xm) / (y3 - y2);
		if (invslope1 < invslope2) swap(invslope1, invslope2);
		double curx1 = x3, curx2 = x3;
		y_min = Floor(y2), y_max = Ceil(y3); if (y_min < 0) y_min = 0; if (y_max >= h) y_max = h - 1;
		maxd = y_max - y3; curx1 += maxd * invslope1, curx2 += maxd * invslope2;
		for (y = y_max, _y1 = y1 - y, _y2 = y2 - y, _y3 = y3 - y; y >= y_min; y--, _y1++, _y2++, _y3++) {
			x_min = Floor(curx1), x_max = Ceil(curx2);
			if (x_min < 0) x_min = 0; if (x_max >= w) x_max = w - 1;
			for (_x1 = x1 - x_min, _x2 = x2 - x_min, _x3 = x3 - x_min; x_min <= x_max; x_min++, _x1--, _x2--, _x3--) {
				if (oinTriangle(_x1, _y1, _x2, _y2, _x3, _y3)) {
					double z = a * x_min + b * y + c; dr = y * w + x_min;
					if (z > ZB[dr] && z > min_z && z < max_z) {
						uv = M * vec2(x1 - x_min, y1 - y); u = uv.x, v = uv.y / uv.x;
						col = (1 - u)*c1 + u * ((1 - v)*c2 + v * c3);
						img[dr] = toCOLORREF(col), ZB[dr] = z;
					}
					break;
				}
			}
			for (_x1 = x1 - x_max, _x2 = x2 - x_max, _x3 = x3 - x_max; x_max > x_min; x_max--, _x1++, _x2++, _x3++) {
				if (oinTriangle(_x1, _y1, _x2, _y2, _x3, _y3)) {
					double z = a * x_max + b * y + c; dr = y * w + x_max;
					if (z > ZB[dr] && z > min_z && z < max_z) {
						uv = M * vec2(x1 - x_max, y1 - y); u = uv.x, v = uv.y / uv.x;
						col = (1 - u)*c1 + u * ((1 - v)*c2 + v * c3);
						img[dr] = toCOLORREF(col), ZB[dr] = z;
					}
					break;
				}
			}
			for (x = x_min, dr = y * w + x_min; x <= x_max; x++, dr++) {
				double z = a * x + b * y + c;
				if (z > ZB[dr] && z > min_z && z < max_z) {
					uv = M * vec2(x1 - x, y1 - y); u = uv.x, v = uv.y / uv.x;
					col = (1 - u)*c1 + u * ((1 - v)*c2 + v * c3);
					img[dr] = toCOLORREF(col), ZB[dr] = z;
				}
			}
			curx1 -= invslope1, curx2 -= invslope2;
		}
	}

}

void GouraudShadeTrigInZBuffer(COLORREF* img, int w, int h, double* ZB, const triangle &T, COLORf c1, COLORf c2, COLORf c3, double min_z, double max_z) {
	if (abs(det(T.B.xy() - T.A.xy(), T.C.xy() - T.A.xy())) < 10) GouraudShadeTrigInZBuffer_1(img, w, h, ZB, T, c1, c2, c3, min_z, max_z); \
	else if (abs(det(T.B.xy() - T.A.xy(), T.C.xy() - T.A.xy())) < 50) GouraudShadeTrigInZBuffer_2(img, w, h, ZB, T, c1, c2, c3, min_z, max_z); \
	else GouraudShadeTrigInZBuffer_3(img, w, h, ZB, T, c1, c2, c3, min_z, max_z);
}

void fillQuadInZBuffer(COLORREF* img, int w, int h, double* ZB, const quadrilateral &Q, COLORREF fill) {	// only works for convex quads
	if (Q.n.z == 0) return;
	double x1 = Q.A.x, y1 = Q.A.y, x2 = Q.B.x, y2 = Q.B.y, x3 = Q.C.x, y3 = Q.C.y, x4 = Q.D.x, y4 = Q.D.y;
	double a = -Q.n.x / Q.n.z, b = -Q.n.y / Q.n.z, c = (Q.n.x*Q.A.x + Q.n.y*Q.A.y) / Q.n.z + Q.A.z;		// z=ax+by+c

	double mind, maxd;

	int y_min = Floor(min(min(y1, y2), min(y3, y4))), y_max = Ceil(max(max(y1, y2), max(y3, y4)));
	if (y_min < 0) y_min = 0; if (y_max >= h) y_max = h - 1;
	double s12 = (x2 - x1) / (y2 - y1), s23 = (x3 - x2) / (y3 - y2), s34 = (x4 - x3) / (y4 - y3), s41 = (x1 - x4) / (y1 - y4),
		i12 = x1 - s12 * y1, i23 = x2 - s23 * y2, i34 = x3 - s34 * y3, i41 = x4 - s41 * y4;
	double I12 = s12 * y_min + i12, I23 = s23 * y_min + i23, I34 = s34 * y_min + i34, I41 = s41 * y_min + i41;
	for (int y = y_min; y <= y_max; y++) {
		mind = maxd = NAN;
#define cki(a,b) if (maxd!=maxd && y>=min(y##a,y##b)&&y<=max(y##a,y##b)) if (mind!=mind) mind=I##a##b; else if (maxd!=mind) maxd=I##a##b
		cki(1, 2); cki(2, 3); cki(3, 4); cki(4, 1);
#undef cki
		if (mind > maxd) swap(mind, maxd);
		int x_min = Floor(mind), x_max = Ceil(maxd); if (x_min < 0) x_min = 0; if (x_max >= w) x_max = w - 1;
		for (int x = x_min, dr = y * w + x_min; x <= x_max; x++, dr++) {
			if ((x != x_min && y != y_min && x != x_max && y != y_max) || inConvexQuad(x, y, x1, y1, x2, y2, x3, y3, x4, y4)) {
				double z = a * x + b * y + c;
				if (z > ZB[dr]) img[dr] = fill, ZB[dr] = z;
			}
		}
		I12 += s12, I23 += s23, I34 += s34, I41 += s41;
	}

}

void GouraudShadeQuadInZBuffer(COLORREF* img, int w, int h, double* ZB, const quadrilateral &Q, COLORf c1, COLORf c2, COLORf c3, COLORf c4, double min_z, double max_z) {	// debugging, only works for convex quads
	if (Q.n.z == 0) return;
	double x1 = Q.A.x, y1 = Q.A.y, x2 = Q.B.x, y2 = Q.B.y, x3 = Q.C.x, y3 = Q.C.y, x4 = Q.D.x, y4 = Q.D.y;
	double a = -Q.n.x / Q.n.z, b = -Q.n.y / Q.n.z, c = (Q.n.x*Q.A.x + Q.n.y*Q.A.y) / Q.n.z + Q.A.z;		// z=ax+by+c

	//COLORf col; double u, v;

	double mind, maxd;
	int y_min = Floor(min(min(y1, y2), min(y3, y4))), y_max = Ceil(max(max(y1, y2), max(y3, y4)));
	if (y_min < 0) y_min = 0; if (y_max >= h) y_max = h - 1;
	double s12 = (x2 - x1) / (y2 - y1), s23 = (x3 - x2) / (y3 - y2), s34 = (x4 - x3) / (y4 - y3), s41 = (x1 - x4) / (y1 - y4),
		i12 = x1 - s12 * y1, i23 = x2 - s23 * y2, i34 = x3 - s34 * y3, i41 = x4 - s41 * y4;
	double I12 = s12 * y_min + i12, I23 = s23 * y_min + i23, I34 = s34 * y_min + i34, I41 = s41 * y_min + i41;
	for (int y = y_min; y <= y_max; y++) {
		mind = maxd = NAN;
#define cki(a,b) if (maxd!=maxd && y>=min(y##a,y##b)&&y<=max(y##a,y##b)) if (mind!=mind) mind=I##a##b; else if (maxd!=mind) maxd=I##a##b
		cki(1, 2); cki(2, 3); cki(3, 4); cki(4, 1);
#undef cki
		if (mind > maxd) swap(mind, maxd);
		int x_min = Floor(mind), x_max = Ceil(maxd); if (x_min < 0) x_min = 0; if (x_max >= w) x_max = w - 1;
		for (int x = x_min, dr = y * w + x_min; x <= x_max; x++, dr++) {
			if ((x != x_min && y != y_min && x != x_max && y != y_max) || inConvexQuad(x, y, x1, y1, x2, y2, x3, y3, x4, y4)) {
				double z = a * x + b * y + c;
				if (z > ZB[dr] && z > min_z && z < max_z) {
					img[dr] = toCOLORREF(c1), ZB[dr] = z;	// debugging
				}
			}
		}
		I12 += s12, I23 += s23, I34 += s34, I41 += s41;
	}
}



#undef inTriangle
#undef oinTriangle
#undef inConvexQuad












#pragma region DEBUG

#ifdef _DEBUG
#include <crtdbg.h>
#include <cstdlib>
#define CheckMemoryLeaks _CrtDumpMemoryLeaks();
#define BreakAtAlloc(t) _CrtSetBreakAlloc(t);
#else
#define CheckMemoryLeaks { }
#define BreakAtAlloc(t) { }
#endif

#include <iostream>
#include <iomanip>
#include <sstream>
wostream& operator << (wostream& os, const vec2 &p) { os << "(" << p.x << "," << p.y << ")"; return os; }
wostream& operator << (wostream& os, const vec3 &p) { os << "(" << p.x << "," << p.y << "," << p.z << ")"; return os; }
wostream& operator << (wostream& os, const mat3 &p) {
	for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
		os << (j == 0 ? (i == 0 ? "{ {" : "{") : "") << p[i][j] << (j == 2 ? (i == 2 ? "} }" : "}, ") : ", ");
	}
	return os;
}
wostream& operator << (wostream& os, const triangle &p) {
	os << "Surface((1-v)*((1-u)*" << p.A << "+u*" << p.B << ")+v*((1-u)*" << p.A << "+u*" << p.C << "),u,0,1,v,0,1)";
	return os;
}
wostream& operator << (wostream& os, const quad &p) {
	os << "Surface((1-v)*((1-u)*" << p.A << "+u*" << p.B << ")+v*((1-u)*" << p.D << "+u*" << p.C << "),u,0,1,v,0,1)";
	return os;
}
#define Dout(s) { std::wostringstream os_; os_ << s << " (" << __LINE__ << ")" << endl; OutputDebugStringW( os_.str().c_str() ); }
#define dout(s) { std::wostringstream os_; os_ << s; OutputDebugStringW( os_.str().c_str() ); }	// log to Visual Studio output window
//#define Dout(s) { }
//#define dout(s) { }	// uncomment these two lines in final release


#pragma endregion

