// https://docs.microsoft.com/en-us/windows/desktop/learnwin32/learn-to-program-for-windows
// http://www.winprog.org/tutorial/start.html

#pragma warning (disable: 4244)

#ifndef UNICODE
#define UNICODE
#endif

#include <windows.h>
#include <stdlib.h>
#include <tchar.h>
#include <cmath>


static TCHAR szWindowClass[] = _T("DesktopApp");	// The main window class name.

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// forward declarations of "window procedure"

#include <d2d1.h>
#include <gdiplus.h>
using namespace std;

HBITMAP hbmp;
RECT Client;
COLORREF *img_data;
HDC hdcMem;
HANDLE GraphingThread;
HANDLE GraphingWindow;
#define _RGB(r,g,b) ((COLORREF)(((BYTE)(b)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(r))<<16)))
COLORREF HSL(double h, double s, double l) {
	// 0 ≤ h < 1, 0 ≤ s,l ≤ 1
	auto hue2RGB = [](double v1, double v2, double vH) {
		vH -= floor(vH);
		if ((6 * vH) < 1) return (v1 + (v2 - v1) * 6 * vH);
		if ((2 * vH) < 1) return v2;
		if ((3 * vH) < 2) return (v1 + (v2 - v1) * ((2.0 / 3) - vH) * 6);
		return v1;
	};
	if (s == 0) return RGB(l * 255, l * 255, l * 255);
	double v1, v2;
	v2 = (l < 0.5) ? (l * (1 + s)) : ((l + s) - (l * s));
	v1 = 2 * l - v2;
	return _RGB(
		255 * hue2RGB(v1, v2, h + (1. / 3)),
		255 * hue2RGB(v1, v2, h),
		255 * hue2RGB(v1, v2, h - (1. / 3))
	);
}


#include <crtdbg.h>
int CALLBACK WinMain(_In_ HINSTANCE hInstance, _In_ HINSTANCE hPrevInstance, _In_ LPSTR lpCmdLine, _In_ int nCmdShow) 	// entry point
{
	_CrtSetBreakAlloc(-1);

	// Windows class
	// class structure: https://docs.microsoft.com/en-us/windows/desktop/api/winuser/ns-winuser-tagwndclassexa
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);	// size of WNDCLASSEX, in bytes
	wcex.style = 0;	// see https://docs.microsoft.com/en-us/windows/desktop/winmsg/window-class-styles
	wcex.lpfnWndProc = WndProc;		// pointer to "window procedure"
	wcex.cbClsExtra = 0;	// initialize to zero
	wcex.cbWndExtra = 0;	// 0 or DLGWINDOWEXTRA
	wcex.hInstance = hInstance;
	wcex.hIcon = 0; 	// handle to the class icon, system provides a default icon if null
	wcex.hIconSm = LoadIcon(wcex.hInstance, IDI_APPLICATION);	// handle to a small icon
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW); 	// handle to the class cursor
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);	// handle to the class background brush
	wcex.lpszMenuName = NULL;	// ?
	wcex.lpszClassName = szWindowClass;		// main window class name


	// regist windows class
	if (!RegisterClassEx(&wcex)) {
		MessageBox(NULL, _T("Call to RegisterClassEx failed!"), _T("Windows Desktop Guided Tour"), NULL);
		return 1;
	}


	HWND hWnd = CreateWindowEx(
		WS_EX_APPWINDOW,	// windows style
		szWindowClass, 	// window class name
		_T("Colors"), 	// title of window
		WS_MINIMIZEBOX | WS_SYSMENU | WS_POPUP | WS_CAPTION,	// the type of window to create
		CW_USEDEFAULT, CW_USEDEFAULT,	// initial position (x, y)
		600, 400,	// initial size (width, length)
		NULL,	// the parent of this window
		NULL,	// this application does not have a menu bar
		hInstance,	// Instance handle, the first parameter from WinMain
		NULL	// can be any type of pointer
	);
	// return the handle to this window


	if (!hWnd) {
		MessageBox(NULL,
			_T("Call to CreateWindow failed!"),
			_T("Windows Desktop Guided Tour"),
			NULL);
		return 1;
	}


	// hWnd: the value returned from CreateWindow
	// nCmdShow: the fourth parameter from WinMain
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);


	// Main message loop: send message to WndProc
	MSG msg;
	while (GetMessage(&msg, 0, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	//delete img_data;

	_CrtDumpMemoryLeaks();
	return (int)msg.wParam;
}



void drawMandelbrot(HWND &hWnd) {
	PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hWnd, &ps);

	unsigned w = Client.right, h = Client.bottom;
	RedrawWindow(hWnd, &Client, NULL, RDW_ERASENOW);
	FillRect(hdc, &Client, (HBRUSH)(COLOR_WINDOW));

#define ctr_re 0.3385847939577921
#define ctr_im 0.5733237332425829
#define area 1.7e-12

#define LN2 0.693147180559945309417232121458

	const double ratio = sqrt(w*h / area);
	const double ctr_x = 0.5*w - ctr_re * ratio, ctr_y = 0.5*h + ctr_im * ratio;
	unsigned limit = floor(120 / pow(area, 0.25));
	if (limit > 20000) limit = 20000;

	auto Mandelbrot = [](double re, double im, unsigned max_iter)->COLORREF {
		double a = re, b = im, c, s;
		for (double n = 0; n < max_iter; n++) {
			c = a * a - b * b, b = 2 * a*b, a = c;
			a += re, b += im;
			s = a * a + b * b;
			if (s > 1.844674407e+19) {	// 2^2^6
				n -= log(0.5 * log(s) / LN2) / LN2, n += 4;
				double mr = exp(-n * n / 20000);
				n = n * mr + 4 * pow((log(n + 1) + 1), 2) * (1 - mr);
				mr = 5 * sin((n - 6) / 10) + n;
				return _RGB(250 * pow(sin((mr - 8) / 20), 6), 255 * pow(sin((mr + 1) / 20), 4),
					(205 * pow(sin((mr + 2) / 20), 2) + 50) * (1 - pow(sin((mr - 14) / 20), 12)));
			}
		}
		return RGB(0, 0, 0);
	};

	double Cx, Cy;
	const unsigned H = 1;
	COLORREF *img = new COLORREF[w*H];
	for (unsigned y = 0; y < h + H; y++) {
		for (unsigned x = 0; x < w; x++) {
			Cx = (x - ctr_x) / ratio, Cy = -(y - ctr_y) / ratio;
			//SetPixel(hdc, x, y, Mandelbrot(Cx, Cy, limit));
			img[(y % H)*w + x] = Mandelbrot(Cx, Cy, limit);
		}
		if (y != 0 && (y + 1) % H == 0) {
			hbmp = CreateBitmap(w, H, 1, 32, img);
			HDC hdcMem = CreateCompatibleDC(hdc);
			HGDIOBJ img_old = SelectObject(hdcMem, hbmp);
			BITMAP bitmap; GetObject(hbmp, sizeof(bitmap), &bitmap);
			BitBlt(hdc, 0, y - H, bitmap.bmWidth, bitmap.bmHeight, hdcMem, 0, 0, SRCCOPY);
			SelectObject(hdcMem, img_old);
			DeleteDC(hdcMem);
		}
	}
	delete img;

	EndPaint(hWnd, &ps);
}

#include <ctime>
#define PI 3.141592653589793238463
extern double RAND_LCG_DV = 0.36787944117;	// random number seed
#define RAND_LCG_TMS 13.35717028437795
#define RAND_LCG_ADD 0.841470984807897
inline double pick_random(double max) {
	RAND_LCG_DV = fmod(RAND_LCG_DV * RAND_LCG_TMS + RAND_LCG_ADD, max);
	return RAND_LCG_DV;
}
inline double pick_random(double min, double max) {
	RAND_LCG_DV = fmod(RAND_LCG_DV * RAND_LCG_TMS + RAND_LCG_ADD, max - min);
	return RAND_LCG_DV + min;
}
DWORD WINAPI drawAnimation(HANDLE _HWND) {
	//HWND *hWnd = ((HWND*)_HWND);
	HWND hWnd = (HWND)GraphingWindow;
	Sleep(50);
	ShowWindow(hWnd, SW_SHOW);

	HDC hdc = GetDC(hWnd);
	hdcMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmp);

	double S[3][3], C[3][3], T[3];
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			S[i][j] = pick_random(-1, 1);
			C[i][j] = pick_random(-1, 1);
		}
		T[i] = pick_random(-1, 1);
	}
	while (1) {
		double t = (double)(clock());
		t /= 2000;
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				S[i][j] += pick_random(0.01, 0.02) * sin(t);
				C[i][j] += pick_random(0.01, 0.02) * cos(t);
			}
			T[i] += pick_random(0.01, 0.02) * sin(t) * cos(t);
		}
		t = sin(t)*cos(t) + sin(t / 2) + cos(t / 3) + sin(t / 5) + cos(t / 7) + sin(t / 11) + cos(t / 13) + sin(t / 17) + cos(t / 19);
		// t = 6 * sin(t)*cos(t) * sin(t / 2)*cos(t / 3)*sin(t / 5)*cos(t / 7)*sin(t / 11)*cos(t / 13)*sin(t / 17)*cos(t / 19);		// This one is slower
		double u, v;
		for (unsigned y = 0, h = Client.bottom; y < h; y++) {
			v = double(y) / h;
			for (unsigned x = 0, w = Client.right; x < w; x++) {
				u = double(x) / w;
				img_data[y*w + x] = _RGB(
					255 * (log(abs(sin(S[0][0] * t + S[0][1] * u + S[0][2] * v) / cos(C[0][0] * t + C[0][1] * u + C[0][2] * v)) + 2) + T[0] * t),
					255 * (log(abs(sin(S[1][0] * t + S[1][1] * u + S[1][2] * v) / cos(C[1][0] * t + C[1][1] * u + C[1][2] * v)) + 2) + T[1] * t),
					255 * (log(abs(sin(S[2][0] * t + S[2][1] * u + S[2][2] * v) / cos(C[2][0] * t + C[2][1] * u + C[2][2] * v)) + 2) + T[2] * t),
					);
			}
		}
		BitBlt(hdc, 0, 0, Client.right, Client.bottom, hdcMem, 0, 0, SRCCOPY);
		Sleep(10);
	}

	SelectObject(hdcMem, hbmOld);
	DeleteDC(hdc);
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) {
	case WM_CREATE: {	// This message is sent before the window becomes visible
		CREATESTRUCT *pCreate = reinterpret_cast<CREATESTRUCT*>(lParam);
		void* p = pCreate->lpCreateParams;	// p is the last parameter in CreateWindowEx function

		GetClientRect(hWnd, &Client);

		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = Client.right;
		bmi.bmiHeader.biHeight = -Client.bottom; // Order pixels from top to bottom
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32; // last byte not used, 32 bit for alignment
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		// Create DIB section to always give direct access to pixels
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&img_data, NULL, 0);		// don't need to initialize img_data, or memory leaks will occur
		DeleteDC(hdc);

		GraphingWindow = hWnd;
		GraphingThread = CreateThread(NULL, NULL, &drawAnimation, &hWnd, NULL, NULL);
		break;
	}
	case WM_PAINT: {
		//drawMandelbrot(hWnd);
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		BitBlt(hdc, 0, 0, Client.right, Client.bottom, hdcMem, 0, 0, SRCCOPY);
		EndPaint(hWnd, &ps);
		DeleteDC(hdc);
		break;
	}
	case WM_CLOSE: {
		// MessageBox function: https://docs.microsoft.com/en-us/windows/desktop/api/winuser/nf-winuser-messagebox
		//if (MessageBox(hWnd, L"Really quit? \nChanges you made won't be saved.", L"Confirm Quit Request", MB_ICONWARNING | MB_OKCANCEL) == IDOK)
		DestroyWindow(hWnd);
		return 0;
	}
	case WM_DESTROY: {
		DeleteObject(hbmp);
		TerminateThread(GraphingThread, 0);
		PostQuitMessage(0);
		break;
	}
	default: {
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	}

	return 0;
}
