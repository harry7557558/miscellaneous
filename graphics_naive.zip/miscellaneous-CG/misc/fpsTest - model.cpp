#include <Windows.h>
#include <tchar.h>
#include "3D.h"

using namespace std;


#define APPLICATION_NAME "Name"

HWND HWnd;
RECT Client; int clt_w, clt_h;
COLORREF *img; HBITMAP HImg;


#include <chrono>
typedef chrono::high_resolution_clock NTime;
typedef std::chrono::duration<double> fsec;

const auto t0 = NTime::now();




void MainImage(vec3 &col, vec2 coor) {
	col = vec3(0, 0, 0);
}






#include <thread>

bool rendering = false;
void render() {

	if (rendering) return; rendering = true;

	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);


	unsigned clt_size = clt_w * clt_h;
	const unsigned MAX_THREADS = thread::hardware_concurrency();
	const unsigned ppt = 0x1000;
	const unsigned N = clt_size / ppt;

	bool* fn = new bool[MAX_THREADS]; for (int i = 0; i < MAX_THREADS; i++) fn[i] = false;
	thread** T = new thread*[MAX_THREADS]; for (int i = 0; i < MAX_THREADS; i++) T[i] = NULL;

	unsigned released = 0, finished = 0;
	while (finished < N) {
		for (int i = 0; i < MAX_THREADS; i++) {
			if (fn[i]) {
				fn[i] = false;
				delete T[i]; T[i] = 0;
				if (++finished >= N) break;
			}
			if (!fn[i] && !T[i] && released < N) {
				T[i] = new thread([&](unsigned beg, unsigned end, bool* sig) {
					COLORf col;
					for (unsigned i = beg; i < end; i++) {
						MainImage(*(vec3*)&col, vec2(i % clt_w, i / clt_w));
						img[i] = toCOLORREF(col);
					}
					*sig = true;
				}, ppt * released, ppt * (released + 1), fn + i);
				T[i]->detach();
				released++;
			}
		}
	}

	COLORf col;
	for (unsigned i = N * ppt; i < clt_size; i++) {
		MainImage(*(vec3*)&col, vec2(i % clt_w, i / clt_w));
		img[i] = toCOLORREF(col);
	}

	delete fn;
	delete T;



	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);

	rendering = false;

}



#include <string>

HANDLE RenderingThread;
DWORD WINAPI fpsTest(HANDLE H) {

	auto uint2str = [](unsigned n)->string {
		string r;
		while (n) r = char('0' + n % 10) + r, n /= 10;
		return r;
	};
	auto fps2str = [](double a)->string {
		if (a <= 0 || isNaN(a)) return "NaN";
		int e = 3;
		while (a < 100) a *= 10, e--;
		string r;
		while (a != 0) r = char('0' + int(a) % 10) + r, a = int(a) / 10;
		while (e <= 0) r = '0' + r, e++;
		if (e < 3) r.insert(r.begin() + e, '.');
		return r;
	};

	while (1) {
		Sleep(100);
		auto t0 = NTime::now();
		render();
		auto t1 = NTime::now();
		fsec fs = t1 - t0;
		SetWindowTextA(HWnd, &("   " + (fps2str(1 / fs.count()) + "fps") + "      " + (uint2str(clt_w) + "x" + uint2str(clt_h)) + "       " + APPLICATION_NAME)[0]);
	}


	return 0;
}




LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = clt_w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)clt_h : clt_h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};
	switch (message) {
	case WM_CREATE: {
		GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		InitializeClientBitmap(hWnd, HImg, img, false);
		HWnd = hWnd;
		RenderingThread = CreateThread(NULL, NULL, &fpsTest, NULL, NULL, NULL);
		break;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		while (rendering) Sleep(1);
		SuspendThread(RenderingThread);
		DeleteObject(HImg);
		InitializeClientBitmap(hWnd, HImg, img, false);
		render();
		ResumeThread(RenderingThread);
		break;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 120, lpMMI->ptMinTrackSize.y = 80;
		break;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HMem, HImg);
		BitBlt(hdc, 0, 0, Client.right, Client.bottom, HMem, 0, 0, SRCCOPY);
		SelectObject(HMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HMem);
		DeleteDC(hdc);
		break;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		TerminateThread(RenderingThread, NULL);
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}


int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
	const wchar_t CLASS_NAME[] = _T(APPLICATION_NAME);
	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = CLASS_NAME;
	if (!RegisterClassEx(&wc)) return -1;

	HWND hWnd = CreateWindowEx(
		0,
		CLASS_NAME,
		CLASS_NAME,
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		640, 400,
		NULL, NULL, hInstance, NULL
	);
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	return (int)message.wParam;
}


