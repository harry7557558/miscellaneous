
#pragma warning(disable:4244 4018 4010 4305)

#include <Windows.h>
#include <windowsx.h>
#include <tchar.h>

using namespace std;

#include "3D.h"

#include <chrono>
typedef chrono::high_resolution_clock NTime;
typedef chrono::duration<double> fsec;




#include "Ray Casting/SDF_3D.h"

double Imp0(cv3ref p) {	// sphere
	return 1 - p.sqr();
	return p.x*p.x + p.y*p.y / 2.6 + p.z*p.z - 1;
	return exp(4 * (p.sqr() - 2)) + exp(4 * (0.5 - p.x*p.x - p.y*p.y - p.z*p.z / 4)) - 1;
}
double Imp1(cv3ref p) {	// "rounded" cube
	return p.x*p.x*p.x*p.x + p.y*p.y*p.y*p.y + p.z*p.z*p.z*p.z - 1;
	return pow(p.x, 8) + pow(p.y, 8) + pow(p.z, 8) - 1;
	return p.x*p.x*p.x*p.x + p.y*p.y*p.y*p.y + p.z*p.z*p.z*p.z - p.x*p.x - p.y*p.y;
	return p.x*p.x*p.x*p.x + p.y*p.y*p.y*p.y + p.z*p.z*p.z*p.z - p.x*p.x - p.y*p.y + 0.1;
}
double Imp2(cv3ref p) {	// torus
	return pow(p.sqr() + 0.8, 2) - 4 * p.xy().sqr();
	return pow(p.sqr() + 3.5, 2) - 16 * p.xy().sqr();
	return p.sqr()*p.sqr() - p.xy().sqr();
	return exp(10 * (4 * p.xy().sqr() - pow(p.sqr() + 0.96, 2))) + exp(10 * (4 * p.xz().sqr() - pow(p.sqr() + 0.96, 2))) + exp(10 * (4 * p.yz().sqr() - pow(p.sqr() + 0.96, 2))) - 1;
	return pow(pow(p.x, 6) + pow(p.y, 6) + pow(p.z, 6) + 3.5, 2) - 16 * (pow(p.x, 6) + pow(p.y, 6));
}
double Imp3(cv3ref p) {	// peanut
	return exp(1 - (p.x - 1)*(p.x - 1) - p.y*p.y - p.z*p.z) + exp(1 - (p.x + 1)*(p.x + 1) - p.y*p.y - p.z*p.z) - 1;
	return exp(4 * (1.2 - (p.x - 1)*(p.x - 1) - (p.y - 1)*(p.y - 1) - (p.z - 1)*(p.z - 1))) + exp(4 * (1.2 - (p.x + 1)*(p.x + 1) - (p.y - 1)*(p.y - 1) - (p.z - 1)*(p.z - 1))) \
		+ exp(4 * (1.2 - (p.x - 1)*(p.x - 1) - (p.y + 1)*(p.y + 1) - (p.z - 1)*(p.z - 1))) + exp(4 * (1.2 - (p.x + 1)*(p.x + 1) - (p.y + 1)*(p.y + 1) - (p.z - 1)*(p.z - 1))) \
		+ exp(4 * (1.2 - (p.x - 1)*(p.x - 1) - (p.y - 1)*(p.y - 1) - (p.z + 1)*(p.z + 1))) + exp(4 * (1.2 - (p.x + 1)*(p.x + 1) - (p.y - 1)*(p.y - 1) - (p.z + 1)*(p.z + 1))) \
		+ exp(4 * (1.2 - (p.x - 1)*(p.x - 1) - (p.y + 1)*(p.y + 1) - (p.z + 1)*(p.z + 1))) + exp(4 * (1.2 - (p.x + 1)*(p.x + 1) - (p.y + 1)*(p.y + 1) - (p.z + 1)*(p.z + 1))) - 1;
	return exp(2 * (0.5 - p.x*p.x - p.y*p.y - 1.5*(p.z - 0.8)*(p.z - 0.8))) + exp(2 * (1.5 - p.x*p.x - p.y*p.y - 1.5*(p.z + 0.8)*(p.z + 0.8))) + 0.1*sin(20 * p.x)*sin(20 * p.x)*sin(20 * p.z) - 1;
}
double Imp4(cv3ref p) {	// heart
	return pow(p.x*p.x + 2.25*p.y*p.y + p.z*p.z - 1, 3) - (p.x*p.x + 0.1125*p.y*p.y)*p.z*p.z*p.z;
}
double Imp5(cv3ref p) {	// open surface that intersects itself
	return p.x*p.x + p.y*p.y + p.z*p.z*p.z - p.z*p.z;
}
double Imp6(cv3ref p) {	// jax
	return ((p.x - 1)*(p.x - 1) + p.y*p.y + p.z*p.z) * ((p.x + 1)*(p.x + 1) + p.y*p.y + p.z*p.z) * (p.x*p.x + (p.y - 1)*(p.y - 1) + p.z*p.z) * (p.x*p.x + (p.y + 1)*(p.y + 1) + p.z*p.z) - 1.1;
	return ((p.x - 1)*(p.x - 1) + p.y*p.y + p.z*p.z) * ((p.x + 1)*(p.x + 1) + p.y*p.y + p.z*p.z) * (p.x*p.x + (p.y - 1)*(p.y - 1) + p.z*p.z) * (p.x*p.x + (p.y + 1)*(p.y + 1) + p.z*p.z) \
		* (p.x*p.x + p.y*p.y + (p.z - 1)*(p.z - 1)) * (p.x*p.x + p.y*p.y + (p.z + 1)*(p.z + 1)) - 1.5;
}
double Imp7(cv3ref p) {	// test thin lines
	return SD_Bezier3(vec3(-1, -1, -1), vec3(-1, 1, 0), vec3(1, 1, 0), vec3(-1, -1, 1), p) - 0.1;
	return sd_OpSmoothedUnion(min((p - vec3(-1, 0, 0)).mod(), (p - vec3(1, 0, 0)).mod()) - 0.5, SD_Segment(vec3(-1, 0, 0), vec3(1, 0, 0), p) - 0.1, 0.1);
	return sd_OpSmoothedUnion(sd_OpSmoothedUnion(\
		sd_OpSmoothedUnion((vec3(abs(p.x), p.y, p.z) - vec3(1, 0, 0)).mod() - 0.3, SD_Segment(vec3(-1, 0, 0), vec3(1, 0, 0), p), 0.1), \
		sd_OpSmoothedUnion((vec3(p.x, abs(p.y), p.z) - vec3(0, 1, 0)).mod() - 0.3, SD_Segment(vec3(0, -1, 0), vec3(0, 1, 0), p), 0.1), 0.1), \
		sd_OpSmoothedUnion((vec3(p.x, p.y, abs(p.z)) - vec3(0, 0, 1)).mod() - 0.3, SD_Segment(vec3(0, 0, -1), vec3(0, 0, 1), p), 0.1), 0.1) - 0.075;
}
double Imp8(cv3ref p) {	// test genus
	return 2 * p.y*(p.y*p.y - 3 * p.x*p.x)*(1 - p.z*p.z) + (p.x*p.x + p.y*p.y)*(p.x*p.x + p.y*p.y) - (9 * p.z*p.z - 1)*(1 - p.z*p.z);
	return SD_Torus(1, 0, p - vec3(-1, -sqrt(3) / 3)) * SD_Torus(1, 0, p - vec3(1, -sqrt(3) / 3)) * SD_Torus(1, 0, p - vec3(0, sqrt(3) / 1.5)) - 0.3;
}

double ImpX(cv3ref p) {		// cup constructed with csg, ultra complex piecewise implicit surface
	vec3 P = p + vec3(0, 0, 0.5);
	double cyl = SD_Cylinder_z(0.75, 0, 2, P);
	double sd = abs(cyl - 0.15) - 0.08;
	sd = sd_OpSmoothedSubtract(sd, 1.8 - P.z, 0.08);
	double handle = SD_OpExtrusion([](vec2 p) {
		return abs(sd_Polygon({ vec2(0,0.9), vec2(0.4,0.9), vec2(0.3,0.35), vec2(0,0.1) }, p) - 0.2) - 0.05;
	}, 0.3, vec3(P.x - 1.03, P.z - 0.38, P.y + 0.15)) - 0.1;
	handle = sd_OpSubtract(handle, cyl - 0.12);
	sd = sd_OpSmoothedUnion(sd, handle, 0.05);
	//return sd * sd;
	return sd;
}

#define Imp Imp8



#include <vector>
#include <stack>
vector<triangle*> T;
vector<triangle*> Td;

struct gapNode {
	vec3 p;
	gapNode *m = 0, *n = 0;
	gapNode *nb = 0;
};



#define EPSILON 1e-6
#define UPSILON 1e-4

// tetrahedron method numerically calculate gradient
vec3 calcGradient(double(*f)(cv3ref), cv3ref p) {
	double k_111 = f(vec3(p.x + EPSILON, p.y + EPSILON, p.z + EPSILON));
	double k_100 = f(vec3(p.x + EPSILON, p.y - EPSILON, p.z - EPSILON));
	double k_010 = f(vec3(p.x - EPSILON, p.y + EPSILON, p.z - EPSILON));
	double k_001 = f(vec3(p.x - EPSILON, p.y - EPSILON, p.z + EPSILON));
	vec3 n(k_111 + k_100 - k_010 - k_001, k_111 - k_100 + k_010 - k_001, k_111 - k_100 - k_010 + k_001);
	n /= 4 * EPSILON; return n;
}

// numerically calculate radius of curvature
double calcCurvatureR(double(*f)(cv3ref), cv3ref p) {
	vec3 n = calcGradient(f, p);
	mat3 R = RotationMatrix_xz(atan2(sqrt(n.x*n.x + n.y*n.y), n.z), atan2(n.x, -n.y));
	vec3 x = R * vec3(UPSILON, 0), y = R * vec3(0, UPSILON);
	double ax = dot(calcGradient(f, p + x).unitvec(), calcGradient(f, p - x).unitvec());
	double ay = dot(calcGradient(f, p + y).unitvec(), calcGradient(f, p - y).unitvec());
	ax = sqrt(1 - ax * ax), ay = sqrt(1 - ay * ay);
	double r = 2 * UPSILON / max(ax, ay);
	return Clamp(r, 0.1, 1);
}

// Newton's iteration method finding point on surface
bool land(double(*f)(cv3ref), vec3 &p) {
	vec3 n; double d;
	int i = 0; do {
		n = calcGradient(f, p);
		d = f(p);
		p -= (d / n.sqr()) * n;
		if (++i > 50 || isNaN(d)) return false;
	} while (abs(d) > EPSILON);
	return true;
}

// non-recursive growing phase, no depth limit, where a stack is needed
typedef struct {
	vec3 v1, v2, v3;
	int stage = 0;
} spread_step;
bool spread(double(*f)(cv3ref), vec3 v1, vec3 v2, double r, gapNode* &g) {
	const COLORf col = RGBf(0.8, 0.8, 0.8);
	stack<spread_step> S;
	vec3 v3;
	S.push(spread_step());
	S.top().v1 = v1, S.top().v2 = v2;
	do {
		v1 = S.top().v1, v2 = S.top().v2, v3 = S.top().v3;
		if (S.top().stage == 0) {
			//double R = r * max(max(calcCurvatureR(f, v1), calcCurvatureR(f, v2)), calcCurvatureR(f, 0.5*(v1 + v2)));
			double R = r;
			v3 = R * (RotationMatrix(calcGradient(f, v1), PI / 3) * (v2 - v1).unitvec()) + v1;
			land(f, v3);
			bool s = true;
			//R = 0.6 * r * max(max(calcCurvatureR(f, v1), calcCurvatureR(f, v2)), calcCurvatureR(f, v3));
			R = 0.578*r;
			for (int i = 0; i < T.size(); i++) {	// O(n^2)
				if ((v3 - T[i]->A).mod() < R || (v3 - T[i]->B).mod() < R || (v3 - T[i]->C).mod() < R) {
					s = false; S.pop(); break;
				}
			}
			if (s) {
				T.push_back(new triangle(v1, v2, v3, col));
				S.top().v3 = v3;
				S.top().stage = 1;
				S.push(spread_step());
				S.top().v1 = v1, S.top().v2 = v3;
			}
		}
		else if (S.top().stage == 1) {
			g->n = new gapNode;
			g->n->p = v3, g->n->m = g, g->n->n = 0;
			g = g->n;
			S.top().stage = 2;
			S.push(spread_step());
			S.top().v1 = v3, S.top().v2 = v2;
		}
		else S.pop();
	} while (!S.empty());
	return true;
}


// debug
auto checkChain = [](gapNode *g) {
	int N = T.size();
	gapNode *g0 = g;
	while (1) {
		g = g->n;
		if (g->m->n != g) {
			Dout("g->m->n != g : " << g);
		}
		if (g->n->m != g) {
			Dout("g->n->m != g : " << g);
		}
		if (g == g0) {
			Dout("OK," << (T.size() - N));
			break;
		}
		if (--N <= 0) {
			Dout("--N == 0");
		}
	}
};
auto drawNB = [](gapNode *g, COLORf col) {
	if (g != 0) {
		checkChain(g);
		gapNode *g0 = g;
		do {
			if (g->nb != 0) {
				Td.push_back(new triangle(g->p, g->nb->p + vec3(0.003, 0, 0), g->nb->p - vec3(0.003, 0, 0), col));
				Td.push_back(new triangle(g->p, g->nb->p + vec3(0, 0.003, 0), g->nb->p - vec3(0, 0.003, 0), col));
				Td.push_back(new triangle(g->p, g->nb->p + vec3(0, 0, 0.003), g->nb->p - vec3(0, 0, 0.003), col));
			}
		} while ((g = g->n) != g0);
		g = 0;
	}
};

// fill a gap, g can be any node on the gap
auto calcNeighbour = [](double(*f)(cv3ref), gapNode *g, double r) {		// O(n^2)
	g->nb = 0;
	if (g->n->n == g || g->n->n->n == g) return;
	gapNode *m = g->m, *n = g->n;
	double d, md = INFINITY;
	mat3 R = RotationMatrix(calcGradient(f, g->p), PI / 2);
	auto crossTrig = [&](const gapNode *g, const gapNode *h)->bool {	// test if a triangle is between the two nodes (heuristics, not always work)
		if ((g->p - h->p).mod() > 2.5 * r) return true;
		for (int i = 0; i < T.size(); i++) {
			triangle *t = T[i];
			if ((g->p - t->A).sqr() < 16 * r*r) {
				if (g->p == t->A || g->p == t->B || g->p == t->C) {
					if (h->p == t->A || h->p == t->B || h->p == t->C) return true;

					if (g->p == t->B) swap(t->A, t->B); else if (g->p == t->C) swap(t->A, t->C);
					vec3 b = (t->B - t->A).unitvec(), c = (t->C - t->A).unitvec(), p = (h->p - g->p).unitvec(); double m = dot(b, c);
					if (dot(p, b) > m && dot(p, c) > m) return true;
				}
				if (h->p == t->A || h->p == t->B || h->p == t->C) {
					if (h->p == t->B) swap(t->A, t->B); else if (h->p == t->C) swap(t->A, t->C);
					vec3 b = (t->B - t->A).unitvec(), c = (t->C - t->A).unitvec(), p = (g->p - h->p).unitvec(); double m = dot(b, c);
					if (dot(p, b) > m && dot(p, c) > m) return true;
				}
			}
		}
		return false;
	};
	gapNode *h = n->n;
	do {
		d = (h->p - g->p).mod();
		if (d < md && !crossTrig(g, h)) md = d, g->nb = h;
	} while ((h = h->n) != m);

};
void fillGap(double(*f)(cv3ref), gapNode* &g, double r, int N) {
	const COLORf col = RGBf(1, 0.6, 0);
	gapNode *g0 = g;
	if (N == 0) do {	// O(n^3)
		calcNeighbour(f, g, r);
	} while ((g = g->n) != g0);


	// fill angles less than 65° within the gap
	auto cutEars = [](double(*f)(cv3ref), gapNode* &g, double r) ->bool {
		const COLORf col = RGBf(0.9, 0.8, 0.7);
		bool res = false;
		while (dot((g->m->p - g->p).unitvec(), (g->n->p - g->p).unitvec()) > 0.4 && det(g->m->p - g->p, g->n->p - g->p, calcGradient(f, g->p)) < 0) {
			T.push_back(new triangle(g->m->p, g->p, g->n->p, col));
			gapNode *h = g->m; g = g->n; delete g->m; g->m = h, h->n = g;
			calcNeighbour(f, h, r); calcNeighbour(f, g, r);
			res = true;
		}
		gapNode *g0 = g;
		do {
			if (dot((g->m->p - g->p).unitvec(), (g->n->p - g->p).unitvec()) > 0.4 && det(g->m->p - g->p, g->n->p - g->p, calcGradient(f, g->p)) < 0) {
				T.push_back(new triangle(g->m->p, g->p, g->n->p, col));
				gapNode *h = g->m; g = g->n; delete g->m; g->m = h, h->n = g;
				calcNeighbour(f, h, r); calcNeighbour(f, g, r);
				res = true;
			}
		} while ((g = g->n) != g0);
		return res;
	};

	auto fillX = [](double(*f)(cv3ref), gapNode* &g, double r)->bool {
		const COLORf col = RGBf(0.8, 0.9, 0.7);
		gapNode *a, *b, *c, *d, *g0 = g;
		do {
			a = g, b = g->n, c = b->n, d = c->n;
			//if ((a->nb == c && b->nb == d && ((c->nb == a && d->nb == b) || (a->nb == d && d->nb == a))) || (a->nb == d && d->nb == a)) {
			if ((b->nb == d && c->nb == a) || (a->nb == d && d->nb == a)) {
				if ((a->p - c->p).mod() < (b->p - d->p).mod()) T.push_back(new triangle(a->p, b->p, c->p, col)), T.push_back(new triangle(a->p, d->p, c->p, col));
				else T.push_back(new triangle(a->p, b->p, d->p, col)), T.push_back(new triangle(c->p, b->p, d->p, col));
				delete b, c; b = c = 0;
				a->n = d, d->m = a;
				calcNeighbour(f, a, r), calcNeighbour(f, d, r);
				return true;
			}
		} while ((g = g->n) != g0);
		return false;
	};

	auto fillT = [](double(*f)(cv3ref), gapNode* &g, double r)->bool {
		const COLORf col = RGBf(0.7, 0.9, 0.8);
		gapNode *a, *b, *c, *g0 = g;
		do {
			a = g, b = g->n, c = b->n;
			if (a->nb == c && c->nb == a) {
				T.push_back(new triangle(a->p, b->p, c->p, col));
				delete b; b = 0;
				a->n = c, c->m = a;
				calcNeighbour(f, a, r), calcNeighbour(f, c, r);
				return true;
			}
		} while ((g = g->n) != g0);
		return false;
	};

	auto fillW = [](double(*f)(cv3ref), gapNode* &g, double r)->bool {
		const COLORf col = RGBf(0.7, 0.9, 0.8);
		gapNode *a, *b, *c, *d, *e, *g0 = g;
		do {
			a = g, b = g->n, c = b->n, d = c->n, e = d->n;
			if (a == e) return false;
			if (a->nb == e && e->nb == a || a == e->n) {
				gapNode *_m = a->m, *_n = e->n; a->m = e, e->n = a;
				gapNode *t = a, *mt = 0; double s, ms = 1;
				for (int i = 0; i < 5; i++) {
					s = dot((t->n->p - t->p).unitvec(), (t->m->p - t->p).unitvec());
					if (s < ms) ms = s, mt = t;
					t = t->n;
				}
				T.push_back(new triangle(mt->p, mt->m->p, mt->m->m->p, col));
				T.push_back(new triangle(mt->p, mt->n->p, mt->n->n->p, col));
				T.push_back(new triangle(mt->p, mt->m->m->p, mt->n->n->p, col));
				delete b, c, d; b = c = d = 0;
				a->m = _m, e->n = _n; a->n = e, e->m = a;
				calcNeighbour(f, a, r), calcNeighbour(f, e, r);
				return true;
			}
		} while ((g = g->n) != g0);
		return false;
	};

	auto fillH = [](double(*F)(cv3ref), gapNode* &g, double r)->bool {
		const COLORf col = RGBf(0.6, 0.8, 0.8);
		gapNode *a, *b, *c, *d, *e, *f, *g0 = g;
		do {
			a = g, b = g->n, c = b->n, d = c->n, e = d->n, f = e->n;
			if (a == e || a == f) return false;
			if ((a->nb == f && f->nb == a) || a == f->n) {
				gapNode *_m = a->m, *_n = f->n; a->m = f, f->n = a;
				gapNode *t = a, *mt = 0; double s, ms = 1;
				for (int i = 0; i < 5; i++) {
					s = dot((t->n->p - t->p).unitvec(), (t->m->p - t->p).unitvec());
					if (s < ms) ms = s, mt = t;
					t = t->n;
				}
				t = mt;
				if (dot((t->m->m->m->p - t->m->m->p).unitvec(), (t->n->n->n->p - t->n->n->p).unitvec()) < -0.8) {
					gapNode *a = t, *b = t->m, *c = t->m->m, *d = t->m->m->m;
					if ((a->p - c->p).mod() < (b->p - d->p).mod()) T.push_back(new triangle(a->p, b->p, c->p, col)), T.push_back(new triangle(a->p, d->p, c->p, col));
					else T.push_back(new triangle(a->p, d->p, b->p, col)), T.push_back(new triangle(c->p, d->p, b->p, col));
					b = t->n, c = t->n->n;
					if ((a->p - c->p).mod() < (b->p - d->p).mod()) T.push_back(new triangle(a->p, b->p, c->p, col)), T.push_back(new triangle(a->p, d->p, c->p, col));
					else T.push_back(new triangle(a->p, d->p, b->p, col)), T.push_back(new triangle(c->p, d->p, b->p, col));
				}
				else {
					T.push_back(new triangle(t->p, t->m->p, t->m->m->p, col));
					T.push_back(new triangle(t->p, t->n->p, t->n->n->p, col));
					T.push_back(new triangle(t->p, t->m->m->p, t->n->n->p, col));
					T.push_back(new triangle(t->m->m->m->p, t->m->m->p, t->n->n->p, col));
				}
				delete b, c, d, e; b = c = d = e = 0;
				a->m = _m, f->n = _n; a->n = f, f->m = a;
				calcNeighbour(F, a, r), calcNeighbour(F, f, r);
				return true;
			}
		} while ((g = g->n) != g0);
		return false;
	};

	auto fillTg = [](double(*f)(cv3ref), gapNode* &g, double r)->bool {
		const COLORf col = RGBf(0.7, 0.9, 0.8);
		gapNode *a, *b, *c, *g0 = g;
		do {
			a = g, b = g->n, c = b->n;
			if (a->nb == c || c->nb == a) {
				T.push_back(new triangle(a->p, b->p, c->p, col));
				delete b; b = 0;
				a->n = c, c->m = a;
				calcNeighbour(f, a, r), calcNeighbour(f, c, r);
				return true;
			}
		} while ((g = g->n) != g0);
		return false;
	};

	bool s = false, t = false;
	do {
		s = true, t = false;
		do {
			s = (cutEars(f, g, r) || fillX(f, g, r) || fillT(f, g, r) || fillW(f, g, r) || fillH(f, g, r));
			if (s) t = true;
		} while (s);
		if (fillTg(f, g, r)) t = true;
	} while (t);


	if (g->n->n == g) {
		Dout("Succeed");
		delete g->n; //delete g;
		g = 0; return;
	}

	g0 = g;
	do {
		if (g->nb != 0 && g->nb->nb != 0 && g->nb->nb == g && g->n->nb != 0 && g->n->nb->nb != 0 && g->n->nb->nb->m == g && g->nb->m == g->n->nb) {

			// construct bridge, genus n construct 2n bridges
			gapNode *h = g->n;
			T.push_back(new triangle(g->p, g->nb->p, h->nb->p, col));
			T.push_back(new triangle(g->p, h->p, h->nb->p, col));
			g->nb->m = g, g->n = g->nb;
			h->nb->n = h, h->m = h->nb;
			calcNeighbour(f, g, r); calcNeighbour(f, g->n, r);
			calcNeighbour(f, h, r); calcNeighbour(f, h->m, r);
			Dout("Bridge Constructed");

			fillGap(f, g, r, N + 1);
			if (g != 0) dout("Fail\n");

			return;
		}
	} while ((g = g->n) != g0);

	Dout("Bridge Construction Failed");
}

// subdivide triangles to fit the surface
void subdivide(double(*f)(cv3ref)) {
	int N = T.size();
	for (int i = 0; i < N; i++) {
		triangle t = *T[i];
		vec3 AB = 0.5*(t.A + t.B), BC = 0.5*(t.B + t.C), CA = 0.5*(t.C + t.A);
		land(f, AB), land(f, BC), land(f, CA);
		T.push_back(new triangle(AB, t.B, BC, t.col));
		T.push_back(new triangle(BC, t.C, CA, t.col));
		T.push_back(new triangle(CA, t.A, AB, t.col));
		T.push_back(new triangle(AB, BC, CA, t.col));
	}
	T.erase(T.begin(), T.begin() + N);
}


bool triangulate(double(*f)(cv3ref), double r) {
	if (!T.empty()) return false;

	// settle first point
	vec3 p; int tp = 0;
	do {
		p = pick_random(2) * random_vec3();
		if (++tp > 1000) return false;
	} while (!land(f, p));
	// once the first point is settled, failing in landing points is not easy to happen

	// settle first triangle
	vec3 n = calcGradient(f, p).unitvec();
	vec3 i = cross(n, vec3(0, 0, 1)).unitvec(), j = RotationMatrix(n, PI / 3) * i;
	vec3 a = p + r * i, b = p + r * j;
	land(f, a); land(f, b);
	T.push_back(new triangle(p, a, b, RGBf(0.8, 0, 0)));

	// growing phase, gap defined by a list of vertexes
	gapNode *g0 = new gapNode; g0->p = p, g0->m = 0, g0->n = new gapNode;
	gapNode *g = g0->n; g->m = g0, g->p = b, g->n = 0;
	if (!spread(f, b, a, r, g)) return false;
	g->n = new gapNode; g->n->m = g, g->n->p = a, g->n->n = g0, g0->m = g->n;
	g0 = g;

	fillGap(f, g, r, 0);

	//subdivide(f); subdivide(f); subdivide(f);


	for (int i = 0; i < Td.size(); i++) T.push_back(Td[i]);
	//for (int i = 0; i < T.size(); i++) T[i]->col = RGBf(0.87, 0.8, 0.7);

	return false;
}




#pragma region Rendering

#define WIN_NAME " Implicit Triangulation"

HWND HWnd;
int clt_w, clt_h;
COLORREF *img; HBITMAP HImg;

vec3 Pos(5, 5, 3), prevPos;
double Unit = 500, dist = Pos.mod();
vec2 Cursor, prevCursor;

affine3 fromWorld;
mat3 fromworld;

typedef struct { vec3 O; vec3 A; vec3 B; } Screen;
Screen Scr;
inline vec3 fromScreen(double u, double v) {
	return Scr.O + u * Scr.A + v * Scr.B;
}

void recalc() {
	fromWorld.init();
	fromWorld.translate(-Pos);
	double rz = atan2(-Pos.x, Pos.y), rx = atan2(hypot(Pos.x, Pos.y), -Pos.z);
	fromWorld.rotate_z(-rz); fromWorld.rotate_x(PI - rx); fromWorld.rotate_z(PI);
	fromWorld.translate(0, 0, 1);
	fromWorld.perspective(-1);
	fromWorld.scale(Unit);
	fromWorld.translate(0.5*clt_w, 0.5*clt_h);
	fromworld = RotationMatrix_zx(atan2(-Pos.x, Pos.y), atan2(hypot(Pos.x, Pos.y), -Pos.z));
	Scr.O = fromworld * vec3(0.5*clt_w / Unit, -0.5*clt_h / Unit, 1), Scr.A = fromworld * vec3(-clt_w / Unit, 0), Scr.B = fromworld * vec3(0, clt_h / Unit);
	fromworld = RotationMatrix_zx(atan2(Pos.x, -Pos.y), atan2(hypot(Pos.x, Pos.y), Pos.z));
	dist = Pos.mod();
}

//const vec3 light = vec3(-0.3, 0.1, 1).unitvec();
const vec3 light = vec3(0.6, 0.6, 1).unitvec();

void render() {
	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);

	recalc();
	double *ZB = new double[clt_w*clt_h];
	for (int i = 0, l = clt_w * clt_h; i < l; i++) ZB[i] = -Unit, img[i] = 0;
	vec3 Light = fromworld * light;

	// rasterize triangles
	for (int i = 0; i < T.size(); i++) {
		triangle t(fromWorld*T[i]->A, fromWorld*T[i]->B, fromWorld*T[i]->C);
		if (t.A.z > -Unit && t.B.z > -Unit && t.C.z > -Unit) {
			vec3 d = ((T[i]->A + T[i]->B + T[i]->C) / 3 - Pos).unitvec();
			if (dot(d, T[i]->n) > 0) T[i]->n = -T[i]->n;
			double dif = dot(T[i]->n, Light); if (dif < 0) dif = 0;
			COLORf col = (dif + 0.2*pow(max(dot(d, Light), 0), 4))*T[i]->col + (0.5 - 0.5*dif)*0.15*T[i]->col;
			fillTrigInZBuffer(img, clt_w, clt_h, ZB, t, toCOLORREF(col));
		}
	}


	delete ZB;

	// axis, painter's algo
	double m = 0.1*dist;
	vec2 dr = 0.5*vec2(clt_w, clt_h) - 0.2*vec2(min(clt_w, clt_h), min(clt_w, clt_h));
	vec3 O = fromWorld * vec3(0, 0, 0) + dr;
	vec3 P[3] = { vec3(m, 0, 0), vec3(0, m, 0), vec3(0, 0, m) };
	for (int i = 0; i < 3; i++) P[i] = fromWorld * P[i] + dr;
	for (int i = 0; i < 3; i++) {
		int m = 0; double d = INFINITY;
		for (int n = 0; n < 3; n++) if (P[n].z < d) m = n, d = P[n].z;
		drawLine(img, clt_w, clt_h, O.x, O.y, P[m].x, P[m].y, 0.005*Unit, m == 0 ? _RGB(255, 0, 0) : m == 1 ? _RGB(0, 128, 0) : _RGB(0, 0, 255));
		P[m].z = INFINITY;
	}


	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);
}

#pragma endregion






// click and drag: rotate view
// right click: remove a triangle (ctrl+z to undo)

bool mouse_down = false;
bool Ctrl = false;

stack<triangle*> CtrlZ;

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {

	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, int w, int h, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)h : (long)h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = bmi.bmiColors[0].rgbGreen = bmi.bmiColors[0].rgbRed = bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};

	switch (message) {
	case WM_CREATE: {
		RECT Client; GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		break;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		RECT Client; GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		Unit *= sqrt((clt_w * clt_h) / (prev_w * prev_h));
		DeleteObject(HImg);
		InitializeClientBitmap(hWnd, HImg, img, clt_w, clt_h, false);
		render();
		break;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 300, lpMMI->ptMinTrackSize.y = 200;
		break;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HMem, HImg);
		BitBlt(hdc, 0, 0, clt_w, clt_h, HMem, 0, 0, SRCCOPY);
		SelectObject(HMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HMem);
		DeleteDC(hdc);
		break;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		while (!CtrlZ.empty()) T.push_back(CtrlZ.top()), CtrlZ.pop();
		for (int i = 0; i < T.size(); i++) delete T[i]; T.clear();
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
	case WM_MOUSEMOVE: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		if (mouse_down) {
			vec2 dC = 0.02 * (prevCursor - Cursor);
			Pos = RotationMatrix_z(dC.x) * prevPos;
			double a = acos(Pos.unitvec().z);
			if (a - dC.y < 0.001) dC.y = a - 0.001;
			if (a - dC.y > 3.141) dC.y = a - 3.141;
			Pos = RotationMatrix(cross(Pos, vec3(0, 0, 1)), dC.y) * Pos;
		}
		render();
		break;
	}
	case WM_MOUSEWHEEL: {
		double delta = GET_WHEEL_DELTA_WPARAM(wParam);
		double s = exp(-0.001*delta);
		if (Pos.mod()*s > 100) Pos = 100 * Pos.unitvec();
		else if (Pos.mod()*s < 0.1) Pos = 0.1 * Pos.unitvec();
		else Pos *= s;
		render();
		break;
	}
	case WM_LBUTTONDOWN: {
		mouse_down = true;
		prevPos = Pos, prevCursor = Cursor;
		SetCapture(hWnd);
		render();
		break;
	}
	case WM_LBUTTONUP: {
		ReleaseCapture();
		mouse_down = false;
		render();
		break;
	}
	case WM_RBUTTONDOWN: {
		double d, md = INFINITY;
		int dr = -1;
		for (int i = 0; i < T.size(); i++) {
			if (T[i]->IntersectionTest(Pos, fromScreen(Cursor.x / clt_w, Cursor.y / clt_h).unitvec(), d)) {
				if (d < md) md = d, dr = i;
			}
		}
		if (dr != -1) {
			CtrlZ.push(T[dr]);
			T.erase(T.begin() + dr);
		}
		render();
		break;
	}
	case WM_KEYDOWN: {
		if (wParam == VK_CONTROL) Ctrl = true;
		if (wParam == 'Z' && Ctrl && !CtrlZ.empty()) {
			T.push_back(CtrlZ.top()), CtrlZ.pop();
			render();
		}
		break;
	}
	case WM_KEYUP: {
		if (wParam == VK_CONTROL) Ctrl = false;
		break;
	}
	}
	return DefWindowProc(hWnd, message, wParam, lParam);

}


int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {

	triangulate(Imp, 0.1);

	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = _T(WIN_NAME);
	if (!RegisterClassEx(&wc)) return -1;


	HWnd = CreateWindow(
		_T(WIN_NAME),
		_T(WIN_NAME),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		600, 400,
		NULL, NULL, hInstance, NULL
	);

	ShowWindow(HWnd, nCmdShow); UpdateWindow(HWnd);


	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	CheckMemoryLeaks;

	return (int)message.wParam;
}



