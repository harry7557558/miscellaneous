#ifndef UNICODE
#define UNICODE
#endif

#pragma warning(disable:4244 4018 4010 4305)
//#pragma optimize("",off)

#include <Windows.h>
#include <windowsx.h>
#include <tchar.h>

#include "3D.h"
#include <thread>

using namespace std;

#include <chrono>
typedef chrono::high_resolution_clock NTime;
typedef std::chrono::duration<double> fsec;

#ifdef _DEBUG
#define Fill_N(First,Count,Val) for (unsigned i = 0; i < Count; i++) First[i] = Val;
#else
#include <memory>
#define Fill_N(First,Count,Val) uninitialized_fill_n(First, Count, Val)
#endif


#define APPLICATION_NAME " Swept Surface"
#define WINC_NAME " Swept Surface - Edit Cross Section"
#define WINF_NAME " Swept Surface - Edit Axis"
#define WIN_NAME " Swept Surface - Visualization"




HWND HWndC, HWndF, HWnd;
int cltC_w, cltC_h, cltF_w, cltF_h, clt_w, clt_h, img_w, img_h;
COLORREF *imgC, *imgF, *img, *img_base; HBITMAP HImgC, HImgF, HIMG;
double* ZB = 0;

#define AA 1




#include <vector>

#define CrossSec_Subsecs 4	// at least 3
#define Axis_CtrlPoints 6

typedef struct { vec2 v1; vec2 v2; double t; } seg2;
typedef struct { vec3 p; vec3 d; } nod3;

seg2* CSComps[CrossSec_Subsecs + 1];
nod3 AxisComps[Axis_CtrlPoints];



void initModel() {
	const double r = 1, l = r * ((cos(PI / CrossSec_Subsecs) - 0.5*cos(2 * PI / CrossSec_Subsecs) - 0.5) / sin(2 * PI / CrossSec_Subsecs) / 0.1875);
	for (int i = 0; i < CrossSec_Subsecs; i++) {	// fit a circle
		double a = 2 * PI*(double(i) / CrossSec_Subsecs), c = cos(a), s = sin(a);
		vec2 p(r*c, r*s), d(s, -c);
		CSComps[i] = new seg2; CSComps[i]->v1 = p + 0.5*l*d, CSComps[i]->v2 = p - 0.5*l*d, CSComps[i]->t = 0.5;
	}
	CSComps[CrossSec_Subsecs] = CSComps[0];

	//CSComps[0]->v1 = vec2(1.3899999999999999, -0.63500000000000001), CSComps[0]->v2 = vec2(0.53000000000000003, 1.0950000000000000);
	//CSComps[1]->v1 = vec2(0.88000000000000000, 0.15500000000000000), CSComps[1]->v2 = vec2(0.29999999999999999, -0.26500000000000001);
	//CSComps[2]->v1 = vec2(-0.99999999999999989, 0.55228474983079368), CSComps[2]->v2 = vec2(-2.0539862483500118, -0.59352200033490599);
	//CSComps[3]->v1 = vec2(-0.97999999999999998, -1.2250000000000001), CSComps[3]->v2 = vec2(0.55228474983079334, -1.0000000000000000);

	const double R = 1.2, H = 6, N = 1.5;
	for (int i = 0; i < Axis_CtrlPoints; i++) {
		double t = i / (Axis_CtrlPoints - 1.0);
		AxisComps[i].p = vec3(R*cos(2 * PI*N*t), R*sin(2 * PI*N*t), H*t - 0.5*H), AxisComps[i].d = vec3(-R * N*sin(2 * PI*N*t), R * N*cos(2 * PI*N*t), 0.5*H / PI);
	}
}


void destruct() {
	for (int i = 0; i < CrossSec_Subsecs; i++) delete CSComps[i];
}






#pragma region Rendering Cross Section Window

double UnitC = 100;

vec2 Cursor_C;

int fitted_c = -1;
int selected_c = -1;
void fitpoint_c() {
	fitted_c = -1;
	vec2 s = (Cursor_C - vec2(cltC_w, cltC_h) / 2) / UnitC;
	double d = 20 / UnitC, td;
	for (int i = 0; i < CrossSec_Subsecs; i++) {
		seg2* p = CSComps[i];
		td = (p->v1 - s).mod(); if (td < d) d = td, fitted_c = 3 * i;
		td = (p->v2 - s).mod(); if (td < d) d = td, fitted_c = 3 * i + 1;
		td = ((1 - p->t) * p->v1 + p->t * p->v2 - s).mod(); if (td <= d) d = td, fitted_c = 3 * i + 2;
	}
}


auto spEval = [](cv2ref A, cv2ref B, cv2ref C, cv2ref D, const double &t)->vec2 {
	return (1 - t)*(1 - t)*((1 - t)*A + 3 * t*B) + t * t*(3 * (1 - t)*C + t * D);
};
void drawSpline(cv2ref A, cv2ref B, cv2ref C, cv2ref D, double t_min, double t_max, double width, COLORREF col) {
	// cubic Bezier, adaptive subdivision, screen coordinate

	if (t_min == 0 && t_max == 1) {		// entry
		vec2 P0 = A - 2 * B + C, P1 = A - 3 * B + 3 * C - D;
		double tx = P0.x / P1.x, ty = P0.y / P1.y; if (tx > ty) swap(tx, ty);	// inflection points
		if (tx > 0 && ty < 1) {
			drawSpline(A, B, C, D, 0, tx, width, col);
			drawSpline(A, B, C, D, tx, ty, width, col);
			drawSpline(A, B, C, D, ty, 1, width, col);
			return;
		}
		else if (tx > 0 && tx < 1) {
			drawSpline(A, B, C, D, 0, tx, width, col);
			drawSpline(A, B, C, D, tx, 1, width, col);
			return;
		}
		else if (ty > 0 && ty < 1) {
			drawSpline(A, B, C, D, 0, ty, width, col);
			drawSpline(A, B, C, D, ty, 1, width, col);
			return;
		}
	}

	// recursive
	vec2 P0 = spEval(A, B, C, D, t_min), P1 = spEval(A, B, C, D, t_max), P = spEval(A, B, C, D, 0.5*(t_min + t_max));
	double d = abs(det(P - P0, (P1 - P0).unitvec()));
	if (d < 1) {
		drawLine(imgC, cltC_w, cltC_h, P0.x, P0.y, P.x, P.y, width, col);
		drawLine(imgC, cltC_w, cltC_h, P.x, P.y, P1.x, P1.y, width, col);
	}
	else {
		drawSpline(A, B, C, D, t_min, 0.5*(t_min + t_max), width, col);
		drawSpline(A, B, C, D, 0.5*(t_min + t_max), t_max, width, col);
	}
}

void render_c() {
	HDC hdc = GetDC(HWndC);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImgC);
	Fill_N(imgC, cltC_w * cltC_h, _RGB(0, 0, 0));


	// axis and grid
	{
		double L = 100.0 / UnitC;	// side length of major gridlines
		double tp = pow(10, floor(log10(L)));
		L /= tp; L = (L < 2 ? 1 : L < 5 ? 2 : 5) * tp;
		double l = L / 5;	// side length of minor gridlines
		vec2 LeftTop = vec2(-0.5*cltC_w, 0.5*cltC_h) / UnitC, RightBottom = vec2(0.5*cltC_w, -0.5*cltC_h);
		LeftTop.x = round(LeftTop.x / l - 0.5), LeftTop.y = round(LeftTop.y / l + 0.5);
		RightBottom.x = round(RightBottom.x / l + 0.5), RightBottom.y = round(RightBottom.y / l - 0.5);

		// minor gridlines
		COLORREF col = mix(_RGB(0, 0, 0), _RGB(35, 45, 50), 0.4);
		for (double i = LeftTop.x; i <= RightBottom.x; i++) {
			vec2 P = vec2(i * l, 0) * UnitC + 0.5*vec2(cltC_w, cltC_h);
			int dr = round(P.x);
			if (dr >= 0 && dr < cltC_w) for (int i = 0; i < cltC_h; i++) {
				imgC[i*cltC_w + dr] = col;
			}
		}
		for (double i = LeftTop.y; i >= RightBottom.y; i--) {
			vec2 P = vec2(0, i * l) * UnitC + 0.5*vec2(cltC_w, cltC_h);
			int dr = round(P.y);
			if (dr >= 0 && dr < cltC_h) for (int i = 0; i < cltC_w; i++) {
				imgC[dr*cltC_w + i] = col;
			}
		}

		// major gridlines
		LeftTop.x = round(LeftTop.x / 5 - 0.5), LeftTop.y = round(LeftTop.y / 5 + 0.5);
		RightBottom.x = round(RightBottom.x / 5 + 0.5), RightBottom.y = round(RightBottom.y / 5 - 0.5);
		col = mix(_RGB(0, 0, 0), _RGB(55, 65, 75), 0.4);
		for (double i = LeftTop.x; i <= RightBottom.x; i++) {
			vec2 P = vec2(i * L, 0) * UnitC + 0.5*vec2(cltC_w, cltC_h);
			int dr = round(P.x);
			if (dr >= 0 && dr < cltC_w) for (int i = 0; i < cltC_h; i++) {
				imgC[i*cltC_w + dr] = col;
			}
		}
		for (double i = LeftTop.y; i >= RightBottom.y; i--) {
			vec2 P = vec2(0, i * L) * UnitC + 0.5*vec2(cltC_w, cltC_h);
			int dr = round(P.y);
			if (dr >= 0 && dr < cltC_h) for (int i = 0; i < cltC_w; i++) {
				imgC[dr*cltC_w + i] = col;
			}
		}

		// axis
		drawLine_p(imgC, cltC_w, cltC_h, 0.5 * cltC_w, 0, 0.5 * cltC_w, cltC_h, 0.5, _RGB(80, 75, 140));
		drawLine_p(imgC, cltC_w, cltC_h, 0, 0.5 * cltC_h, cltC_w, 0.5 * cltC_h, 0.5, _RGB(80, 75, 140));
		for (int i = ceil(-0.5*cltC_w / UnitC), end = floor(0.5*cltC_w / UnitC); i < end; i++)
			drawLine_p(imgC, cltC_w, cltC_h, i*UnitC + 0.5*cltC_w, 0.5*cltC_h + 0.03*UnitC, i*UnitC + 0.5*cltC_w, 0.5*cltC_h - 0.03*UnitC, 0.5, _RGB(80, 75, 140));
		for (int i = ceil(-0.5*cltC_h / UnitC), end = floor(0.5*cltC_h / UnitC); i < end; i++)
			drawLine_p(imgC, cltC_w, cltC_h, 0.5*cltC_w + 0.03*UnitC, i*UnitC + 0.5*cltC_h, 0.5*cltC_w - 0.03*UnitC, i*UnitC + 0.5*cltC_h, 0.8, _RGB(80, 75, 140));

	}


	// main figure
	for (int i = 0; i < CrossSec_Subsecs; i++) {
		seg2 *s1 = CSComps[i], *s2 = CSComps[i + 1];
		double t1 = s1->t, t2 = s2->t;

		vec2 A = (1 - t1)*s1->v1 + t1 * s1->v2, B = s1->v2, C = s2->v1, D = (1 - t2)*s2->v1 + t2 * s2->v2;
		A *= UnitC, B *= UnitC, C *= UnitC, D *= UnitC; vec2 P = 0.5*vec2(cltC_w, cltC_h); A += P, B += P, C += P, D += P;

		// spline
		drawSpline(A, B, C, D, 0, 1, 1.5, _RGB(255, 255, 255));

		// control line
		drawLine(imgC, cltC_w, cltC_h, s1->v1.x*UnitC + 0.5*cltC_w, s1->v1.y*UnitC + 0.5*cltC_h, s1->v2.x*UnitC + 0.5*cltC_w, s1->v2.y*UnitC + 0.5*cltC_h, 0.5, _RGB(0, 255, 0));

		// control points
		{
			auto drawHollowSquare = [](int x, int y) {
				for (int i = x - 2; i <= x + 2; i++)
					if (i >= 0 && i < cltC_w && y >= 2 && y < cltC_h - 2) imgC[(y - 2)*cltC_w + i] = imgC[(y + 2)*cltC_w + i] = _RGB(255, 0, 0);
				for (int i = y - 2; i <= y + 2; i++)
					if (i >= 0 && i < cltC_h && x >= 2 && x < cltC_w - 2) imgC[i*cltC_w + x - 2] = imgC[i*cltC_w + x + 2] = _RGB(255, 0, 0);
			};
			auto drawHollowCircle = [](double x, double y) {
				for (int i = floor(x - 3); i < ceil(x + 3); i++) for (int j = floor(y - 3); j < ceil(y + 3); j++) {
					if (i >= 0 && i < cltC_w && j >= 0 && j < cltC_h) {
						double sd = 1.0 - abs(sqrt((i - x)*(i - x) + (j - y)*(j - y)) - 2);
						if (sd > 1) imgC[j*cltC_w + i] = _RGB(255, 0, 0);
						else if (sd > 0) imgC[j*cltC_w + i] = mix(imgC[j*cltC_w + i], _RGB(255, 0, 0), sd);
					}
				}
			};
			drawHollowSquare(round(A.x), round(A.y));
			drawHollowCircle(s1->v1.x*UnitC + 0.5*cltC_w, s1->v1.y*UnitC + 0.5*cltC_h);
			drawHollowCircle(s1->v2.x*UnitC + 0.5*cltC_w, s1->v2.y*UnitC + 0.5*cltC_h);
		}
	}


	// selected/fitted control points
	{
		auto drawSolidSquare = [](int x, int y) {
			for (int i = x - 2; i <= x + 2; i++) for (int j = y - 2; j <= y + 2; j++)
				if (i >= 0 && i < cltC_w && j >= 0 && j < cltC_h) imgC[j*cltC_w + i] = _RGB(255, 255, 0);
		};
		auto drawSolidCircle = [](double x, double y) {
			for (int i = floor(x - 3); i < ceil(x + 3); i++) for (int j = floor(y - 3); j < ceil(y + 3); j++) {
				if (i >= 0 && i < cltC_w && j >= 0 && j < cltC_h) {
					double sd = 0.5 - (sqrt((i - x)*(i - x) + (j - y)*(j - y)) - 2.5);
					if (sd > 1) imgC[j*cltC_w + i] = _RGB(255, 255, 0);
					else if (sd > 0) imgC[j*cltC_w + i] = mix(imgC[j*cltC_w + i], _RGB(255, 255, 0), sd);
				}
			}
		};
		if (fitted_c != -1) {
			seg2* p = CSComps[fitted_c / 3];
			vec2 s = 0.5*vec2(cltC_w, cltC_h);
			if (fitted_c % 3 == 0) s += p->v1*UnitC, drawSolidCircle(s.x, s.y);
			else if (fitted_c % 3 == 1) s += p->v2*UnitC, drawSolidCircle(s.x, s.y);
			else if (fitted_c % 3 == 2) s += ((1 - p->t)*p->v1 + p->t*p->v2)*UnitC, drawSolidSquare(round(s.x), round(s.y));
		}
	}



	BitBlt(hdc, 0, 0, cltC_w, cltC_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);
}



#pragma endregion





#pragma region Rendering Axis Window

double UnitF = 300;

vec3 PosF(4, 4, 2.4), prevPosF;
void limitPosF() {
	double m = PosF.mod();
	const double MAX = 30, MIN = 0.5;
	if (m > MAX) PosF /= m / MAX;
	if (m < MIN) PosF /= m / MIN;
}

vec2 Cursor_F, prevCursor_F;

affine3 fromWorld_F;
void recalcMatrix_F() {
	fromWorld_F.init();
	fromWorld_F.translate(-PosF);
	double rz = atan2(-PosF.x, PosF.y), rx = atan2(hypot(PosF.x, PosF.y), -PosF.z);
	fromWorld_F.rotate_z(-rz); fromWorld_F.rotate_x(PI - rx); fromWorld_F.rotate_z(PI);
	fromWorld_F.translate(0, 0, 1);
	fromWorld_F.perspective(-1);
	fromWorld_F.scale(UnitF);
	fromWorld_F.translate(0.5*cltF_w, 0.5*cltF_h);
}

// view point control
vec2 VPC_C; const double VPC_R = 40;
bool VPC_SS = false;
vec3 VPC[6], *VPC_fitted = 0, *VPC_selected = 0;
void calc_VPC() {
	VPC_C = vec2(cltF_w - 50, cltF_h - 50);
	affine3 M = RotationMatrix_xz(PI - atan2(hypot(PosF.x, PosF.y), -PosF.z), atan2(PosF.x, PosF.y)); M.rotate_z(PI); M.perspective(-10); M.scale(0.75*VPC_R); M.translate(VPC_C);
	VPC[0] = M * vec3(1, 0, 0), VPC[1] = M * vec3(0, 1, 0), VPC[2] = M * vec3(0, 0, 1), VPC[3] = M * vec3(-1, 0, 0), VPC[4] = M * vec3(0, -1, 0), VPC[5] = M * vec3(0, 0, -1);
	if (!VPC_SS) VPC_fitted = 0;
	else if (!VPC_selected) {
		double min_dist = INFINITY; VPC_fitted = 0;
		for (int i = 0; i < 6; i++) {
			double dist = (vec2(VPC[i]) - Cursor_F).mod();
			if (dist < min_dist) min_dist = dist, VPC_fitted = &VPC[i];
		}
	}
}

// fitting and selecting (point)
int fitted_f = -1;
int selected_f = -1;
void fitpoint_f() {
	fitted_f = -1;
	double m, min_m = 20;
	for (int i = 0; i < Axis_CtrlPoints; i++) {
		m = ((fromWorld_F*AxisComps[i].p).xy() - Cursor_F).mod();
		if (m < min_m) min_m = m, fitted_f = i;
	}
}

// dragging point
vec3 DP[4], *DP_fitted = 0, *DP_selected = 0;	// 0: point;  1-3: x,y,z axis;
void calcDP() {
	nod3 *s = &AxisComps[selected_f];
	double m = 50 * (PosF - s->p).mod() / UnitF;
	DP[0] = fromWorld_F * s->p;
	DP[1] = fromWorld_F * (s->p + vec3(m, 0, 0)), DP[2] = fromWorld_F * (s->p + vec3(0, m, 0)), DP[3] = fromWorld_F * (s->p + vec3(0, 0, m));
}
void fitpoint_dp() {
	double dist, min_dist = 20; DP_fitted = 0;
	dist = (Cursor_F - DP[0].xy()).mod();
	if (dist < min_dist) min_dist = dist, DP_fitted = DP;
	for (int i = 1; i <= 3; i++) {
		vec2 v1 = (DP[i] - DP[0]).xy().unitvec(), v2 = Cursor_F - DP[0];
		double m = (DP[i] - DP[0]).xy().mod(), t = dot(v1, v2);
		dist = t < 0.2 * m ? v2.mod() : t > m ? (Cursor_F - DP[i]).mod() : abs(det(v1, v2));
		if (dist < min_dist) min_dist = dist, DP_fitted = DP + i;
	}
}



auto HermiteEval = [](cv3ref p1, cv3ref p2, cv3ref v1, cv3ref v2, double t)->vec3 {
	return ((2 * t - 3)*t*t + 1)*p1 + ((-2 * t + 3)*t*t)*p2 + (((t - 2)*t + 1)*t)*v1 + ((t - 1)*t*t)*v2;
};
auto HermiteT = [](cv3ref p1, cv3ref p2, cv3ref v1, cv3ref v2, double t)->vec3 {
	return ((6 * t - 6)*t)*p1 + ((-6 * t + 6)*t)*p2 + ((3 * t - 4)*t + 1)*v1 + ((3 * t - 2)*t)*v2;
};
void drawHermite(cv2ref A, cv2ref B, cv2ref C, cv2ref D, double t_min, double t_max, double width, COLORREF col) {
	if (t_min == 0 && t_max == 1) {		// entry
		vec2 P0 = A - 2 * B + C, P1 = A - 3 * B + 3 * C - D;
		double tx = P0.x / P1.x, ty = P0.y / P1.y; if (tx > ty) swap(tx, ty);	// inflection points
		if (tx > 0 && ty < 1) {
			drawHermite(A, B, C, D, 0, tx, width, col);
			drawHermite(A, B, C, D, tx, ty, width, col);
			drawHermite(A, B, C, D, ty, 1, width, col);
			return;
		}
		else if (tx > 0 && tx < 1) {
			drawHermite(A, B, C, D, 0, tx, width, col);
			drawHermite(A, B, C, D, tx, 1, width, col);
			return;
		}
		else if (ty > 0 && ty < 1) {
			drawHermite(A, B, C, D, 0, ty, width, col);
			drawHermite(A, B, C, D, ty, 1, width, col);
			return;
		}
	}

	// recursive
	vec2 P0 = HermiteEval(A, B, C, D, t_min), P1 = HermiteEval(A, B, C, D, t_max), P = HermiteEval(A, B, C, D, 0.5*(t_min + t_max));
	double d = abs(det(P - P0, (P1 - P0).unitvec()));
	if (d < 1) {
		drawLine(imgC, cltC_w, cltC_h, P0.x, P0.y, P.x, P.y, width, col);
		drawLine(imgC, cltC_w, cltC_h, P.x, P.y, P1.x, P1.y, width, col);
	}
	else {
		drawHermite(A, B, C, D, t_min, 0.5*(t_min + t_max), width, col);
		drawHermite(A, B, C, D, 0.5*(t_min + t_max), t_max, width, col);
	}
}


#include "Ray Casting/RC_Cone.h"
void render_f() {
	HDC hdc = GetDC(HWndF);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImgF);

	recalcMatrix_F();
	Fill_N(imgF, cltF_w*cltF_h, 0);

	mat3 M = RotationMatrix_zx(atan2(-PosF.x, PosF.y), atan2(hypot(PosF.x, PosF.y), -PosF.z));
	vec3 O = M * vec3(0.5*cltF_w / UnitF, -0.5*cltF_h / UnitF, 1), A = M * vec3(-cltF_w / UnitF, 0), B = M * vec3(0, cltF_h / UnitF), P;


	// Axis and Grid
	{
		// horizon
		double k = -O.z / B.z;

		// vanishing points
		vec2 _00 = fromWorld_F * vec3(0, 0), _10 = fromWorld_F * vec3(1, 0), _01 = fromWorld_F * vec3(0, 1), _11 = fromWorld_F * vec3(1, 1);
		vec2 vx = _00 + (det(_01 - _00, _01 - _11) / det(_10 - _00, _01 - _11)) * (_10 - _00), vy = _00 + (det(_10 - _00, _11 - _10) / det(_01 - _00, _11 - _10)) * (_01 - _00);

		// grid
		{
			double t00, t10, t01, t11;
			if (k > 1 || k < 0) t00 = -PosF.z / O.z, t10 = -PosF.z / (O.z + A.z), t01 = -PosF.z / (O.z + B.z), t11 = -PosF.z / (O.z + A.z + B.z);
			else if (k > 0.5) k = 0.5 + 0.99*(k - 0.5), t00 = -PosF.z / O.z, t10 = -PosF.z / (O.z + A.z), t01 = -PosF.z / (O.z + k * B.z), t11 = -PosF.z / (O.z + A.z + k * B.z);
			else k = 0.5 - 0.99*(0.5 - k), t00 = -PosF.z / (O.z + k * B.z), t10 = -PosF.z / (O.z + A.z + k * B.z), t01 = -PosF.z / (O.z + B.z), t11 = -PosF.z / (O.z + A.z + B.z);
			vec2 v00 = PosF + t00 * O, v10 = PosF + t10 * (O + A), v01 = PosF + t01 * (O + B), v11 = PosF + t11 * (O + A + B);
			auto fr = [](vec2 &v) { if (v.x > 500) v.x = 500; if (v.x < -500) v.x = -500; if (v.y > 500) v.y = 500; if (v.y < -500) v.y = -500; };
			fr(v00), fr(v10), fr(v01), fr(v11);

			auto drawGrid = [](vec2 v00, vec2 v10, vec2 v01, vec2 v11, vec2 vx, vec2 vy, double k, double size, double width, double edge, double limit, COLORREF col) {
				if (PosF.mod() >= limit) return;
				auto fr = [](vec2 &v, double size) { v.x = int(v.x / size) * size, v.y = int(v.y / size) * size; };
				fr(v00, size), fr(v10, size), fr(v01, size), fr(v11, size);
				col = mix(col, 0, PosF.mod() / limit);
				for (double i = max(min(min(v00.x, v01.x), min(v10.x, v11.x)), -edge), m = min(max(max(v00.x, v01.x), max(v10.x, v11.x)), edge); i <= m; i += size) {
					vec2 p = fromWorld_F * vec3(i, 0);
					if ((k > 0.5 ? p.y < k*cltF_h : p.y > k*cltF_h) && abs(i) > 1e-6) {
						p = 100 * (p - vy) + vy;
						drawLine(imgF, cltF_w, cltF_h, vy.x, vy.y, p.x, p.y, width, col);
					}
				}
				for (double i = max(min(min(v00.y, v01.y), min(v10.y, v11.y)), -edge), m = min(max(max(v00.y, v01.y), max(v10.y, v11.y)), edge); i <= m; i += size) {
					vec2 p = fromWorld_F * vec3(0, i);
					if ((k > 0.5 ? p.y < k*cltF_h : p.y > k*cltF_h) && abs(i) > 1e-6) {
						p = 100 * (p - vx) + vx;
						drawLine(imgF, cltF_w, cltF_h, vx.x, vx.y, p.x, p.y, width, col);
					}
				}
			};

			drawGrid(v00, v10, v01, v11, vx, vy, k, 0.1, 1, 10, 12, _RGB(64, 64, 64));
			drawGrid(v00, v10, v01, v11, vx, vy, k, 1, 1, 40, 85, _RGB(64, 64, 64));
			drawGrid(v00, v10, v01, v11, vx, vy, k, 10, 1, 100, 200, _RGB(64, 64, 64));

		}

		// axis
		{
			const double s = 100, b = 1e+6 * s;
			vec3 O = fromWorld_F * vec3(0, 0, 0);
			drawLine(imgF, cltF_w, cltF_h, vx.x, vx.y, (O.x - vx.x) * 1000 + vx.x, (O.y - vx.y) * 1000 + vx.y, 1.2, _RGB(255, 20, 40));
			drawLine(imgF, cltF_w, cltF_h, vy.x, vy.y, (O.x - vy.x) * 1000 + vy.x, (O.y - vy.y) * 1000 + vy.y, 1.2, _RGB(40, 140, 0));
		}

		// ray damping
		for (int j = 0; j < cltF_h; j++) {
			double t = -PosF.z / (O + 0.5 * A + (double(j) / cltF_h) * B).unitvec().z;
			if (t < 0) t = 1;
			else t = 1 - exp(-t / PosF.mod());
			for (int i = 0; i < cltF_w; i++) imgF[j*cltF_w + i] = mix(imgF[j*cltF_w + i], _RGB(0, 0, 0), t);
		}

	}


	// Cross Section
	{
		const int N = 10;
		for (int d = 0; d < CrossSec_Subsecs; d++) {
			seg2 *s1 = CSComps[d], *s2 = CSComps[d + 1]; double t1 = s1->t, t2 = s2->t;
			vec2 A = (1 - t1)*s1->v1 + t1 * s1->v2, B = s1->v2, C = s2->v1, D = (1 - t2)*s2->v1 + t2 * s2->v2;
			vec3 v1, v2 = fromWorld_F * vec3(A);
			for (int i = 1; i <= N; i++) {
				v1 = v2, v2 = fromWorld_F * vec3(spEval(A, B, C, D, i / double(N)));
				if (i & 1 && v1.z > -UnitF && v2.z > -UnitF) drawLine(imgF, cltF_w, cltF_h, v1.x, v1.y, v2.x, v2.y, 1, _RGB(255, 255, 255));
			}
		}
	}


	// Swept Axis
	const int N = 10;
	for (int d = 0; d < Axis_CtrlPoints; d++) {
		nod3 *s = &AxisComps[d], *s_ = &AxisComps[d + 1];

		// spline
		if (d + 1 != Axis_CtrlPoints) for (int i = 0; i < N; i++) {
			vec3 v1 = HermiteEval(s->p, s_->p, s->d, s_->d, i / double(N));
			vec3 v2 = HermiteEval(s->p, s_->p, s->d, s_->d, (i + 1) / double(N));
			vec3 V1 = fromWorld_F * v1, V2 = fromWorld_F * v2;
			COLORREF col = i & 1 ? _RGB(255, 128, 128) : _RGB(128, 255, 128); if ((v1.z + v2.z > 0) ^ (PosF.z > 0)) col = mix(col, 0, 0.75);
			if (V1.z > -UnitF && V2.z > -UnitF) drawLine(imgF, cltF_w, cltF_h, V1.x, V1.y, V2.x, V2.y, 1, col);
		}


		// vector arrow
		vec3 p = fromWorld_F * s->p, q = fromWorld_F * (s->p + s->d);
		if (p.z > -UnitF) {
			// node, draw a circle defined by sdf
			for (int i = floor(p.x - 5); i < ceil(p.x + 5); i++) for (int j = floor(p.y - 5); j < ceil(p.y + 5); j++) {
				if (i >= 0 && i < cltF_w && j >= 0 && j < cltF_h) {
					double sd = sqrt((i - p.x)*(i - p.x) + (j - p.y)*(j - p.y)) - 3;
					if (d == fitted_f || d == selected_f) {
						sd = (d == selected_f ? 1.0 : 0.2) - sd; if (DP_fitted == DP) sd++;
						if (sd > 0) imgF[j*cltF_w + i] = mix(imgF[j*cltF_w + i], DP_fitted == DP ? _RGB(255, 255, 0) : _RGB(20, 100, 200), sd > 1 ? 1 : sd);
					}
					else {
						sd = 1 - abs(sd + 1);
						if (sd > 0) imgF[j*cltF_w + i] = mix(imgF[j*cltF_w + i], _RGB(200, 120, 20), sd > 1 ? 1 : sd);
					}
				}
			}

			// axis shown when point is selected
			if (d == selected_f) {
				double m = 50 * (PosF - s->p).mod() / UnitF;
				auto drawAxis = [](cv3ref O, cv3ref A, cv3ref B, vec3 beg, vec3 end, double th, COLORREF col)
				{
					// stick
					vec3 C = fromWorld_F * beg, P = fromWorld_F * end;
					drawLine(imgF, cltF_w, cltF_h, Lerp(C.x, P.x, 0.15), Lerp(C.y, P.y, 0.15), P.x, P.y, th, col);

					// ray-casted cone
					double L = 5 * th, R = 1.8 * th;
					double sc = (PosF - end).mod() / UnitF;
					RT_Cone Co(end + L * sc * (end - beg).unitvec(), end, R*sc);
					for (int i = -++L; i <= L; i++) for (int j = -L; j <= L; j++) {
						double Y = P.y - j, X = P.x - i; int y = round(Y), x = round(X);
						vec3 NUL;
						if (y >= 0 && y < cltF_h && x >= 0 && x < cltF_w) {
							double alpha = 0;
							for (int u = 0; u < 2; u++) for (int v = 0; v < 2; v++) {
								if (Co.intersect(PosF, O + (X + 0.5*u) / cltF_w * A + (Y + 0.5*v) / cltF_h * B, NUL.x, NUL)) alpha += 1. / 4;
							}
							imgF[y*cltF_w + x] = mix(imgF[y*cltF_w + x], col, alpha);
						}
					}
				};
				drawAxis(O, A, B, s->p, s->p + vec3(m, 0, 0), DP_fitted - DP == 1 ? 2.4 : 2, DP_fitted - DP == 1 ? _RGB(255, 128, 128) : _RGB(255, 0, 0));
				drawAxis(O, A, B, s->p, s->p + vec3(0, m, 0), DP_fitted - DP == 2 ? 2.4 : 2, DP_fitted - DP == 2 ? _RGB(128, 255, 128) : _RGB(0, 128, 0));
				drawAxis(O, A, B, s->p, s->p + vec3(0, 0, m), DP_fitted - DP == 3 ? 2.4 : 2, DP_fitted - DP == 3 ? _RGB(128, 128, 255) : _RGB(0, 0, 255));
			}

			// arrow point, now shown when behind viewpoint
			if ((d == fitted_f || d == selected_f) && q.z > -UnitF) {
				COLORREF col = d == fitted_f ? _RGB(20, 100, 200) : _RGB(240, 140, 20);

				// stick
				drawLine(imgF, cltF_w, cltF_h, p.x, p.y, q.x, q.y, d == selected_f ? 2 : 1.2, col);

				// cone, ray casting
				double L = d == fitted_f ? 10 : 12.5, R = d == fitted_f ? 3 : 4;
				double sc = (PosF - (s->p + s->d)).mod() / UnitF; L *= sc, R *= sc;
				RT_Cone C(s->p + s->d + L * s->d.unitvec(), s->p + s->d, R);
				for (int i = -13; i < 13; i++) for (int j = -13; j < 13; j++) {
					double Y = q.y - j, X = q.x - i; int y = round(Y), x = round(X);
					vec3 NUL;
					if (y >= 0 && y < cltF_h && x >= 0 && x < cltF_w) {
						//imgF[y*cltF_w + x] = mix(imgF[y*cltF_w + x], _RGB(255, 0, 0), 0.2);
						double alpha = 0;
						for (int u = 0; u < 2; u++) for (int v = 0; v < 2; v++) {
							if (C.intersect(PosF, O + (X + 0.5*u) / cltF_w * A + (Y + 0.5*v) / cltF_h * B, NUL.x, NUL)) alpha += 1. / 4;
						}
						imgF[y*cltF_w + x] = mix(imgF[y*cltF_w + x], col, alpha);
					}
				}
			}
		}
	}




	// Viewpoint Controller
	{
		const double r = 0.17*VPC_R;
		int xb = VPC_C.x - VPC_R, yb = VPC_C.y - VPC_R, xe = VPC_C.x + VPC_R + 0.5, ye = VPC_C.y + VPC_R + 0.5;

		// outer circle
		if (VPC_SS) for (int i = xb; i <= xe; i++) for (int j = yb; j <= ye; j++) {
			double sd = (VPC_C - vec2(i, j)).mod() - VPC_R;
			sd = 0.5 - sd; if (sd > 1) sd = 1; sd *= 0.15;
			if (sd > 0) imgF[j*cltF_w + i] = mix(imgF[j*cltF_w + i], _RGB(192, 192, 192), sd);
		}

		// controller, painter's algo
		calc_VPC();
		const COLORREF selected_col = _RGB(255, 255, 255), x_col = _RGB(255, 20, 40), y_col = _RGB(80, 220, 0), z_col = _RGB(30, 100, 255);
		vec3 fitted = VPC_fitted ? *VPC_fitted : vec3(NAN, NAN, NAN);
		int ps[6] = { 0, 1, 2, 3, 4, 5 };
		for (int i = 0; i < 6; i++) for (int j = 0; j < i; j++) if (VPC[ps[i]].z < VPC[ps[j]].z) swap(ps[i], ps[j]);
		vec3 ep[3]; for (int i = 0; i < 3; i++) ep[i] = VPC[i] + (0.17 / 0.75)*(VPC_C - VPC[i]);
		auto drawCircle = [](vec2 c, double r, COLORREF col, double alpha) {
			for (int x = c.x - r - 0.5, x_max = c.x + r + 1; x < x_max; x++) {
				for (int y = c.y - r - 0.5, y_max = c.y + r + 1; y < y_max; y++) {
					if (x >= 0 && y >= 0 && x < cltF_w && y < cltF_h) {		// sometimes overflow when minimized
						double sd = (c - vec2(x, y)).mod() - r;
						sd = 0.5 - sd;
						if (sd > 1) imgF[y*cltF_w + x] = mix(imgF[y*cltF_w + x], col, alpha);
						else if (sd > 0) imgF[y*cltF_w + x] = mix(imgF[y*cltF_w + x], col, sd * alpha);
					}
				}
			}
		};

		bool x_d, y_d, z_d = y_d = x_d = false;
		for (int i = 0; i < 6; i++) {
			switch (ps[i]) {
			case 0:	// x
				drawLine(imgF, cltF_w, cltF_h, VPC_C.x, VPC_C.y, ep[0].x, ep[0].y, x_d ? 2 : 1, VPC_fitted == &VPC[0] ? selected_col : x_col);
				drawCircle(VPC[0], r, VPC_fitted == &VPC[0] ? selected_col : x_col, x_d || VPC_fitted == &VPC[0] ? 1 : 0.5);
				drawLine(imgF, cltF_w, cltF_h, VPC[0].x - 0.35*r, VPC[0].y + 0.5*r, VPC[0].x + 0.35*r, VPC[0].y - 0.5*r, 0.8, _RGB(0, 0, 0)), \
					drawLine(imgF, cltF_w, cltF_h, VPC[0].x + 0.35*r, VPC[0].y + 0.5*r, VPC[0].x - 0.35*r, VPC[0].y - 0.5*r, 0.8, _RGB(0, 0, 0));		// X symbol
				x_d = true; break;
			case 1:	// y
				drawLine(imgF, cltF_w, cltF_h, VPC_C.x, VPC_C.y, ep[1].x, ep[1].y, y_d ? 2 : 1, VPC_fitted == &VPC[1] ? selected_col : y_col);
				drawCircle(VPC[1], r, VPC_fitted == &VPC[1] ? selected_col : y_col, y_d || VPC_fitted == &VPC[1] ? 1 : 0.5);
				drawLine(imgF, cltF_w, cltF_h, VPC[1].x - 0.35*r, VPC[1].y + 0.5*r, VPC[1].x, VPC[1].y - 0.15*r, 0.8, _RGB(0, 0, 0)), \
					drawLine(imgF, cltF_w, cltF_h, VPC[1].x + 0.35*r, VPC[1].y + 0.5*r, VPC[1].x, VPC[1].y - 0.15*r, 0.8, _RGB(0, 0, 0)), \
					drawLine(imgF, cltF_w, cltF_h, VPC[1].x, VPC[1].y - 0.15*r, VPC[1].x, VPC[1].y - 0.6*r, 0.8, _RGB(0, 0, 0));		// Y symbol
				y_d = true; break;
			case 2:	// z
				drawLine(imgF, cltF_w, cltF_h, VPC_C.x, VPC_C.y, ep[2].x, ep[2].y, z_d ? 2 : 1, VPC_fitted == &VPC[2] ? selected_col : z_col);
				drawCircle(VPC[2], r, VPC_fitted == &VPC[2] ? selected_col : z_col, z_d || VPC_fitted == &VPC[2] ? 1 : 0.5);
				drawLine(imgF, cltF_w, cltF_h, VPC[2].x - 0.4*r, VPC[2].y + 0.45*r, VPC[2].x + 0.4*r, VPC[2].y + 0.45*r, 0.8, _RGB(0, 0, 0)), \
					drawLine(imgF, cltF_w, cltF_h, VPC[2].x + 0.4*r, VPC[2].y + 0.45*r, VPC[2].x - 0.4*r, VPC[2].y - 0.45*r, 0.8, _RGB(0, 0, 0)), \
					drawLine(imgF, cltF_w, cltF_h, VPC[2].x - 0.4*r, VPC[2].y - 0.45*r, VPC[2].x + 0.4*r, VPC[2].y - 0.45*r, 0.8, _RGB(0, 0, 0));	// Z symbol
				z_d = true; break;
			case 3:	// -x
				drawCircle(VPC[3], 0.8 * r, VPC_fitted == &VPC[3] ? selected_col : x_col, x_d || VPC_fitted == &VPC[3] ? 1 : 0.5);
				x_d = true; break;
			case 4:	// -y
				drawCircle(VPC[4], 0.8 * r, VPC_fitted == &VPC[4] ? selected_col : y_col, y_d || VPC_fitted == &VPC[4] ? 1 : 0.5);
				y_d = true; break;
			case 5:	// -z
				drawCircle(VPC[5], 0.8 * r, VPC_fitted == &VPC[5] ? selected_col : z_col, z_d || VPC_fitted == &VPC[5] ? 1 : 0.5);
				z_d = true; break;
			}
		}


	}


	//saveBitmap(imgF, cltF_w, cltF_h, "C:\\Users\\harry\\Desktop\\Test\\Debug.bmp"); exit(0);



	BitBlt(hdc, 0, 0, cltF_w, cltF_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);
}



#pragma endregion




#pragma region 3D Rendering


const vec3 light = vec3(0.6, 0.5, 1).unitvec();
const COLORf bkg_col = RGBf(0.05, 0.1, 0.15);

bool Ctrl = false, Shift = false, Alt = false;


vec3 Pos(7.4, 3.6, 2.4), prevPos(Pos);
double Unit3D = 700, img_Unit3D = AA * Unit3D;


affine3 fromWorld, fromScreen;
void recalcMatrix() {
	fromWorld.init();
	fromWorld.translate(-Pos);
	fromWorld.rotate_z(atan2(Pos.x, Pos.y)); fromWorld.rotate_x(PI - atan2(hypot(Pos.x, Pos.y), -Pos.z)); fromWorld.rotate_z(PI);
	fromWorld.translate(0, 0, 1);
	fromWorld.perspective(-1);
	fromWorld.scale(img_Unit3D);
	fromWorld.translate(img_w / 2, img_h / 2);
	fromScreen = fromWorld.invert();
}



void render3D() {
	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HIMG);
	Fill_N(img_base, img_w * img_h, _RGB(0, 0, 0));

	if (ZB == 0) ZB = new double[img_w*img_h];
	Fill_N(ZB, img_w*img_h, -INFINITY);

	recalcMatrix();


	double min_z = -img_Unit3D, max_z = 100 * img_Unit3D;

	auto surfEval = [](double u, double v)->vec3 {	// u: cross section (0 - CrossSec_Subsecs); v: axis (0 - Axis_CtrlPoints-1)
		if (u > CrossSec_Subsecs) u = CrossSec_Subsecs - 1e-6;
		if (v > Axis_CtrlPoints - 1) v = Axis_CtrlPoints - 1 - 1e-6;
		int n = (int)v; v -= n; nod3 *p = &AxisComps[n], *q = p + 1;
		vec3 P = HermiteEval(p->p, q->p, p->d, q->d, v), T = HermiteT(p->p, q->p, p->d, q->d, v);
		mat3 R = RotationMatrix_zx(atan2(T.x, -T.y), atan2(hypot(T.x, T.y), T.z));
		n = (int)u; u -= n; seg2 *s1 = CSComps[n], *s2 = CSComps[n + 1]; double t1 = s1->t, t2 = s2->t;
		return R * vec3(spEval((1 - t1)*s1->v1 + t1 * s1->v2, s1->v2, s2->v1, (1 - t2)*s2->v1 + t2 * s2->v2, u)) + P;
	};

	auto calc_col = [](const COLORf &Col, vec3 n, vec3 v) -> COLORf {
		const double Kd = 0.4, Ks = 1 - Kd, N = 5;
		n /= n.mod(), v /= v.mod();
		if (dot(n, v) > 0) n = -n;
		double a = dot(light, n);
		double amb = 0.5 - 0.5*n.x;
		double dif = Kd * max(a, 0.0);
		double spc = Ks * pow(max(-dot(2 * a*n - light, v), 0.0), N);
		return amb * bkg_col + (dif + spc) * Col;
	};

	const double step = 0.05;
	for (double u = 0; u < CrossSec_Subsecs; u += step) {
		for (double v = 0; v < Axis_CtrlPoints - 1; v += step) {
			vec3 p = surfEval(u, v), P = fromWorld * p;
			vec3 px = surfEval(u + step, v), Px = fromWorld * px;
			vec3 py = surfEval(u, v + step), Py = fromWorld * py;
			vec3 pxy = surfEval(u + step, v + step), Pxy = fromWorld * pxy;
			triangle T(P, Px, Py);
			COLORf col = calc_col(RGBf(255, 250, 238) / 256, T.n, T.A - PosF);
			fillTrigInZBuffer(img_base, img_w, img_h, ZB, T, toCOLORREF(col));
			T = triangle(Px, Py, Pxy);
			col = calc_col(RGBf(255, 250, 238) / 256, T.n, T.A - PosF);
			fillTrigInZBuffer(img_base, img_w, img_h, ZB, T, toCOLORREF(col));
		}
	}



	vec3 O = fromWorld * vec3(0, 0, 0), I = fromWorld * vec3(1, 0, 0), J = fromWorld * vec3(0, 1, 0), K = fromWorld * vec3(0, 0, 1);
	drawLine(img_base, img_w, img_h, O.x, O.y, I.x, I.y, 1, _RGB(255, 0, 0));
	drawLine(img_base, img_w, img_h, O.x, O.y, J.x, J.y, 1, _RGB(0, 255, 0));
	drawLine(img_base, img_w, img_h, O.x, O.y, K.x, K.y, 1, _RGB(0, 0, 255));


	COLORf col;
	for (int j = 0; j < clt_h; j++) for (int i = 0; i < clt_w; i++) {
		col.r = col.g = col.b = 0;
		for (int u = 0; u < AA; u++) for (int v = 0; v < AA; v++) {
			col += toCOLORf(img_base[(AA*j + u)*img_w + (AA*i + v)]);
		}
		col /= AA * AA;
		img[j*clt_w + i] = toCOLORREF(col);
	}




	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);

}

bool mouse_down = false;
vec2 Cursor, prevCursor;


#pragma endregion










LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {

	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, int w, int h, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)h : (long)h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};

	switch (message) {	// key actions, apply to all windows
	case WM_KEYDOWN: {
		switch (wParam) {
		case VK_SHIFT: { Shift = true; break; }
		case VK_CONTROL: { Ctrl = true; break; }
		}
		break;
	}
	case WM_KEYUP: {
		switch (wParam) {
		case VK_SHIFT: { Shift = false; break; }
		case VK_CONTROL: { Ctrl = false; break; }
		}
		break;
	}
	}

	if (hWnd == HWnd) {
		switch (message) {
#pragma region Window
		case WM_CREATE: {
			RECT Client; GetClientRect(hWnd, &Client);
			clt_w = Client.right, clt_h = Client.bottom;
			break;
		}
		case WM_MOVE:;
		case WM_SIZE: {
			RECT Client; GetClientRect(hWnd, &Client);
			if (Client.right*Client.bottom == 0) break;
			double prev_w = clt_w, prev_h = clt_h;
			clt_w = Client.right, clt_h = Client.bottom;
			img_w = AA * clt_w, img_h = AA * clt_h;
			if (ZB != 0) delete ZB, ZB = new double[img_w*img_h];
			delete img_base; img_base = new COLORREF[img_w*img_h];
			if (prev_w * prev_h != 0) Unit3D *= sqrt((clt_w * clt_h) / (prev_w * prev_h));
			img_Unit3D = AA * Unit3D;
			DeleteObject(HIMG);
			InitializeClientBitmap(hWnd, HIMG, img, clt_w, clt_h, false);
			render3D();

			// Test the speed of different rendering methods
			auto Test = [](unsigned N) {
				auto t0 = NTime::now();
				for (int i = 0; i < N; i++) render3D();
				auto t1 = NTime::now();
				fsec fs = t1 - t0;
				dout("\n" << (N / fs.count()) << "fps\n\n");
			};
			//Test(50); exit(0);

			break;
		}
		case WM_GETMINMAXINFO: {
			LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
			lpMMI->ptMinTrackSize.x = 600, lpMMI->ptMinTrackSize.y = 400;
			break;
		}
		case WM_PAINT: {
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd, &ps);
			HDC HMem = CreateCompatibleDC(hdc);
			HBITMAP hbmOld = (HBITMAP)SelectObject(HMem, HIMG);
			BitBlt(hdc, 0, 0, clt_w, clt_h, HMem, 0, 0, SRCCOPY);
			SelectObject(HMem, hbmOld);
			EndPaint(hWnd, &ps);
			DeleteDC(HMem);
			DeleteDC(hdc);
			break;
		}
		case WM_CLOSE: {
			DestroyWindow(hWnd);
			destruct();
			return 0;
		}
		case WM_DESTROY: {
			PostQuitMessage(0);
			return 0;
		}
#pragma endregion
#pragma region User
		case WM_MOUSEMOVE: {
			Cursor.x = GET_X_LPARAM(lParam);
			Cursor.y = clt_h - GET_Y_LPARAM(lParam);
			if (mouse_down) {
				vec2 dC = 5 * (prevCursor - Cursor) / Unit3D;
				Pos = RotationMatrix_z(dC.x) * prevPos;
				double a = acos(Pos.unitvec().z);
				if (a - dC.y < 1e-6) dC.y = a - 1e-6;
				if (a - dC.y > 3.14159) dC.y = a - 3.14159;
				Pos = RotationMatrix(cross(Pos, vec3(0, 0, 1)), dC.y) * Pos;
			}
			render3D();
			break;
		}
		case WM_MOUSEWHEEL: {
			int delta = GET_WHEEL_DELTA_WPARAM(wParam);
			Pos /= exp(0.0008 * delta);
			render3D();
			break;
		}
		case WM_SYSKEYDOWN:;
		case WM_KEYDOWN: {
			break;
		}
		case WM_KEYUP: {
			break;
		}
		case WM_LBUTTONDOWN: {
			mouse_down = true;
			SetCapture(hWnd);
			prevCursor = Cursor, prevPos = Pos;
			render3D();
			break;
		}
		case WM_LBUTTONUP: {
			ReleaseCapture();
			mouse_down = false;
			render3D();
			break;
		}
#pragma endregion
		}
		return DefWindowProc(hWnd, message, wParam, lParam);
	}

	if (hWnd == HWndC) {
		switch (message) {
#pragma region Window
		case WM_CREATE: {
			RECT Client; GetClientRect(hWnd, &Client);
			cltC_w = Client.right, cltC_h = Client.bottom;
			break;
		}
		case WM_MOVE:;
		case WM_SIZE: {
			RECT Client; GetClientRect(hWnd, &Client);
			if (Client.right*Client.bottom == 0) break;
			double prev_w = cltC_w, prev_h = cltC_h;
			cltC_w = Client.right, cltC_h = Client.bottom;
			if (prev_w*prev_h == 0) break;
			UnitC *= sqrt((cltC_w * cltC_h) / (prev_w * prev_h));
			DeleteObject(HImgC);
			InitializeClientBitmap(hWnd, HImgC, imgC, cltC_w, cltC_h, false);
			SendMessage(hWnd, WM_MOUSEWHEEL, 0, 0);
			break;
		}
		case WM_GETMINMAXINFO: {
			LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
			lpMMI->ptMinTrackSize.x = 300, lpMMI->ptMinTrackSize.y = 300;
			lpMMI->ptMaxTrackSize.x = 600, lpMMI->ptMaxTrackSize.y = 400;
			break;
		}
		case WM_PAINT: {
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd, &ps);
			HDC HMem = CreateCompatibleDC(hdc);
			HBITMAP hbmOld = (HBITMAP)SelectObject(HMem, HImgC);
			BitBlt(hdc, 0, 0, cltC_w, cltC_h, HMem, 0, 0, SRCCOPY);
			SelectObject(HMem, hbmOld);
			EndPaint(hWnd, &ps);
			DeleteDC(HMem);
			DeleteDC(hdc);
			break;
		}
		case WM_CLOSE: {
			return 0;
		}
		case WM_DESTROY: {
			return 0;
		}
#pragma endregion
#pragma region User
		case WM_MOUSEMOVE: {
			Cursor_C.x = GET_X_LPARAM(lParam);
			Cursor_C.y = cltC_h - GET_Y_LPARAM(lParam);
			if (selected_c == -1) fitpoint_c();
			else {
				seg2 *p = CSComps[selected_c / 3];
				vec2 s = (Cursor_C - 0.5*vec2(cltC_w, cltC_h)) / UnitC;
				if (selected_c % 3 == 2) {
					p->t = dot(s - p->v1, p->v2 - p->v1) / (p->v2 - p->v1).sqr();
					if (p->t < 0) p->t = 0; if (p->t > 1) p->t = 1;
				}
				else if (selected_c % 3 == 0) p->v1 = s;
				else if (selected_c % 3 == 1) p->v2 = s;
				render_f();
				render3D();
			}
			render_c();
			break;
		}
		case WM_MOUSEWHEEL: {
			int delta = GET_WHEEL_DELTA_WPARAM(wParam);
			const double MAX = 1000, MIN = 20;
			double d = exp(0.0008 * delta);
			if (UnitC * d > MAX) d = MAX / UnitC;
			else if (UnitC * d < MIN) d = MIN / UnitC;
			UnitC *= d;
			render_c();
			break;
		}
		case WM_LBUTTONDOWN: {
			if (selected_c != -1) selected_c = -1;
			else if (fitted_c != -1) selected_c = fitted_c;
			render_c();
			break;
		}
#pragma endregion
		}
		return DefWindowProc(hWnd, message, wParam, lParam);
	}

	if (hWnd == HWndF) {
		switch (message) {
#pragma region Window
		case WM_CREATE: {
			RECT Client; GetClientRect(hWnd, &Client);
			cltF_w = Client.right, cltF_h = Client.bottom;
			break;
		}
		case WM_MOVE:;
		case WM_SIZE: {
			RECT Client; GetClientRect(hWnd, &Client);
			//if (Client.right*Client.bottom == 0) break;
			double prev_w = cltF_w, prev_h = cltF_h;
			cltF_w = Client.right, cltF_h = Client.bottom;
			if (prev_w*prev_h != 0) UnitF *= sqrt((cltF_w * cltF_h) / (prev_w * prev_h));
			DeleteObject(HImgF);
			InitializeClientBitmap(hWnd, HImgF, imgF, cltF_w, cltF_h, false);

			// view point controller
			calc_VPC();

			render_f();
			break;
		}
		case WM_GETMINMAXINFO: {
			LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
			lpMMI->ptMinTrackSize.x = 300, lpMMI->ptMinTrackSize.y = 300;
			lpMMI->ptMaxTrackSize.x = 800, lpMMI->ptMaxTrackSize.y = 600;
			break;
		}
		case WM_PAINT: {
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd, &ps);
			HDC HMem = CreateCompatibleDC(hdc);
			HBITMAP hbmOld = (HBITMAP)SelectObject(HMem, HImgF);
			BitBlt(hdc, 0, 0, cltF_w, cltF_h, HMem, 0, 0, SRCCOPY);
			SelectObject(HMem, hbmOld);
			EndPaint(hWnd, &ps);
			DeleteDC(HMem);
			DeleteDC(hdc);
			break;
		}
		case WM_CLOSE: {
			exit(0);
			return 0;
		}
		case WM_DESTROY: {
			return 0;
		}
#pragma endregion
#pragma region User
		case WM_MOUSEMOVE: {
			Cursor_F.x = GET_X_LPARAM(lParam);
			Cursor_F.y = cltF_h - GET_Y_LPARAM(lParam);

			VPC_SS = VPC_selected || (Cursor_F - VPC_C).mod() < VPC_R;
			calc_VPC();
			if (VPC_selected) {
				// This cheating method works pretty well
				vec2 dC = 0.02 * (prevCursor_F - Cursor_F);
				PosF = RotationMatrix_z(dC.x) * prevPosF;
				double a = acos(PosF.unitvec().z);
				if (a - dC.y < 0.001) dC.y = a - 0.001;
				if (a - dC.y > 3.141) dC.y = a - 3.141;
				PosF = RotationMatrix(cross(PosF, vec3(0, 0, 1)), dC.y) * PosF;
				render_f(); break;
			}

			if (selected_f == -1) fitpoint_f();

			if (selected_f != -1 && !DP_selected) calcDP(), fitpoint_dp();


			render_f();
			break;
		}
		case WM_MOUSEWHEEL: {
			if (VPC_SS) break;
			int delta = GET_WHEEL_DELTA_WPARAM(wParam);
			double m = PosF.mod();
			if (Ctrl) {		// vertically movement
				double d = 0.0002 * delta * m;
				PosF.z += d;
			}
			else if (Shift) {	// rotation around z-axis
				double d = 0.0008 * delta;
				PosF = RotationMatrix_z(d) * PosF;
			}
			else {	// zoom
				double d = exp(0.0008 * delta);
				PosF /= d;
			}
			limitPosF();
			calcDP();
			render_f();
			break;
		}
		case WM_LBUTTONDOWN: {
			calc_VPC();
			if (VPC_fitted != 0) VPC_selected = VPC_fitted, VPC_fitted = 0;
			prevCursor_F = Cursor_F, prevPosF = PosF;
			SetCapture(hWnd);
			if (VPC_SS) ShowCursor(false);
			else {
				if (selected_f == -1) selected_f = fitted_f, fitted_f = -1;
				else {
					selected_f = -1;
					fitpoint_f(); selected_f = fitted_f, fitted_f = -1;
				}
			}
			break;
		}
		case WM_LBUTTONUP: {
			if (VPC_selected) {
				RECT R; GetClientRect(hWnd, &R);
				MapWindowPoints(hWnd, NULL, reinterpret_cast<POINT*>(&R), 2);
				SetCursorPos(R.left + prevCursor_F.x, R.bottom - prevCursor_F.y);
				ShowCursor(true);
			}
			VPC_SS = (Cursor_F - VPC_C).mod() < VPC_R;
			ReleaseCapture();
			if (VPC_SS && prevCursor_F == Cursor_F) {		// click no drag
				switch (VPC_selected - VPC) {
				case 0: PosF = vec3(PosF.mod(), 1e-5*PosF.mod(), 1e-8*PosF.mod()); break;
				case 1: PosF = vec3(1e-5*PosF.mod(), PosF.mod(), 1e-8*PosF.mod()); break;
				case 2: PosF = vec3(1e-8*PosF.mod(), -1e-5*PosF.mod(), PosF.mod()); break;
				case 3: PosF = vec3(-PosF.mod(), 1e-5*PosF.mod(), 1e-8*PosF.mod()); break;
				case 4: PosF = vec3(1e-5*PosF.mod(), -PosF.mod(), 1e-8*PosF.mod()); break;
				case 5: PosF = vec3(1e-8*PosF.mod(), 1e-5*PosF.mod(), -PosF.mod()); break;
				}
			}
			VPC_selected = 0;
			render_f();
			break;
		}
#pragma endregion
		}
		return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}



int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {

	BreakAtAlloc(-1);


	//Test(); exit(0);
	initModel();


	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = _T(APPLICATION_NAME);
	if (!RegisterClassEx(&wc)) return -1;


	HWnd = CreateWindow(
		_T(APPLICATION_NAME),
		_T(WIN_NAME),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		900, 600,
		NULL, NULL, hInstance, NULL
	);

	HWndF = CreateWindowEx(
		WS_EX_TOPMOST,
		//0,
		_T(APPLICATION_NAME),
		_T(WINF_NAME),
		(WS_OVERLAPPEDWINDOW & ~WS_MAXIMIZEBOX) | WS_BORDER,
		//CW_USEDEFAULT, CW_USEDEFAULT,
		1000, 150,
		//500, 600,
		350, 420,
		NULL, NULL, hInstance, NULL
	);

	HWndC = CreateWindowEx(
		WS_EX_TOPMOST,
		_T(APPLICATION_NAME),
		_T(WINC_NAME),
		(WS_OVERLAPPEDWINDOW & ~WS_MAXIMIZEBOX) | WS_BORDER,
		CW_USEDEFAULT, CW_USEDEFAULT,
		400, 300,
		NULL, NULL, hInstance, NULL
	);

	ShowWindow(HWnd, nCmdShow); UpdateWindow(HWnd);
	ShowWindow(HWndF, nCmdShow); UpdateWindow(HWndF);
	ShowWindow(HWndC, nCmdShow); UpdateWindow(HWndC);


	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	CheckMemoryLeaks;
	return (int)message.wParam;
}


