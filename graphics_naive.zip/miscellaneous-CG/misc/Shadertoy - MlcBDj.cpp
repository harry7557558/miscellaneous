#include <Windows.h>
#include <tchar.h>
#include "3D.h"

using namespace std;



HWND HWnd;
RECT Client; int clt_w, clt_h;
COLORREF *img; HBITMAP HImg;




#pragma region World


// The MIT License
// Copyright © 2018 Inigo Quilez
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

// When carving interiors of shapes ir when you want to give thickness to
// the object boundaries, a way to do it is to carve our a smaller copy of
// the object. That is very expensive though (twice as expensie!). There's
// a method that allows you ro create onions shells of any shape that is
// inexpensive and that returns an exact euclidean distance to the new
// generated shape.

// Related techniques:
//
// Elongation  : https://www.shadertoy.com/view/Ml3fWj
// Rounding    : https://www.shadertoy.com/view/Mt3BDj
// Onion       : https://www.shadertoy.com/view/MlcBDj
// Metric      : https://www.shadertoy.com/view/ltcfDj
// Combination : https://www.shadertoy.com/view/lt3BW2
// Extrusion2D : https://www.shadertoy.com/view/4lyfzw
// Revolution2D: https://www.shadertoy.com/view/4lyfzw
//
// More information here: http://iquilezles.org/www/articles/distfunctions/distfunctions.htm



//-------------------------------------------------

double onion(double d, double h)
{
	return abs(d) - h;
}

//-------------------------------------------------

double sdCappedCylinder(vec3 p, vec2 h)
{
	vec2 d = vec2(p.xz().mod(), abs(p.y)) - h;
	return min(max(d.x, d.y), 0.0) + vec2(max(d.x, 0), max(d.y, 0)).mod();
}


double sdTorus(vec3 p, vec2 t)
{
	vec2 q = vec2(p.xz().mod() - t.x, p.y);
	return q.mod() - t.y;
}

double sdSphere(vec3 p, double r)
{
	return p.mod() - r;
}

//---------------------------------

double map(vec3 pos)
{
	double d = 1e10;


	// sphere
	{
		vec3 q = pos - vec3(-3.0, 0.0, -1.0);
		d = min(d, sdSphere(q.yzx(), 0.4));
	}

	// double onion sphere
	{
		vec3 q = pos - vec3(-3.0, 0.0, 1.0);
		d = min(d, onion(onion(sdSphere(q.yzx(), 0.4), 0.05), 0.02));
	}

	// cylinder
	{
		vec3 q = pos - vec3(-1.0, 0.0, -1.0);
		d = min(d, sdCappedCylinder(q, vec2(0.4, 0.2)));
	}

	// single onion cylinder
	{
		vec3 q = pos - vec3(-1.0, 0.0, 1.0);
		d = min(d, onion(sdCappedCylinder(q, vec2(0.4, 0.2)), 0.03));
	}

	// torus
	{
		vec3 q = pos - vec3(1.0, 0.0, -1.0);
		d = min(d, sdTorus(q, vec2(0.4, 0.1)));
	}

	// single onion torus
	{
		vec3 q = pos - vec3(1.0, 0.0, 1.0);
		d = min(d, onion(sdTorus(q, vec2(0.4, 0.1)), 0.03));
	}

	// torus
	{
		vec3 q = pos - vec3(3.0, 0.0, -1.0);
		d = min(d, sdTorus(q.xzy(), vec2(0.5, 0.2)));
	}

	// triple onion torus
	{
		vec3 q = pos - vec3(3.0, 0.0, 1.0);
		d = min(d, onion(onion(onion(sdTorus(q.xzy(), vec2(0.5, 0.2)), 0.08), 0.04), 0.02));
	}

	// cut it all in half so we can see the interiors
	d = max(d, pos.y);

	return d;
}

// http://iquilezles.org/www/articles/normalsSDF/normalsSDF.htm
vec3 calcNormal(vec3 pos)
{
	const double ep = 0.0001;
	vec2 e = vec2(1.0, -1.0)*0.5773;
	return (e.xyy()*map(pos + e.xyy()*ep) +
		e.yyx()*map(pos + e.yyx()*ep) +
		e.yxy()*map(pos + e.yxy()*ep) +
		e.xxx()*map(pos + e.xxx()*ep)).unitvec();
}

// http://iquilezles.org/www/articles/rmshadows/rmshadows.htm
double calcSoftshadow(vec3 ro, vec3 rd, double tmin, double tmax, const double k)
{
	double res = 1.0;
	double t = tmin;
	for (int i = 0; i < 50; i++)
	{
		double h = map(ro + rd * t);
		res = min(res, k*h / t);
		t += Clamp(h, 0.02, 0.20);
		if (res<0.005 || t>tmax) break;
	}
	return Clamp(res, 0.0, 1.0);
}


#define AA 2

void mainImage(vec3& fragColor, vec2 fragCoord)
{
	vec3 tot = vec3(0, 0, 0);

	for (int m = 0; m < AA; m++)
		for (int n = 0; n < AA; n++)
		{
			// pixel coordinates
			vec2 o = vec2(double(m), double(n)) / double(AA); o.x -= 0.5;
			vec2 p = (-vec2(clt_w, clt_h) + 2.0*(fragCoord + o)) / clt_h;

			vec3 ro = vec3(0.0, 3.0, 6.0);
			vec3 rd = vec3(p - vec2(0.0, 1.0), -2.0).unitvec();

			double t = 5.0;
			for (int i = 0; i < 64; i++)
			{
				vec3 p = ro + t * rd;
				double h = map(p);
				if (abs(h) < 0.001 || t > 10.0) break;
				t += h;
			}

			vec3 col = vec3(0, 0, 0);

			if (t < 10.0)
			{
				vec3 pos = ro + t * rd;
				vec3 nor = calcNormal(pos);
				vec3  lig = vec3(1.0, 0.8, -0.2).unitvec();
				double dif = Clamp(dot(nor, lig), 0.0, 1.0);
				double sha = calcSoftshadow(pos, lig, 0.001, 1.0, 32.0);
				double amb = 0.5 + 0.5*nor.y;
				col = vec3(0.05, 0.1, 0.15)*amb +
					vec3(1.00, 0.9, 0.80)*dif*sha;
			}

			col = vec3(sqrt(col.x), sqrt(col.y), sqrt(col.z));
			tot += col;
		}
	tot /= double(AA*AA);

	fragColor = tot;
}



#pragma endregion Save from https://www.shadertoy.com/view/MlcBDj








#include <thread>

bool rendering = false;
void render() {

	if (rendering) return; rendering = true;

	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);



	unsigned clt_size = clt_w * clt_h;
	const unsigned MAX_THREADS = thread::hardware_concurrency();
	const unsigned ppt = 0x1000;
	const unsigned N = clt_size / ppt;

	bool* fn = new bool[MAX_THREADS]; for (int i = 0; i < MAX_THREADS; i++) fn[i] = false;
	thread** T = new thread*[MAX_THREADS]; for (int i = 0; i < MAX_THREADS; i++) T[i] = NULL;

	unsigned released = 0, finished = 0;
	while (finished < N) {
		for (int i = 0; i < MAX_THREADS; i++) {
			if (fn[i]) {
				fn[i] = false;
				delete T[i]; T[i] = 0;
				if (++finished >= N) break;
			}
			if (!fn[i] && !T[i] && released < N) {
				T[i] = new thread([&](unsigned beg, unsigned end, bool* sig) {
					COLORf col;
					for (unsigned i = beg; i < end; i++) {
						mainImage(*(vec3*)&col, vec2(i % clt_w, i / clt_w));
						img[i] = toCOLORREF(col);
					}
					*sig = true;
				}, ppt * released, ppt * (released + 1), fn + i);
				T[i]->detach();
				released++;
			}
		}
	}

	COLORf col;
	for (unsigned i = N * ppt; i < clt_size; i++) {
		mainImage(*(vec3*)&col, vec2(i % clt_w, i / clt_w));
		img[i] = toCOLORREF(col);
	}

	delete fn;
	delete T;



	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);

	rendering = false;

}



#include <string>
#include <chrono>
typedef chrono::high_resolution_clock NTime;
typedef std::chrono::duration<double> fsec;

HANDLE RenderingThread;
DWORD WINAPI fpsTest(HANDLE H) {

	auto uint2str = [](unsigned n)->string {
		string r;
		while (n) r = char('0' + n % 10) + r, n /= 10;
		return r;
	};
	auto fps2str = [](double a)->string {
		if (a <= 0 || isNaN(a)) return "NaN";
		if (round(a) >= 1000) return "Impossible!";
		int e = 3;
		while (a < 100) a *= 10, e--;
		string r;
		while (a != 0) r = char('0' + int(a) % 10) + r, a = int(a) / 10;
		while (e <= 0) r = '0' + r, e++;
		r.insert(r.begin() + e, '.');
		return r;
	};

	while (1) {
		Sleep(100);
		auto t0 = NTime::now();
		render();
		auto t1 = NTime::now();
		fsec fs = t1 - t0;
		SetWindowTextA(HWnd, &("   " + uint2str(clt_w) + "x" + uint2str(clt_h) + "      " + fps2str(1 / fs.count()) + "fps       Saved from https://www.shadertoy.com/view/MlcBDj")[0]);
	}


	return 0;
}




LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = clt_w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)clt_h : clt_h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};
	switch (message) {
	case WM_CREATE: {
		GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		InitializeClientBitmap(hWnd, HImg, img, false);
		HWnd = hWnd;
		RenderingThread = CreateThread(NULL, NULL, &fpsTest, NULL, NULL, NULL);
		break;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		while (rendering) Sleep(1);
		SuspendThread(RenderingThread);
		DeleteObject(HImg);
		InitializeClientBitmap(hWnd, HImg, img, false);
		render();
		ResumeThread(RenderingThread);
		break;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 120, lpMMI->ptMinTrackSize.y = 80;
		break;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HMem, HImg);
		BitBlt(hdc, 0, 0, Client.right, Client.bottom, HMem, 0, 0, SRCCOPY);
		SelectObject(HMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HMem);
		DeleteDC(hdc);
		break;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		TerminateThread(RenderingThread, NULL);
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}


int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
	const wchar_t CLASS_NAME[] = _T("Saved from https://www.shadertoy.com/view/MlcBDj");
	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = CLASS_NAME;
	if (!RegisterClassEx(&wc)) return -1;

	HWND hWnd = CreateWindowEx(
		0,
		CLASS_NAME,
		CLASS_NAME,
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		640, 400,
		NULL, NULL, hInstance, NULL
	);
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	return (int)message.wParam;
}


