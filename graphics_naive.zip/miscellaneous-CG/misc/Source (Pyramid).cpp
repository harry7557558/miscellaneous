#include <Windows.h>
#include <tchar.h>

#pragma warning(disable:4244 4018 4010 4305)
//#pragma optimize("",off)

#include "3D.h"
#include "RayTracing.h"


using namespace std;

#include <chrono>
typedef chrono::high_resolution_clock NTime;
typedef std::chrono::duration<double> fsec;

const auto t0 = NTime::now();
inline double iTime() { return fsec(NTime::now() - t0).count(); }



/* Window */

#define APPLICATION_NAME " Real-Time Ray Tracing (specular only)"

HWND HWnd;
RECT Client; int clt_w, clt_h;
COLORREF *img; HBITMAP HImg;



/* Construction */

const vec3 s_col = vec3(255, 250, 238) / 256, c_col = vec3(255, 182, 193) / 256;	// color of spheres(nodes) and cylinders(sticks)
const double radius_of_sphere = 0.2;



/* Rendering */

const vec3 dome = vec3(0, 0, 1).unitvec();	// lighting

vec3 P(5.8, 3.0, 2.1), V(1.6, 1.2, 0.9); double Unit = 600;
RT_Parallelogram Screen;
void CalcScreen() {
	vec3 v = (V - P).unitvec();
	double rz = atan2(v.x, -v.y), rx = atan2(hypot(v.x, v.y), v.z);
	mat3 M; M.rotate_zx(rz, rx);
	Screen = RT_Parallelogram(M * vec3(0.5*clt_w / Unit, -0.5*clt_h / Unit, 1) + P, M * vec3(-clt_w / Unit, 0, 0), M * vec3(0, clt_h / Unit, 0));
	//Dout("P=" << P << ", v=Vector(" << P << "," << (P + dist * v) << "), Screen=" << Screen);
}

// set this to 0 for self-adaptable supersampling
#define AA 0

bool param_is_modifying = true;



/* User */

bool mouse_down = false;
vec2 Cursor(0, 0), OrigCursor = Cursor;
vec3 OrigP, OrigV; RT_Parallelogram OrigScreen;

bool Ctrl = false, Shift = false, Alt = false;






//-------------------------------------------

#pragma region Frame Operation


#define SQUARE_BASED 1

#include <vector>

#if SQUARE_BASED

const mat3 Tr(1, 0, 1. / 2, 0, 1, 1. / 2, 0, 0, sqrt(2) / 2);

#define E_100 0b00000001
#define E_010 0b00000010
#define E_001 0b00000100
#define E_101 0b00001000
#define E_011 0b00010000
#define E_111 0b00100000

typedef byte Node;
inline bool has_100(const Node &e) { return e & E_100; } inline bool has_010(const Node &e) { return e & E_010; } inline bool has_001(const Node &e) { return e & E_001; } \
inline bool has_101(const Node &e) { return e & E_101; } inline bool has_011(const Node &e) { return e & E_011; } inline bool has_111(const Node &e) { return e & E_111; }
inline void set_100(Node &e) { e |= E_100; } inline void set_010(Node &e) { e |= E_010; } inline void set_001(Node &e) { e |= E_001; } \
inline void set_101(Node &e) { e |= E_101; } inline void set_011(Node &e) { e |= E_011; } inline void set_111(Node &e) { e |= E_111; }
inline void del_100(Node &e) { e &= ~E_100; } inline void del_010(Node &e) { e &= ~E_010; } inline void del_001(Node &e) { e &= ~E_001; } \
inline void del_101(Node &e) { e &= ~E_101; } inline void del_011(Node &e) { e &= ~E_011; } inline void del_111(Node &e) { e &= ~E_111; }


#pragma region RT_Cylinder Special Cases

#define RT_Cylinder_Constructors(s) \
	const static double r, r2, h; \
public: \
	vec3 C; \
	RT_Cylinder_##s() { col = c_col; } \
	RT_Cylinder_##s(cv3ref C) :C(C) { col = c_col; } \
	RT_Cylinder_##s(const RT_Cylinder_##s &other) :C(other.C) { col = c_col; } \
	RT_Cylinder_##s& operator = (const RT_Cylinder_##s &other) { C = other.C, col = c_col; return *this; } \
	virtual ~RT_Cylinder_##s() {} \
	virtual void init() {} \
	virtual void debug_output(wostream& os) const {}
#define RT_Cylinder_InitStatic(s) \
	const double RT_Cylinder_##s::r = 0.5*radius_of_sphere; \
	const double RT_Cylinder_##s::r2 = 0.25*radius_of_sphere*radius_of_sphere; \
	const double RT_Cylinder_##s::h = 1;


class RT_Cylinder_100 : public RT_Object {
	RT_Cylinder_Constructors(100);
	virtual bool intersect(cv3ref P, cv3ref d, double &t, vec3 &n) const {
		vec3 p = P - C;
		double a = d.yz().sqr(), b = dot(p.yz(), d.yz());
		double delta = b * b - a * (p.yz().sqr() - r2); if (delta <= 0) return false;
		delta = sqrt(delta) / a, b /= -a;
		a = b - delta, b += delta; if (a > b) delta = a, a = b, b = delta;
		t = a, delta = p.x + t * d.x;
		if (t < RT_EPSILON || delta < 0 || delta > h) {
			t = b, delta = p.x + t * d.x;
			if (t < RT_EPSILON || delta < 0 || delta > h) return false;
		}
		n = vec3(0.0, (p.yz() + t * d.yz()) / (p.yz().sqr() < r2 ? -r : r)); return true;
	}
};
RT_Cylinder_InitStatic(100);

class RT_Cylinder_010 : public RT_Object {
	RT_Cylinder_Constructors(010);
	virtual bool intersect(cv3ref P, cv3ref d, double &t, vec3 &n) const {
		vec3 p = P - C;
		double a = d.xz().sqr(), b = dot(p.xz(), d.xz());
		double delta = b * b - a * (p.xz().sqr() - r2); if (delta <= 0) return false;
		delta = sqrt(delta) / a, b /= -a;
		a = b - delta, b += delta; if (a > b) delta = a, a = b, b = delta;
		t = a, delta = p.y + t * d.y;
		if (t < RT_EPSILON || delta < 0 || delta > h) {
			t = b, delta = p.y + t * d.y;
			if (t < RT_EPSILON || delta < 0 || delta > h) return false;
		}
		n = (p + t * d) / (p.xz().sqr() < r2 ? -r : r); n.y = 0; return true;
	}
};
RT_Cylinder_InitStatic(010);

#pragma endregion


#define d_000 0
#define d_100 1
#define d_010 2
#define d_001 3
#define d_101 4
#define d_011 5
#define d_111 6

const mat3 CT_Matrix[] = { RotationMatrix_zx(0, 0),
	RotationMatrix_zx(1.5707963267948966, 1.5707963267948966),
	RotationMatrix_zx(3.141592653589793, 1.5707963267948966),
	RotationMatrix_zx(2.356194490192345, 0.7853981633974483),
	RotationMatrix_zx(-2.356194490192345, 0.7853981633974483),
	RotationMatrix_zx(0.7853981633974483, 0.7853981633974483),
	RotationMatrix_zx(-0.7853981633974483, 0.7853981633974483) };
const mat3 CT_Invert[] = {
	CT_Matrix[d_000].invert(), CT_Matrix[d_100].invert(), CT_Matrix[d_010].invert(), CT_Matrix[d_001].invert(),
	CT_Matrix[d_101].invert(), CT_Matrix[d_011].invert(), CT_Matrix[d_111].invert() };

class RT_Node {
	RT_Box Border;
	const static double sr, sr2, cr, cr2, ch;
	static bool std_cylinder_intersect(cv3ref p, cv3ref d, double &t, vec3 &n) {
		double a = d.xy().sqr(), b = dot(p.xy(), d.xy());
		double delta = b * b - a * (p.xy().sqr() - cr2); if (delta <= 0) return false;
		delta = sqrt(delta) / a, b /= -a;
		a = b - delta, b += delta; if (a > b) delta = a, a = b, b = delta;
		t = a, delta = p.z + t * d.z;
		if (t < RT_EPSILON || delta < 0 || delta > ch) {
			t = b, delta = p.z + t * d.z;
			if (t < RT_EPSILON || delta < 0 || delta > ch) return false;
		}
		n = (p.xy() + t * d.xy()) / (p.xy().sqr() < cr2 ? -cr : cr); return true;
	}
	static bool std_sphere_intersect(cv3ref p, cv3ref d, double &t, vec3 &n) {
		if (dot(p, d) >= 0) return false;
		double rd2 = cross(p, d).sqr(); if (rd2 >= sr2) return false;
		t = sqrt(p.sqr() - rd2) - sqrt(sr2 - rd2); if (t < RT_EPSILON) return false;
		n = (p + t * d) / sr; return true;
	}
public:
	vec3 C[7];
	Node Nd; bool _100, _010, _001, _101, _011, _111;
	void init() {
		Border = RT_Sphere(C[0], radius_of_sphere).getMaxMin();
		for (int i = 1; i < 7; i++) C[i] = CT_Invert[i] * C[0];
		_100 = has_100(Nd), _010 = has_010(Nd), _001 = has_001(Nd), _101 = has_101(Nd), _011 = has_011(Nd), _111 = has_111(Nd);
		if (_100) Border.Union(RT_Cylinder(C[0], Tr*vec3(1, 0, 0), RT_Node::ch, RT_Node::cr).getMaxMin());
		if (_010) Border.Union(RT_Cylinder(C[0], Tr*vec3(0, 1, 0), RT_Node::ch, RT_Node::cr).getMaxMin());
		if (_001) Border.Union(RT_Cylinder(C[0], Tr*vec3(0, 0, 1), RT_Node::ch, RT_Node::cr).getMaxMin());
		if (_101) Border.Union(RT_Cylinder(C[0], Tr*vec3(-1, 0, 1), RT_Node::ch, RT_Node::cr).getMaxMin());
		if (_011) Border.Union(RT_Cylinder(C[0], Tr*vec3(0, -1, 1), RT_Node::ch, RT_Node::cr).getMaxMin());
		if (_111) Border.Union(RT_Cylinder(C[0], Tr*vec3(-1, -1, 1), RT_Node::ch, RT_Node::cr).getMaxMin());
	}

	RT_Node() {}
	RT_Node(int x, int y, int z, Node n) : Nd(n) {
		C[0] = Tr * vec3(x, y, z) + vec3(0, 0, radius_of_sphere);
		init();
	}
	~RT_Node() {}

	bool intersect(const vec3* const &P, const vec3* const &d, double &t, vec3 &n, int& Int) const {
		if (Nd && !Border.intersect(*P, *d)) return false;
		double tt; t = INFINITY; vec3 tn;
		if (std_sphere_intersect(P[d_000] - C[0], d[d_000], tt, tn)) t = tt, n = tn, Int = d_000;
		if (_100 && std_cylinder_intersect(P[d_100] - C[d_100], d[d_100], tt, tn) && tt < t) t = tt, n = tn, Int = d_100;
		if (_010 && std_cylinder_intersect(P[d_010] - C[d_010], d[d_010], tt, tn) && tt < t) t = tt, n = tn, Int = d_010;
		if (_001 && std_cylinder_intersect(P[d_001] - C[d_001], d[d_001], tt, tn) && tt < t) t = tt, n = tn, Int = d_001;
		if (_101 && std_cylinder_intersect(P[d_101] - C[d_101], d[d_101], tt, tn) && tt < t) t = tt, n = tn, Int = d_101;
		if (_011 && std_cylinder_intersect(P[d_011] - C[d_011], d[d_011], tt, tn) && tt < t) t = tt, n = tn, Int = d_011;
		if (_111 && std_cylinder_intersect(P[d_111] - C[d_111], d[d_111], tt, tn) && tt < t) t = tt, n = tn, Int = d_111;
		return 0 * t == 0;
	}
};
const double RT_Node::sr = radius_of_sphere;
const double RT_Node::sr2 = radius_of_sphere * radius_of_sphere;
const double RT_Node::cr = 0.5*radius_of_sphere;
const double RT_Node::cr2 = 0.25*radius_of_sphere*radius_of_sphere;
const double RT_Node::ch = 1.0;

#elif TRIANGLE_BASED
const mat3 Tr(1, 1. / 2, 1. / 2, 0, sqrt(3) / 2, sqrt(3) / 6, 0, 0, 2 * sqrt(2) / 3);
#endif


//-------------------------------------------


// sort z, y, x in increasing order
typedef struct { int x; Node data; } F_obj;
typedef struct { int y; vector<F_obj*> data; } F_row;
typedef struct { int z; vector<F_row*> data; } F_layer;
vector<F_layer*> Frame;

// if found, return true, and set d to the position;  if not found, return false, and set d to the next position
bool searchLayer(int z, int* d) {
	if (Frame.empty() || z < Frame[0]->z) { if (d) *d = 0; return false; }
	if (z > Frame.back()->z) { if (d) *d = Frame.size(); return false; }
	int r, rb = 0, re = Frame.size();
	while (1) {
		if (re - rb <= 1) {
			if (Frame[rb]->z == z) { r = rb; break; }
			if (Frame[re]->z == z) { r = re; break; }
			if (d) *d = re; return false;
		}
		r = (rb + re) / 2;
		if (Frame[r]->z == z) break;
		if (Frame[r]->z > z) re = r;
		else rb = r;
	}
	if (d) *d = r; return true;
}
bool searchRow(const F_layer *L, int y, int* d) {
	if (L->data.empty() || y < L->data[0]->y) { if (d) *d = 0; return false; }
	if (y > L->data.back()->y) { if (d) *d = L->data.size(); return false; }
	int r, rb = 0, re = L->data.size();
	while (1) {
		if (re - rb <= 1) {
			if (L->data[rb]->y == y) { r = rb; break; }
			if (L->data[re]->y == y) { r = re; break; }
			if (d) *d = re; return false;
		}
		r = (rb + re) / 2;
		if (L->data[r]->y == y) break;
		if (L->data[r]->y > y) re = r;
		else rb = r;
	}
	if (d) *d = r; return true;
}
bool searchObject(const F_row *L, int x, int* d) {
	if (L->data.empty() || x < L->data[0]->x) { if (d) *d = 0; return false; }
	if (x > L->data.back()->x) { if (d) *d = L->data.size(); return false; }
	int r, rb = 0, re = L->data.size();
	while (1) {
		if (re - rb <= 1) {
			if (L->data[rb]->x == x) { r = rb; break; }
			if (L->data[re]->x == x) { r = re; break; }
			if (d) *d = re; return false;
		}
		r = (rb + re) / 2;
		if (L->data[r]->x == x) break;
		if (L->data[r]->x > x) re = r;
		else rb = r;
	}
	if (d) *d = r; return true;
}



Node* getNode(int x, int y, int z, int* dx, int* dy, int* dz) {
	int rx, ry, rz;
	if (!searchLayer(z, &rz)) { if (dz) *dz = rz; return NULL; }
	if (dz) *dz = rz;
	if (!searchRow(Frame[rz], y, &ry)) { if (dy) *dy = ry; return NULL; }
	if (dy) *dy = ry;
	if (!searchObject(Frame[rz]->data[ry], x, &rx)) { if (dx) *dx = rx; return NULL; }
	if (dx) *dx = rx;
	return &Frame[rz]->data[ry]->data[rx]->data;
}

// exist - set, return false;  not exist - create, return true
bool addNode(int x, int y, int z, Node N) {
	bool r = false;
	int rx = 0, ry = 0, rz = 0;
	if (!searchLayer(z, &rz)) {
		Frame.insert(Frame.begin() + rz, new F_layer);
		Frame[rz]->z = z; r = true;
	}
	if (r || !searchRow(Frame[rz], y, &ry)) {
		Frame[rz]->data.insert(Frame[rz]->data.begin() + ry, new F_row);
		Frame[rz]->data[ry]->y = y; r = true;
	}
	if (r || !searchObject(Frame[rz]->data[ry], x, &rx)) {
		Frame[rz]->data[ry]->data.insert(Frame[rz]->data[ry]->data.begin() + rx, new F_obj);
		Frame[rz]->data[ry]->data[rx]->x = x; r = true;
	}
	Frame[rz]->data[ry]->data[rx]->data = N;
	return r;
}

void debug() {
	srand(0);
	F_layer Fz; F_row Fy; F_obj Fx; Fx.data = 0;
	Fz.z = 0; for (int k = 0; k < rand() % 10 + 5; k++) {
		Frame.push_back(new F_layer(Fz)); Fz.z += rand() % 2 + 1;
		Fy.y = 0; for (int j = 0; j < rand() % 10 + 5; j++) {
			Frame.back()->data.push_back(new F_row(Fy)); Fy.y += rand() % 2 + 1;
			Fx.x = 0; for (int i = 0; i < rand() % 10 + 5; i++) {
				Frame.back()->data.back()->data.push_back(new F_obj(Fx)); Fx.x += rand() % 2 + 1;
			}
		}
	}
	addNode(-1, 0, 4, E_100 | E_010 | E_001); &Frame;
	int dx = -1, dy = -1, dz = -1;
	Node* Found = getNode(0, 0, 0, &dx, &dy, &dz); &Frame;
	Dout(Found << ": " << dx << ", " << dy << ", " << dz);
}

#pragma endregion




//-------------------------------------------

#pragma region Construction


const RT_Parallelogram Plane(vec3(-200, -200, 0), vec3(400, 0, 0), vec3(0, 400, 0), vec3(0.5, 0.8, 1));
vector<RT_Node*> Nodes;


void destruct() {
	bool is_modifying = param_is_modifying; param_is_modifying = true;
	for (int i = 0; i < Nodes.size(); i++) delete Nodes[i];
	Nodes.clear();
	param_is_modifying = is_modifying;
}
void destruct_frame() {
	for (int k = 0; k < Frame.size(); k++) {
		for (int j = 0; j < Frame[k]->data.size(); j++) {
			for (int i = 0; i < Frame[k]->data[j]->data.size(); i++) delete Frame[k]->data[j]->data[i];
			Frame[k]->data[j]->data.clear();
			delete Frame[k]->data[j];
		}
		Frame[k]->data.clear();
		delete Frame[k];
	}
	Frame.clear();
}



void construct_from_frame() {
	destruct();
	for (int k = 0, z; k < Frame.size(); k++) {
		z = Frame[k]->z;
		for (int j = 0, y; j < Frame[k]->data.size(); j++) {
			y = Frame[k]->data[j]->y;
			for (int i = 0, x; i < Frame[k]->data[j]->data.size(); i++) {
				x = Frame[k]->data[j]->data[i]->x;
				Nodes.push_back(new RT_Node(x, y, z, Frame[k]->data[j]->data[i]->data));
			}
		}
	}
}

void construct() {
	if (Frame.empty()) {
		// Initialize to a default world
		const unsigned stair = 3;
		for (int i = 0; i < stair; i++) for (int j = 0; j < stair; j++) for (int k = 0; k < stair; k++)
			if (i + k < stair && j + k < stair) addNode(i, j, k, (i + k != stair - 1 ? E_100 : 0) | (j + k != stair - 1 ? E_010 : 0) | (i + k != stair - 1 && j + k != stair - 1 ? E_001 : 0) \
				| (i != 0 && j + k != stair - 1 ? E_101 : 0) | (j != 0 && i + k != stair - 1 ? E_011 : 0) | (i != 0 && j != 0 ? E_111 : 0));
		// n(n+1)(2n+1)/6 spheres and 2n^2(n-1) cylinders
	}

	construct_from_frame();


	CalcScreen();
	//for (int i = 0; i < Objs.size(); i++) dout("C_{" << i << "}=" << *Objs.at(i) << ";  " \
		<< "SetColor(C_{" << i << "}," << int(255 * Objs.at(i)->col.x) << "," << int(255 * Objs.at(i)->col.y) << "," << int(255 * Objs.at(i)->col.z) << ")" << endl);
}

#pragma endregion




//-------------------------------------------

#pragma region Rendering


bool calcIntersect(const vec3* const &p, const vec3* const &d, double &t, vec3 &n, vec3 &col) {
	double min_t = INFINITY; vec3 min_n;
	if (Plane.intersect(*p, *d, t, n)) min_t = t, min_n = n, col = Plane.col;
	for (unsigned i = 0; i < Nodes.size(); i++) {
		int Int;
		if (Nodes.at(i)->intersect(p, d, t, n, Int) && t < min_t) {
			min_t = t, min_n = CT_Matrix[Int] * n, col = Int ? c_col : s_col;
		}
	}
	t = min_t, n = min_n;
	return 0 * t == 0;
}

vec3 traceRay(cv3ref P, cv3ref D, unsigned N) {		// return color
	if (++N > 20) {
		double t = dot(dome, D); if (t < 0) t = 0;
		return vec3(t, t, t);
	}
	const RT_Object* IO; double t; vec3 n; vec3 Col;
	vec3 p[7], d[7];
	*p = P, *d = D; for (int i = 1; i < 7; i++) p[i] = CT_Invert[i] * P, d[i] = CT_Invert[i] * D;
	if (calcIntersect(p, d, t, n, Col)) {
		vec3 col = traceRay(P + t * D, D - (2 * dot(D, n)) * n, N);
		//double t = dot(dome, d - (2 * dot(d, n)) * n); if (t < 0) t = 0; vec3 col(t, t, t);		// disable reflection
		col.x *= Col.x, col.y *= Col.y, col.z *= Col.z;
		//dout("Vector(" << P << "," << (P + t * d) << ")" << endl);
		return col;
	}
	else {
		double t = dot(dome, D);
		//dout("Vector(" << P << "," << (P + Unit * d) << ")" << endl);
		if (t > 0) return vec3(t, t, t);
		else return vec3(0, 0, 0);
	}

}


void MainImage(vec3 &col, vec2 coor) {
	vec3 dir = (Screen.O + (coor.x / clt_w)*Screen.A + (coor.y / clt_h)*Screen.B - P).unitvec();
	col = traceRay(P, dir, 0);
}



//-------------------------------------------


#include <thread>

bool rendering = false;
void render() {

	if (rendering) return; rendering = true;

	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);


	unsigned clt_size = clt_w * clt_h;
	const unsigned MAX_THREADS = thread::hardware_concurrency();
	const unsigned ppt = 0x2000;
	const unsigned N = clt_size / ppt;

	bool* fn = new bool[MAX_THREADS]; for (int i = 0; i < MAX_THREADS; i++) fn[i] = false;
	thread** T = new thread*[MAX_THREADS]; for (int i = 0; i < MAX_THREADS; i++) T[i] = NULL;

	const unsigned uAA = AA == 0 ? 1 : AA;

	auto calcCol = [&](unsigned beg, unsigned end, bool* sig) {
		COLORf col; vec3 vcol;
		for (unsigned i = beg; i < end; i++) {
			col.r = col.g = col.b = 0;
			for (unsigned u = 0; u < uAA; u++) for (unsigned v = 0; v < uAA; v++)
				if (!param_is_modifying) MainImage(vcol, vec2(i % clt_w + double(u) / uAA, i / clt_w + double(v) / uAA)), *(vec3*)&col += vcol;
			*(vec3*)&col /= uAA * uAA;
			if (!param_is_modifying) img[i] = toCOLORREF(col);
		}
		if (sig) *sig = true;
	};

	unsigned released = 0, finished = 0;
	while (finished < N) {
		for (int i = 0; i < MAX_THREADS; i++) {
			if (fn[i]) {
				fn[i] = false;
				delete T[i]; T[i] = 0;
				if (++finished >= N) break;
			}
			if (!fn[i] && !T[i] && released < N) {
				T[i] = new thread(calcCol, ppt * released, ppt * (released + 1), fn + i);
				T[i]->detach();
				released++;
			}
		}
	}

	calcCol(N * ppt, clt_size, NULL);

#if AA==0

#endif

	delete fn;
	delete T;

	if (Ctrl) for (int i = clt_h - 10; i > clt_h - 30; i--) for (int j = 10; j < 30; j++) img[i*clt_w + j] = _RGB(0, 255, 0);
	else if (Shift) for (int i = clt_h - 10; i > clt_h - 30; i--) for (int j = 10; j < 30; j++) img[i*clt_w + j] = _RGB(255, 255, 0);
	else if (Alt) for (int i = clt_h - 10; i > clt_h - 30; i--) for (int j = 10; j < 30; j++) img[i*clt_w + j] = _RGB(255, 0, 0);


	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);

	rendering = false;


}
void dbgRender() {
	COLORf col;
	for (unsigned i = 0, clt_size = clt_w * clt_h; i < clt_size; i++) {
		MainImage(*(vec3*)&col, vec2(i % clt_w, i / clt_w)), img[i] = toCOLORREF(col);
	}

	unsigned Fw = 300, Fh = 160;
	if (Fw > 0 && Fh > 0 && Fw + 1 < clt_w && Fh + 1 < clt_h) {
		MainImage(*(vec3*)&col, vec2(Fw, Fh));
		img[Fh * clt_w + Fw] = toCOLORREF(col);
		img[(Fh - 1)*clt_w + Fw] = img[(Fh + 1)*clt_w + Fw] = img[Fh*clt_w + Fw - 1] = img[Fh*clt_w + Fw + 1] = _RGB(255, 0, 0);
	}

	saveBitmap(img, clt_w, clt_h, "C:\\Users\\harry\\Desktop\\Test\\debug.bmp");
	exit(0);
}


#include <string>

HANDLE RenderingThread;
DWORD WINAPI fpsTest(HANDLE H) {

	auto uint2str = [](unsigned n)->string {
		string r;
		while (n) r = char('0' + n % 10) + r, n /= 10;
		return r;
	};
	auto fps2str = [](double a)->string {
		if (a <= 0 || a > 2000 || isNaN(a)) return "###";
		int e = 3;
		while (a < 100) a *= 10, e--;
		string r;
		while (a != 0) r = char('0' + int(a) % 10) + r, a = int(a) / 10;
		while (e <= 0) r = '0' + r, e++;
		if (e < 3) r.insert(r.begin() + e, '.');
		return r;
	};

	while (1) {
		Sleep(1000);
		auto t0 = NTime::now();
		render();
		auto t1 = NTime::now();
		fsec fs = t1 - t0;
		SetWindowTextA(HWnd, &("   " + (fps2str(1 / fs.count()) + "fps") + "      " + (uint2str(clt_w) + "x" + uint2str(clt_h)) + "       " + APPLICATION_NAME)[0]);
	}


	return 0;
}


#pragma endregion




//-------------------------------------------



#include <windowsx.h>



bool IntersectionTest(vec3 P, vec3 d, RT_Object** IO, double* _t, vec3* _n) {
	d /= d.mod();
	double min_t = INFINITY, t; vec3 min_n, n; RT_Object* I = 0;
	/*for (int i = 0; i < Objs.size(); i++) {
		if (Objs.at(i)->intersect(P, d, t, n) && t < min_t) min_t = t, min_n = n, I = Objs.at(i);
	}*/
	if (isNaN(min_t)) min_t = -P.z / d.z;
	if (_t != 0) *_t = min_t; if (_n != 0) *_n = min_n; if (IO != 0) *IO = I;
	return I;
}
vec3 fromScreen(vec2 coor) {
	coor.x /= clt_w, coor.y /= clt_h;
	vec3 S = Screen.O + coor.x * Screen.A + coor.y * Screen.B, dir = (S - P).unitvec();
	double t; if (IntersectionTest(P, dir, NULL, &t, NULL)) return P + t * dir;
	return P - (P.z / dir.z) * dir;
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = clt_w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)clt_h : clt_h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};
	switch (message) {
#pragma region window
	case WM_CREATE: {
		GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		InitializeClientBitmap(hWnd, HImg, img, false);
		HWnd = hWnd;
		construct();
		const RT_Object* IO; double t; vec3 n;
		//if (calcIntersect(P, (V - P).unitvec(), IO, t, n)) V = P + t * (V - P).unitvec();
		//dbgRender();
		RenderingThread = CreateThread(NULL, NULL, &fpsTest, NULL, NULL, NULL);
		return 0;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		param_is_modifying = true;
		while (rendering) Sleep(1);
		SuspendThread(RenderingThread);
		GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		Unit *= sqrt((clt_w*clt_h) / (prev_w*prev_h));
		DeleteObject(HImg);
		InitializeClientBitmap(hWnd, HImg, img, false);
		CalcScreen();
		param_is_modifying = false;
		render();
		ResumeThread(RenderingThread);
		return 0;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 240, lpMMI->ptMinTrackSize.y = 160;
		return 0;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HMem, HImg);
		BitBlt(hdc, 0, 0, Client.right, Client.bottom, HMem, 0, 0, SRCCOPY);
		SelectObject(HMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HMem);
		DeleteDC(hdc);
		return 0;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		param_is_modifying = true;
		while (rendering) Sleep(1);
		TerminateThread(RenderingThread, NULL);
		destruct();
		destruct_frame();
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
#pragma endregion
#pragma region user
	case WM_MOUSEMOVE: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		if (mouse_down) {
			if (Shift) {
				double dx = OrigCursor.x - Cursor.x, dy = OrigCursor.y - Cursor.y;
				dx *= 2 * PI / clt_w, dy *= 2 * PI / clt_h;
				vec3 OP = OrigP, OV = OrigV;
				double a = asin((OP - OV).unitvec().z);
				if (a + dy >= 1.57) dy = 1.57 - a;
				if (a + dy <= 0.01) dy = 0.01 - a;
				mat3 M; M.rotate_z(dx); M.rotate(cross(M * (OP - OV), vec3(0, 0, 1)), dy);
				P = M * (OP - OV) + OV;
			}
			CalcScreen();
			render(); return 0;
		}
		return 0;
	}
	case WM_LBUTTONDOWN: {
		mouse_down = true;
		OrigCursor = Cursor, OrigP = P, OrigV = V, OrigScreen = Screen;

		if (Shift) {

		}
		else if (Ctrl) {

		}
		else if (Alt) {
			RT_Object* p = 0;
			/*if (IntersectionTest(P, fromScreen(Cursor) - P, &p, NULL, NULL)) {
				for (int i = 1; i < Objs.size(); i++) if (Objs.at(i) == p) Objs.erase(Objs.begin() + i), i--;
				render();
			}*/
		}

		return 0;
	}
	case WM_LBUTTONUP: {
		mouse_down = false;
		return 0;
	}
	case WM_MOUSEWHEEL: {	// doesn't work fine
		double delta = GET_WHEEL_DELTA_WPARAM(wParam);
		vec3 Vf = fromScreen(Cursor);
		double t; IntersectionTest(P, Vf - P, NULL, &t, NULL);
		delta *= 0.0005 * t;
		if (abs(delta) < 0.1) delta = delta < 0 ? -0.1 : 0.1;
		if (abs(delta) > 1000) delta = delta < 0 ? -1000 : 1000;
		vec3 SI = (Vf - P).unitvec();
		vec3 dr = (V - P).unitvec();
		P += delta * (V - P).unitvec(); if (P.z < 0.01) P.z = 0.01;
		vec3 nSI = (Vf - P).unitvec();
		mat3 M; M.rotate_z(asin(det(nSI.xy().unitvec(), SI.xy().unitvec())));
		SI = M * SI; M.rotate(cross(SI, nSI), acos(dot(SI, nSI)));
		dr = M * dr;
		if (IntersectionTest(P, dr, NULL, &t, NULL)) V = P + t * dr;

		CalcScreen();
		render(); return 0;
	}
	case WM_SYSKEYDOWN:;
	case WM_KEYDOWN: {
		if (!mouse_down) switch (wParam) {
		case VK_CONTROL: { Ctrl = true, Shift = Alt = false; break; }
		case VK_SHIFT: { Shift = true, Ctrl = Alt = false; break; }
		case VK_MENU: { Alt = true, Ctrl = Shift = false; break; }
		}
		render();
		break;
	}
	case WM_SYSKEYUP:;
	case WM_KEYUP: {
		if (!mouse_down) switch (wParam) {
		case VK_CONTROL: { Ctrl = false; break; }
		case VK_SHIFT: { Shift = false; break; }
		case VK_MENU: { Alt = false; break; }
		}
		render();
		break;
	}
#pragma endregion
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}


int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
	//debug(); exit(0);
	const wchar_t CLASS_NAME[] = _T(APPLICATION_NAME);
	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = CLASS_NAME;
	if (!RegisterClassEx(&wc)) return -1;

	HWND hWnd = CreateWindowEx(
		0,
		CLASS_NAME,
		CLASS_NAME,
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		640, 400,
		NULL, NULL, hInstance, NULL
	);
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	return (int)message.wParam;
}


