#ifndef UNICODE
#define UNICODE
#endif

#pragma warning(disable:4244 4018 4010)

#include <Windows.h>
#include <windowsx.h>
#include <tchar.h>
#include <cmath>
#include <algorithm>
using namespace std;

#define PI 3.1415926535897932384626433832795029

#define SNAIL true

#if RING
#define X(u,v) 0.6*(cos(u)*(4+0.5*cos(v)))
#define Y(u,v) 0.6*(sin(u)*(3.2+0.5*cos(v)))
#define Z(u,v) 0.6*(1.2*sin(v))
#define u_min 0.
#define u_max (2*PI)
#define v_min 0.
#define v_max (2*PI)
#define u_dif 200
#define v_dif 200
#elif SNAIL
#define X(u,v) 2.4*(0.4*(1-v/(2*PI))*(1+cos(u)+0.1)*cos(3*v))
#define Y(u,v) 2.4*(0.4*(1-v/(2*PI))*(1+cos(u)+0.1)*sin(3*v))
#define Z(u,v) 2.4*(0.5*v/(2*PI)-0.4*(1-v/(2*PI))*sin(u))
#define u_min 0.
#define u_max (2*PI)
#define v_min 0.
#define v_max (2*PI)
#define u_dif 200
#define v_dif 400
#elif DISH
#define X(u,v) cos(u)*(cos(u/2)*(sqrt(2)+cos(v))+sin(u/2)*sin(v)*cos(v))
#define Y(u,v) -sin(u)*(cos(u/2)*(sqrt(2)+cos(v))+sin(u/2)*sin(v)*cos(v))
#define Z(u,v) -sin(u/2)*(sqrt(2)+cos(v))+cos(u/2)*sin(v)*cos(v)
#define u_min 0.
#define u_max (4*PI)
#define v_min 0.
#define v_max (2*PI)
#define u_dif 600
#define v_dif 300
#elif BEADS
const int BEADS_N = 24;
const double BEADS_Tr = PI / BEADS_N;
const double BEADS_R = 1.2;
const double BEADS_r = BEADS_R / 2 * sqrt(2 * (1 - cos(2 * PI / BEADS_N)));
const double BEADS_T = 1.2;
const double BEADS_t = 2 * PI*floor(BEADS_N*BEADS_T / (2 * PI)) / BEADS_N;
double BEADS_Nr(double u) { return sqrt(BEADS_Tr*BEADS_Tr - pow(u - 2 * BEADS_Tr*floor((u + BEADS_Tr) / (2 * BEADS_Tr)), 2)); }
#define X(u,v) 1.5*(cos(u)*(BEADS_R+BEADS_Nr(u)*cos(v)))
#define Y(u,v) 1.5*(sin(u)*(BEADS_R+BEADS_Nr(u)*cos(v)))
#define Z(u,v) 1.5*(BEADS_Nr(u)*sin(v)+BEADS_r)
#define u_min 0.
#define u_max (2*PI)
#define v_min 0.
#define v_max (2*PI)
#define u_dif 800
#define v_dif 400
#endif

#define _RGB(r,g,b) ((COLORREF)(((BYTE)(b)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(r))<<16)))
COLORREF mix(COLORREF a, COLORREF b, double r) { return _RGB((1 - r)*((BYTE*)&a)[2] + r * ((BYTE*)&b)[2], (1 - r)*((BYTE*)&a)[1] + r * ((BYTE*)&b)[1], (1 - r)*(BYTE)a + r * (BYTE)b); }

#ifdef _DEBUG
#define fill_n(First,Count,Val) for (unsigned i = 0, l = clt_w * clt_h; i < l; i++) First[i] = Val;
#define sort_objs mergesort_objs
#else
#include <memory>
#define fill_n(First,Count,Val) uninitialized_fill_n(First, Count, Val)
#define sort_objs heapsort_objs
#endif


class point {
public:
	double x, y, z;
	point() {}
	point(double x, double y, double z) :x(x), y(y), z(z) {}
	point(const point &other) :x(other.x), y(other.y), z(other.z) {}
	point& operator = (const point &other) { x = other.x, y = other.y, z = other.z; return *this; }
	~point() {}

	void normalize() { double m = sqrt(x*x + y * y + z * z); x /= m, y /= m, z /= m; }
	friend double dot(const point &P, const point &Q) { return P.x*Q.x + P.y*Q.y + P.z*Q.z; }
	friend point cross(const point &P, const point &Q) { return point(P.y*Q.z - P.z*Q.y, P.z*Q.x - P.x*Q.z, P.x*Q.y - P.y*Q.x); }
	point operator - () const { return point(-x, -y, -z); }
	point operator + (const point &p) const { return point(x + p.x, y + p.y, z + p.z); }
	point operator - (const point &p) const { return point(x - p.x, y - p.y, z - p.z); }
	friend point operator * (const double &c, const point &p) { return point(c*p.x, c*p.y, c*p.z); }
	void operator += (const point &p) { x += p.x, y += p.y, z += p.z; }
	void operator -= (const point &p) { x -= p.x, y -= p.y, z -= p.z; }
	void operator *= (const double &c) { x *= c, y *= c, z *= c; }
	void operator /= (const double &c) { x /= c, y /= c, z /= c; }
};
class affine { 	// matrix
	double p[4][4];
public:
	affine() { for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) p[i][j] = i == j ? 1 : 0; }
	affine(const affine &other) { for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) p[i][j] = other.p[i][j]; }
	affine(const double& _00, const double& _01, const double& _02,
		const double& _10, const double& _11, const double& _12, const double& _20, const double& _21, const double& _22) {
		p[0][0] = _00, p[0][1] = _01, p[0][2] = _02, p[1][0] = _10, p[1][1] = _11, p[1][2] = _12, p[2][0] = _20, p[2][1] = _21, p[2][2] = _22,
			p[0][3] = p[1][3] = p[2][3] = 0, p[3][0] = p[3][1] = p[3][2] = 0, p[3][3] = 1;
	}
	affine(const double& _00, const double& _01, const double& _02, const double& _03, const double& _10, const double& _11, const double& _12, const double &_13,
		const double& _20, const double& _21, const double& _22, const double& _23, const double& _30, const double& _31, const double& _32, const double& _33) {
		p[0][0] = _00, p[0][1] = _01, p[0][2] = _02, p[0][3] = _03, p[1][0] = _10, p[1][1] = _11, p[1][2] = _12, p[1][3] = _13,
			p[2][0] = _20, p[2][1] = _21, p[2][2] = _22, p[2][3] = _23, p[3][0] = _30, p[3][1] = _31, p[3][2] = _32, p[3][3] = _33;
	}
	~affine() {}
	const double* operator [] (const unsigned &n) const { return &p[n][0]; }
	double* operator [] (const unsigned &n) { return &p[n][0]; }
	point operator * (const point &P) const {
		double m = p[3][0] * P.x + p[3][1] * P.y + p[3][2] * P.z + p[3][3];
		return point((p[0][0] * P.x + p[0][1] * P.y + p[0][2] * P.z + p[0][3]) / m,
			(p[1][0] * P.x + p[1][1] * P.y + p[1][2] * P.z + p[1][3]) / m, (p[2][0] * P.x + p[2][1] * P.y + p[2][2] * P.z + p[2][3]) / m);
	}
	affine operator * (const affine &A) const {
		affine R;
		for (int m = 0; m < 4; m++) {
			for (int n = 0; n < 4; n++) {
				R.p[m][n] = 0;
				for (int i = 0; i < 4; i++) R.p[m][n] += p[m][i] * A.p[i][n];
			}
		}
		return R;
	}
	affine invert() const {
		affine R;
		R.p[0][0] = p[1][1] * p[2][2] * p[3][3] - p[1][1] * p[2][3] * p[3][2] - p[2][1] * p[1][2] * p[3][3] + p[2][1] * p[1][3] * p[3][2] + p[3][1] * p[1][2] * p[2][3] - p[3][1] * p[1][3] * p[2][2];
		R.p[1][0] = -p[1][0] * p[2][2] * p[3][3] + p[1][0] * p[2][3] * p[3][2] + p[2][0] * p[1][2] * p[3][3] - p[2][0] * p[1][3] * p[3][2] - p[3][0] * p[1][2] * p[2][3] + p[3][0] * p[1][3] * p[2][2];
		R.p[2][0] = p[1][0] * p[2][1] * p[3][3] - p[1][0] * p[2][3] * p[3][1] - p[2][0] * p[1][1] * p[3][3] + p[2][0] * p[1][3] * p[3][1] + p[3][0] * p[1][1] * p[2][3] - p[3][0] * p[1][3] * p[2][1];
		R.p[3][0] = -p[1][0] * p[2][1] * p[3][2] + p[1][0] * p[2][2] * p[3][1] + p[2][0] * p[1][1] * p[3][2] - p[2][0] * p[1][2] * p[3][1] - p[3][0] * p[1][1] * p[2][2] + p[3][0] * p[1][2] * p[2][1];
		R.p[0][1] = -p[0][1] * p[2][2] * p[3][3] + p[0][1] * p[2][3] * p[3][2] + p[2][1] * p[0][2] * p[3][3] - p[2][1] * p[0][3] * p[3][2] - p[3][1] * p[0][2] * p[2][3] + p[3][1] * p[0][3] * p[2][2];
		R.p[1][1] = p[0][0] * p[2][2] * p[3][3] - p[0][0] * p[2][3] * p[3][2] - p[2][0] * p[0][2] * p[3][3] + p[2][0] * p[0][3] * p[3][2] + p[3][0] * p[0][2] * p[2][3] - p[3][0] * p[0][3] * p[2][2];
		R.p[2][1] = -p[0][0] * p[2][1] * p[3][3] + p[0][0] * p[2][3] * p[3][1] + p[2][0] * p[0][1] * p[3][3] - p[2][0] * p[0][3] * p[3][1] - p[3][0] * p[0][1] * p[2][3] + p[3][0] * p[0][3] * p[2][1];
		R.p[3][1] = p[0][0] * p[2][1] * p[3][2] - p[0][0] * p[2][2] * p[3][1] - p[2][0] * p[0][1] * p[3][2] + p[2][0] * p[0][2] * p[3][1] + p[3][0] * p[0][1] * p[2][2] - p[3][0] * p[0][2] * p[2][1];
		R.p[0][2] = p[0][1] * p[1][2] * p[3][3] - p[0][1] * p[1][3] * p[3][2] - p[1][1] * p[0][2] * p[3][3] + p[1][1] * p[0][3] * p[3][2] + p[3][1] * p[0][2] * p[1][3] - p[3][1] * p[0][3] * p[1][2];
		R.p[1][2] = -p[0][0] * p[1][2] * p[3][3] + p[0][0] * p[1][3] * p[3][2] + p[1][0] * p[0][2] * p[3][3] - p[1][0] * p[0][3] * p[3][2] - p[3][0] * p[0][2] * p[1][3] + p[3][0] * p[0][3] * p[1][2];
		R.p[2][2] = p[0][0] * p[1][1] * p[3][3] - p[0][0] * p[1][3] * p[3][1] - p[1][0] * p[0][1] * p[3][3] + p[1][0] * p[0][3] * p[3][1] + p[3][0] * p[0][1] * p[1][3] - p[3][0] * p[0][3] * p[1][1];
		R.p[3][2] = -p[0][0] * p[1][1] * p[3][2] + p[0][0] * p[1][2] * p[3][1] + p[1][0] * p[0][1] * p[3][2] - p[1][0] * p[0][2] * p[3][1] - p[3][0] * p[0][1] * p[1][2] + p[3][0] * p[0][2] * p[1][1];
		R.p[0][3] = -p[0][1] * p[1][2] * p[2][3] + p[0][1] * p[1][3] * p[2][2] + p[1][1] * p[0][2] * p[2][3] - p[1][1] * p[0][3] * p[2][2] - p[2][1] * p[0][2] * p[1][3] + p[2][1] * p[0][3] * p[1][2];
		R.p[1][3] = p[0][0] * p[1][2] * p[2][3] - p[0][0] * p[1][3] * p[2][2] - p[1][0] * p[0][2] * p[2][3] + p[1][0] * p[0][3] * p[2][2] + p[2][0] * p[0][2] * p[1][3] - p[2][0] * p[0][3] * p[1][2];
		R.p[2][3] = -p[0][0] * p[1][1] * p[2][3] + p[0][0] * p[1][3] * p[2][1] + p[1][0] * p[0][1] * p[2][3] - p[1][0] * p[0][3] * p[2][1] - p[2][0] * p[0][1] * p[1][3] + p[2][0] * p[0][3] * p[1][1];
		R.p[3][3] = p[0][0] * p[1][1] * p[2][2] - p[0][0] * p[1][2] * p[2][1] - p[1][0] * p[0][1] * p[2][2] + p[1][0] * p[0][2] * p[2][1] + p[2][0] * p[0][1] * p[1][2] - p[2][0] * p[0][2] * p[1][1];
		double det = p[0][0] * R.p[0][0] + p[0][1] * R.p[1][0] + p[0][2] * R.p[2][0] + p[0][3] * R.p[3][0];
		if (det == 0) for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) R.p[i][j] = NAN;
		else for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) R.p[i][j] /= det;
		return R;
	}

	void init() { for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) p[i][j] = i == j ? 1 : 0; }
	void scale(double x, double y, double z) { *this = affine(x, 0, 0, 0, y, 0, 0, 0, z)*(*this); }
	void translate(double x, double y, double z) { *this = affine(1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z, 0, 0, 0, 1)*(*this); }
	void rotate(double x, double y, double z) {
		*this = affine(		// x-y-z
			cos(y)*cos(z), sin(x)*sin(y)*cos(z) - cos(x)*sin(z), cos(x)*sin(y)*cos(z) + sin(x)*sin(z),
			cos(y)*sin(z), sin(x)*sin(y)*sin(z) + cos(x)*cos(z), cos(x)*sin(y)*sin(z) - sin(x)*cos(z),
			-sin(y), sin(x)*cos(y), cos(x)*cos(y))*(*this);
	}
	void rotate_xz(double x, double z) { *this = affine(cos(z), -sin(z), 0, cos(x)*sin(z), cos(x)*cos(z), -sin(x), sin(x)*sin(z), sin(x)*cos(z), cos(x))*(*this); }
};
affine RotationMatrix_xz(double x, double z) { return affine(cos(z), -sin(z), 0, cos(x)*sin(z), cos(x)*cos(z), -sin(x), sin(x)*sin(z), sin(x)*cos(z), cos(x)); }
class point2D {
public:
	double x, y;
	point2D() {}
	template<typename T, typename t> point2D(T x, t y) :x((double)x), y((double)y) {}
	point2D(const point &other) :x(other.x), y(other.y) {}
	point2D& operator = (const point &other) { x = other.x, y = other.y; return *this; }
	~point2D() {}

	void operator -= (const point2D &p) { x -= p.x, y -= p.y; }
};
typedef point vec3;


HWND HWnd;
RECT Client; int clt_w, clt_h;
COLORREF *img; HBITMAP HImg;
point2D Cursor;
bool mouse_down = false; point2D OrigCursor(NAN, NAN);


double rx = -1.2, rz = -0.8, orig_rx = rx, orig_rz = rz;
affine Tr;
double Unit = 70;
void init_mat() {
	Tr.init();
	Tr.rotate_xz(rx, rz);
}
void fix_ang(double &theta) {
	if (!(abs(theta) < 1e+6)) { theta = NAN; return; }
	while (theta < 0) theta += 2 * PI;
	while (theta > 2 * PI) theta -= 2 * PI;
}

point2D fromCoordinate(point P) {
	//P = Tr * P;
	return point2D(P.x * Unit + 0.5*clt_w, P.y * Unit + 0.5*clt_h);
}
point fromCanvas(point2D P) {
	point2D O = fromCoordinate(point(0, 0, 0)), A = fromCoordinate(point(1, 0, 0)), B = fromCoordinate(point(0, 1, 0));
	A -= O, B -= O, P -= O;		// P = O + u*A + v*B  =>  [u v] = [A B].invert * [P-O]
	double a = A.x, b = B.x, c = A.y, d = B.y, det = a * d - b * c;
	A.x = d / det, B.x = -b / det, A.y = -c / det, B.y = a / det;
	return point(A.x*P.x + B.x*P.y, A.y*P.x + B.y*P.y, 0);
}

const vec3 light(0, 0, 1);



class object {
public:
	double cz;
	COLORREF col;
	object() {}
	object(const object &other) { cz = other.cz, col = other.col; }
	virtual ~object() {}
	virtual void transform() = 0 {}
	virtual void fill() = 0 {}
};
class segment : public object {
public:
	point A, B;
	segment() {}
	segment(const point &E1, const point &E2) { A = E1, B = E2, cz = 0.5*(E1.z + E2.z); }
	segment(const point &E1, const point &E2, const COLORREF &col) { A = E1, B = E2, cz = 0.5*(E1.z + E2.z), this->col = col; }
	segment(const segment &other) { A = other.A, B = other.B, cz = other.cz, col = other.col; }
	segment& operator = (const segment &other) { A = other.A, B = other.B, cz = other.cz, col = other.col; return *this; }
	~segment() {}
	virtual void transform() { A = Tr * A, B = Tr * B, cz = 0.5*(A.z + B.z); }
	virtual void fill();
};
class triangle : public object {
public:
	point A, B, C;
	vec3 n;	// normal
	triangle() {}
	triangle(const point &V1, const point &V2, const point &V3) { A = V1, B = V2, C = V3, cz = (V1.z + V2.z + V3.z) / 3; n = cross(B - A, C - A), n.normalize(); }
	triangle(const point &V1, const point &V2, const point &V3, const COLORREF &col) { A = V1, B = V2, C = V3, cz = (V1.z + V2.z + V3.z) / 3; n = cross(B - A, C - A), n.normalize(); this->col = col; }
	triangle(const triangle &other) { A = other.A, B = other.B, C = other.C, cz = other.cz, n = other.n, col = other.col; }
	triangle& operator = (const triangle &other) { A = other.A, B = other.B, C = other.C, cz = other.cz, n = other.n, col = other.col; return *this; }
	~triangle() {}
	virtual void transform() { A = Tr * A, B = Tr * B, C = Tr * C, cz = (A.z + B.z + C.z) / 3; }
	virtual void fill();
};
void drawLine(int x1, int y1, int x2, int y2, COLORREF fill) {
	const int w = clt_w, h = clt_h;
	double slope, intercept; int d;
	if (abs(y2 - y1) < abs(x2 - x1)) {
		if (x1 > x2) swap(x1, x2), swap(y1, y2);
		if (x2 < 0 || (y1 < 0 && y2 < 0)) return;
		if (x1 > int(w) || (y1 > int(h) && y2 > int(h))) return;
		slope = double(y2 - y1) / (x2 - x1);
		intercept = y1 - x1 * slope;
		if (x1 < 0) x1 = 0, y1 = intercept;
		if (x2 > w) x2 = w, y2 = w * slope + intercept;
		if (x1*slope + intercept < 0) x1 = -intercept / slope, y1 = 0;
		else if (x1*slope + intercept > h) x1 = (h - intercept) / slope, y1 = h;
		if (x2*slope + intercept < 0) x2 = -intercept / slope, y2 = 0;
		else if (x2*slope + intercept > h) x2 = (h - intercept) / slope, y2 = h;
		for (int i = x1; i < x2; i++) {
			d = i * slope + intercept;
			if (d >= 0 && d < h) img[d * w + i] = fill;
		}
	}
	else {
		if (y1 > y2) swap(x1, x2), swap(y1, y2);
		if (y2 < 0 || (x1 < 0 && x2 < 0)) return;
		if (y1 > int(h) || (x1 > int(w) && x2 > int(w))) return;
		slope = double(x2 - x1) / (y2 - y1);
		intercept = x1 - y1 * slope;
		if (y1 < 0) y1 = 0, x1 = intercept;
		if (y2 > h) y2 = h, x2 = h * slope + intercept;
		if (y1*slope + intercept < 0) y1 = -intercept / slope, x1 = 0;
		else if (y1*slope + intercept > w) y1 = (w - intercept) / slope, x1 = w;
		if (y2*slope + intercept < 0) y2 = -intercept / slope, x2 = 0;
		else if (y2*slope + intercept > w) y2 = (w - intercept) / slope, x2 = w;
		for (int i = y1; i < y2; i++) {
			d = i * slope + intercept;
			if (d >= 0 && d < w) img[i * w + d] = fill;
		}
	}
}
void fillTrig(int x1, int y1, int x2, int y2, int x3, int y3, COLORREF fill) {
	// http://www.sunshine2k.de/coding/java/TriangleRasterization/TriangleRasterization.html
	auto fillBottomFlatTriangle = [](int x1, int y1, int x2, int y2, int x3, int y3, COLORREF fill) {
		double invslope1 = double(x2 - x1) / double(y2 - y1);
		double invslope2 = double(x3 - x1) / double(y3 - y1);
		if (0 * invslope1 != 0 || 0 * invslope2 != 0) return;
		double curx1 = x1, curx2 = x1; if (0 * curx1 != 0) return;
		int y_min = y1, y_max = y2; if (y_min > y_max) swap(y_min, y_max);
		if (y_min < 0) curx1 -= y_min * invslope1, curx2 -= y_min * invslope2, y_min = 0; if (y_max >= clt_h) y_max = clt_h - 1;
		for (int scanlineY = y_min; scanlineY <= y_max; scanlineY++) {
			int x_min = curx1, x_max = curx2; if (x_min > x_max) swap(x_min, x_max);
			if (x_min < 0) x_min = 0; if (x_max >= clt_w) x_max = clt_w - 1;
			for (int i = x_min; i <= x_max; i++) img[scanlineY*clt_w + i] = fill;
			curx1 += invslope1, curx2 += invslope2;
		}
	};
	auto fillTopFlatTriangle = [](int x1, int y1, int x2, int y2, int x3, int y3, COLORREF fill) {
		float invslope1 = double(x3 - x1) / double(y3 - y1);
		float invslope2 = double(x3 - x2) / double(y3 - y2);
		if (0 * invslope1 != 0 || 0 * invslope2 != 0) return;
		float curx1 = x3, curx2 = x3; if (0 * curx1 != 0) return;
		int y_min = y1, y_max = y3; if (y_min > y_max) swap(y_min, y_max);
		if (y_min < -1) y_min = -1; if (y_max >= clt_h) curx1 -= (y_max - clt_h + 1)*invslope1, curx2 -= (y_max - clt_h + 1)*invslope2, y_max = clt_h - 1;
		for (int scanlineY = y_max; scanlineY > y_min; scanlineY--) {
			int x_min = curx1, x_max = curx2; if (x_min > x_max) swap(x_min, x_max);
			if (x_min < 0) x_min = 0; if (x_max >= clt_w) x_max = clt_w - 1;
			for (int i = x_min; i <= x_max; i++) img[scanlineY*clt_w + i] = fill;
			curx1 -= invslope1, curx2 -= invslope2;
		}
	};
	if (y1 > y2) swap(x1, x2), swap(y1, y2); if (y2 > y3) swap(x2, x3), swap(y2, y3); if (y1 > y2) swap(x1, x2), swap(y1, y2);
	if (y2 == y3) fillBottomFlatTriangle(x1, y1, x2, y2, x3, y3, fill);
	else if (y1 == y2) fillTopFlatTriangle(x1, y1, x2, y2, x3, y3, fill);
	else {
		int x = x1 + (double(y2 - y1) / double(y3 - y1)) * (x3 - x1);
		fillBottomFlatTriangle(x1, y1, x2, y2, x, y2, fill);
		fillTopFlatTriangle(x2, y2, x, y2, x3, y3, fill);
	}
}
void segment::fill() {
	point2D A2 = fromCoordinate(A), B2 = fromCoordinate(B);
	drawLine(A2.x, A2.y, B2.x, B2.y, col);
}
void triangle::fill() {
	point2D A2 = fromCoordinate(A), B2 = fromCoordinate(B), C2 = fromCoordinate(C);
	fillTrig(A2.x, A2.y, B2.x, B2.y, C2.x, C2.y, col);
}


void mergesort_objs(object** s, unsigned N) {	// sort by cz from smallest to largest
	if (N == 1) return;
	if (N == 2) {
		if (s[0]->cz > s[1]->cz) swap(s[0], s[1]);
		return;
	}
	if (N == 3) {
		if (s[0]->cz > s[1]->cz) swap(s[0], s[1]);
		if (s[1]->cz > s[2]->cz) swap(s[1], s[2]);
		if (s[0]->cz > s[1]->cz) swap(s[0], s[1]);
		return;
	}
	unsigned m = N / 2, n = N - m;
	object **u = new object*[m], **v = new object*[n];
	memcpy(u, s, m * sizeof(object*)), memcpy(v, s + m, n * sizeof(object*));
	mergesort_objs(u, m), mergesort_objs(v, n);
	int i, j, k;
	for (i = j = k = 0; i < m && j < n; k++) {
		if (u[i]->cz < v[j]->cz) s[k] = u[i], i++;
		else s[k] = v[j], j++;
	}
	for (; i < m; i++, k++) s[k] = u[i];
	for (; j < n; j++, k++) s[k] = v[j];
	delete u; delete v;
};
void heapsort_objs(object** s, unsigned N) {
	auto adjustHeap = [](object** s, int start, int end) {
		int parent = start, child = parent * 2 + 1;
		while (child <= end) {
			if (child + 1 <= end && s[child]->cz < s[child + 1]->cz) child++;
			if (s[parent]->cz > s[child]->cz) return;
			else swap(s[parent], s[child]), parent = child, child = parent * 2 + 1;
		}
	};
	for (int i = N / 2 - 1; i >= 0; i--) adjustHeap(s, i, N - 1);
	for (int i = N - 1; i > 0; i--) swap(s[0], s[i]), adjustHeap(s, 0, i - 1);
}
void graph() {
	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);

	fill_n(img, clt_w * clt_h, _RGB(0, 0, 0));

	init_mat();
	vec3 v = Tr.invert() * vec3(0, 0, -1);

	double gs = min((u_max - u_min) / u_dif, (v_max - v_min) / v_dif); int Ng = 4 / gs;
	unsigned N = 2 * u_dif * v_dif, M = 2 * Ng, L = N + 3 * M;
	object** sgs = new object*[L];
	for (int i = 0; i < L; i++) sgs[i] = 0;		// make sure there's no nullptr

	// Surface
	for (int i = 0, n = 0; i < u_dif; i++) {
		for (int j = 0; j < v_dif; j++) {
			double u = i * (u_max - u_min) / u_dif + u_min, v = j * (v_max - v_min) / v_dif + v_min, u_ = (i + 1) * (u_max - u_min) / u_dif + u_min, v_ = (j + 1) * (v_max - v_min) / v_dif + v_min;
			point p = point(X(u, v), Y(u, v), Z(u, v)), px = point(X(u_, v), Y(u_, v), Z(u_, v)), py = point(X(u, v_), Y(u, v_), Z(u, v_)), pxy = point(X(u_, v_), Y(u_, v_), Z(u_, v_));
			if (i != u_dif) sgs[n] = new triangle(p, px, py, _RGB(128, 128, 128)), n++;
			if (j != v_dif) sgs[n] = new triangle(pxy, px, py, _RGB(128, 128, 128)), n++;
		}
	}

	// Axis
	for (int i = -Ng, n = N; i < Ng; i++) {
		sgs[n] = new segment(point(1.2*i*gs, 0, 0), point(1.2*(i + 1)*gs, 0, 0), _RGB(255, 0, 0)), n++;
		sgs[n] = new segment(point(0, 1.2*i*gs, 0), point(0, 1.2*(i + 1)*gs, 0), _RGB(0, 128, 0)), n++;
		sgs[n] = new segment(point(0, 0, 0.8*i*gs), point(0, 0, 0.8*(i + 1)*gs), _RGB(0, 0, 255)), n++;
	}


	for (int i = 0; i < N; i++) {
		double a = dot(v - (2 * dot(v, ((triangle*)(sgs[i]))->n))*((triangle*)(sgs[i]))->n, light);
		sgs[i]->col = mix(sgs[i]->col, _RGB(220, 220, 220), a);
	}
	for (int i = 0; i < L; i++) sgs[i]->transform();
	sort_objs(sgs, L);
	for (int i = 0; i < L; i++) sgs[i]->fill();

	for (int i = 0; i < L; i++) delete sgs[i];
	delete sgs;


	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);
}



LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = clt_w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)clt_h : clt_h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};
	switch (message) {
	case WM_CREATE: {
		GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		InitializeClientBitmap(hWnd, HImg, img, false);
		const_cast<vec3*>(&light)->normalize();
		HWnd = hWnd;
		break;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		Unit *= sqrt((clt_w * clt_h) / (prev_w * prev_h));
		DeleteObject(HImg);
		InitializeClientBitmap(hWnd, HImg, img, false);
		graph();
		break;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 600;
		lpMMI->ptMinTrackSize.y = 400;	// set minimum window size
		break;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HDwgMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HDwgMem, HImg);
		BitBlt(hdc, 0, 0, Client.right, Client.bottom, HDwgMem, 0, 0, SRCCOPY);
		SelectObject(HDwgMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HDwgMem);
		DeleteDC(hdc);
		break;
	}
	case WM_MOUSEMOVE: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		if (mouse_down) {	// click and drag
			double dx = Cursor.x - OrigCursor.x, dy = OrigCursor.y - Cursor.y;
			dx /= 100, dy /= 120;
			rx = orig_rx, rz = orig_rz;
			rx += dy, rz += dx;
			graph();
		}
		break;
	}
	case WM_LBUTTONDOWN: {
		mouse_down = true;
		OrigCursor.x = GET_X_LPARAM(lParam);
		OrigCursor.y = clt_h - GET_Y_LPARAM(lParam);
		orig_rx = rx, orig_rz = rz;
		break;
	}
	case WM_LBUTTONUP: {
		mouse_down = false;
		fix_ang(rx), fix_ang(rz);
		OrigCursor = point2D(NAN, NAN);
		break;
	}
	case WM_MOUSEWHEEL: {
		if (mouse_down) break;
		int delta = GET_WHEEL_DELTA_WPARAM(wParam);
		const double MAX = 1e+6, MIN = 1e-8;
		double d = exp(0.0005 * delta);
		if (Unit * d > MAX) d = MAX / Unit;
		else if (Unit * d < MIN) d = MIN / Unit;
		Unit *= d;
		point S = fromCanvas(Cursor);
		graph();
		break;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
	default: {
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	}
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
	const wchar_t CLASS_NAME[] = _T("Rasterization");
	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(16, 20, 23));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = CLASS_NAME;
	if (!RegisterClassEx(&wc)) return -1;

	HWND hWnd = CreateWindowEx(
		0,
		CLASS_NAME,
		CLASS_NAME,
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		900, 600,
		NULL, NULL, hInstance, NULL
	);
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	return (int)message.wParam;
}
