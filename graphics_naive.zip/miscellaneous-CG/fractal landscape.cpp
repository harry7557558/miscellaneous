#ifndef UNICODE
#define UNICODE
#endif

#pragma warning(disable:4244 4018 4010)

#include <Windows.h>
#include <windowsx.h>
#include <tchar.h>

using namespace std;

#define _RGB(r,g,b) ((COLORREF)(((BYTE)(b)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(r))<<16)))
COLORREF mix(COLORREF a, COLORREF b, double r) { return _RGB((1 - r)*((BYTE*)&a)[2] + r * ((BYTE*)&b)[2], (1 - r)*((BYTE*)&a)[1] + r * ((BYTE*)&b)[1], (1 - r)*(BYTE)a + r * (BYTE)b); }
typedef struct { double r, g, b; } COLORf;
#define toCOLORREF(col) _RGB(255*max(min(col.r,1),0),255*max(min(col.g,1),0),255*max(min(col.b,1),0))
COLORf RGBf(const double &r, const double &g, const double &b) { COLORf c; c.r = r, c.g = g, c.b = b; return c; }
COLORf RGBf(const double &g) { COLORf c; c.r = c.g = c.b = g; return c; }
COLORf operator + (const COLORf &a, const COLORf &b) { return RGBf(a.r + b.r, a.g + b.g, a.b + b.b); }
void operator += (COLORf &a, const COLORf &b) { a.r += b.r, a.g += b.g, a.b += b.b; }
void operator -= (COLORf &a, const COLORf &b) { a.r -= b.r, a.g -= b.g, a.b -= b.b; }
COLORf operator * (const double &a, const COLORf &b) { return RGBf(a*b.r, a*b.g, a*b.b); }


#ifdef _DEBUG
#define Fill_N(First,Count,Val) for (unsigned i = 0, l = clt_w * clt_h; i < l; i++) First[i] = Val;
#include <cstdlib>
#include <crtdbg.h>
#define CheckMemoryLeaks _CrtDumpMemoryLeaks();
#define BreakOn(t) _CrtSetBreakAlloc(t);
#define sort_objs mergesort_objs
#else
#include <memory>
#define Fill_N(First,Count,Val) uninitialized_fill_n(First, Count, Val)
#define CheckMemoryLeaks { }
#define BreakOn(t) { }
#define sort_objs MultiThreadSort_objs
#endif

#include <iostream>
#include <sstream>
#define DBGLOG(s) { std::wostringstream os_; os_ << s; OutputDebugStringW( os_.str().c_str() ); }	// log to Visual Studio output window


#include "3D.h"


HWND HWnd;
RECT Client; int clt_w, clt_h;
COLORREF *img; HBITMAP HImg;



class segment {
public:
	double cz; COLORf col;
	vec3 A, B;
	segment() {}
	segment(const vec3 &E1, const vec3 &E2) { A = E1, B = E2, cz = 0.5*(E1.z + E2.z); }
	segment(const vec3 &E1, const vec3 &E2, const COLORf &col) { A = E1, B = E2, cz = 0.5*(E1.z + E2.z), this->col = col; }
	segment(const segment &other) { A = other.A, B = other.B, cz = other.cz, col = other.col; }
	segment& operator = (const segment &other) { A = other.A, B = other.B, cz = other.cz, col = other.col; return *this; }
	~segment() {}
};
class triangle {
public:
	double cz; COLORf col;
	vec3 A, B, C;
	vec3 n;	// normal
	triangle() {}
	triangle(const vec3 &V1, const vec3 &V2, const vec3 &V3) { A = V1, B = V2, C = V3, cz = (V1.z + V2.z + V3.z) / 3; n = cross(B - A, C - A).unitvec(); }
	triangle(const vec3 &V1, const vec3 &V2, const vec3 &V3, const COLORf &col) { A = V1, B = V2, C = V3, cz = (V1.z + V2.z + V3.z) / 3; n = cross(B - A, C - A).unitvec(); this->col = col; }
	triangle(const triangle &other) { A = other.A, B = other.B, C = other.C, cz = other.cz, n = other.n, col = other.col; }
	triangle& operator = (const triangle &other) { A = other.A, B = other.B, C = other.C, cz = other.cz, n = other.n, col = other.col; return *this; }
	~triangle() {}
};
void drawLine(int x1, int y1, int x2, int y2, COLORREF fill) {
	const int w = clt_w, h = clt_h;
	double slope, intercept; int d;
	if (abs(y2 - y1) < abs(x2 - x1)) {
		if (x1 > x2) swap(x1, x2), swap(y1, y2);
		if (x2 < 0 || (y1 < 0 && y2 < 0)) return;
		if (x1 > int(w) || (y1 > int(h) && y2 > int(h))) return;
		slope = double(y2 - y1) / (x2 - x1);
		intercept = y1 - x1 * slope;
		if (x1 < 0) x1 = 0, y1 = intercept;
		if (x2 > w) x2 = w, y2 = w * slope + intercept;
		if (x1*slope + intercept < 0) x1 = -intercept / slope, y1 = 0;
		else if (x1*slope + intercept > h) x1 = (h - intercept) / slope, y1 = h;
		if (x2*slope + intercept < 0) x2 = -intercept / slope, y2 = 0;
		else if (x2*slope + intercept > h) x2 = (h - intercept) / slope, y2 = h;
		for (int i = x1; i < x2; i++) {
			d = i * slope + intercept;
			if (d >= 0 && d < h) img[d * w + i] = fill;
		}
	}
	else {
		if (y1 > y2) swap(x1, x2), swap(y1, y2);
		if (y2 < 0 || (x1 < 0 && x2 < 0)) return;
		if (y1 > int(h) || (x1 > int(w) && x2 > int(w))) return;
		slope = double(x2 - x1) / (y2 - y1);
		intercept = x1 - y1 * slope;
		if (y1 < 0) y1 = 0, x1 = intercept;
		if (y2 > h) y2 = h, x2 = h * slope + intercept;
		if (y1*slope + intercept < 0) y1 = -intercept / slope, x1 = 0;
		else if (y1*slope + intercept > w) y1 = (w - intercept) / slope, x1 = w;
		if (y2*slope + intercept < 0) y2 = -intercept / slope, x2 = 0;
		else if (y2*slope + intercept > w) y2 = (w - intercept) / slope, x2 = w;
		for (int i = y1; i < y2; i++) {
			d = i * slope + intercept;
			if (d >= 0 && d < w) img[i * w + d] = fill;
		}
	}
}
void fillTrig(int x1, int y1, int x2, int y2, int x3, int y3, COLORREF fill) {
	// http://www.sunshine2k.de/coding/java/TriangleRasterization/TriangleRasterization.html
	auto fillBottomFlatTriangle = [](int x1, int y1, int x2, int y2, int x3, int y3, COLORREF fill) {
		double invslope1 = double(x2 - x1) / double(y2 - y1);
		double invslope2 = double(x3 - x1) / double(y3 - y1);
		if (0 * invslope1 != 0 || 0 * invslope2 != 0) return;
		double curx1 = x1, curx2 = x1; if (0 * curx1 != 0) return;
		int y_min = y1, y_max = y2; if (y_min > y_max) swap(y_min, y_max);
		if (y_min < 0) curx1 -= y_min * invslope1, curx2 -= y_min * invslope2, y_min = 0; if (y_max >= clt_h) y_max = clt_h - 1;
		for (int scanlineY = y_min; scanlineY <= y_max; scanlineY++) {
			int x_min = curx1, x_max = curx2; if (x_min > x_max) swap(x_min, x_max);
			if (x_min < 0) x_min = 0; if (x_max >= clt_w) x_max = clt_w - 1;
			for (int i = x_min; i <= x_max; i++) img[scanlineY*clt_w + i] = fill;
			curx1 += invslope1, curx2 += invslope2;
		}
	};
	auto fillTopFlatTriangle = [](int x1, int y1, int x2, int y2, int x3, int y3, COLORREF fill) {
		double invslope1 = double(x3 - x1) / double(y3 - y1);
		double invslope2 = double(x3 - x2) / double(y3 - y2);
		if (0 * invslope1 != 0 || 0 * invslope2 != 0) return;
		double curx1 = x3, curx2 = x3; if (0 * curx1 != 0) return;
		int y_min = y1, y_max = y3; if (y_min > y_max) swap(y_min, y_max);
		if (y_min < -1) y_min = -1; if (y_max >= clt_h) curx1 -= (y_max - clt_h + 1)*invslope1, curx2 -= (y_max - clt_h + 1)*invslope2, y_max = clt_h - 1;
		for (int scanlineY = y_max; scanlineY > y_min; scanlineY--) {
			int x_min = curx1, x_max = curx2; if (x_min > x_max) swap(x_min, x_max);
			if (x_min < 0) x_min = 0; if (x_max >= clt_w) x_max = clt_w - 1;
			for (int i = x_min; i <= x_max; i++) img[scanlineY*clt_w + i] = fill;
			curx1 -= invslope1, curx2 -= invslope2;
		}
	};
	if (y1 > y2) swap(x1, x2), swap(y1, y2); if (y2 > y3) swap(x2, x3), swap(y2, y3); if (y1 > y2) swap(x1, x2), swap(y1, y2);
	if (y2 == y3) fillBottomFlatTriangle(x1, y1, x2, y2, x3, y3, fill);
	else if (y1 == y2) fillTopFlatTriangle(x1, y1, x2, y2, x3, y3, fill);
	else {
		int x = x1 + (double(y2 - y1) / double(y3 - y1)) * (x3 - x1);
		fillBottomFlatTriangle(x1, y1, x2, y2, x, y2, fill);
		fillTopFlatTriangle(x2, y2, x, y2, x3, y3, fill);
	}
}


// different sorting methods
#include <thread>
const unsigned Recursion_Depth = log2(thread::hardware_concurrency());	// 3 on my computer
template<typename T> void mergesort_objs(T** s, unsigned N) {
	if (N == 1) return;
	if (N == 2) {
		if (s[0]->cz > s[1]->cz) swap(s[0], s[1]);
		return;
	}
	if (N == 3) {
		if (s[0]->cz > s[1]->cz) swap(s[0], s[1]);
		if (s[1]->cz > s[2]->cz) swap(s[1], s[2]);
		if (s[0]->cz > s[1]->cz) swap(s[0], s[1]);
		return;
	}
	unsigned m = N / 2, n = N - m;
	T **u = new T*[m], **v = new T*[n];
	memcpy(u, s, m * sizeof(T*)), memcpy(v, s + m, n * sizeof(T*));
	mergesort_objs(u, m), mergesort_objs(v, n);
	int i, j, k;
	for (i = j = k = 0; i < m && j < n; k++) {
		if (u[i]->cz < v[j]->cz) s[k] = u[i], i++;
		else s[k] = v[j], j++;
	}
	for (; i < m; i++, k++) s[k] = u[i];
	for (; j < n; j++, k++) s[k] = v[j];
	delete[] u; delete[] v;
};
template<typename T> void heapsort_objs(T** s, unsigned N) {
	auto adjustHeap = [](T** s, int start, int end) {
		int parent = start, child = parent * 2 + 1;
		while (child <= end) {
			if (child + 1 <= end && s[child]->cz < s[child + 1]->cz) child++;
			if (s[parent]->cz > s[child]->cz) return;
			else swap(s[parent], s[child]), parent = child, child = parent * 2 + 1;
		}
	};
	for (int i = N / 2 - 1; i >= 0; i--) adjustHeap(s, i, N - 1);
	for (int i = N - 1; i > 0; i--) swap(s[0], s[i]), adjustHeap(s, 0, i - 1);
}
template<typename T> void MultiThreadSort_objs(T** s, UINT64 N) {	// variation of merge sort, I don't know why it's only about twice faster than heap sort
	unsigned depth = N >> 32;	// stack depth is compressed into a single integer
	if (depth >= Recursion_Depth || N < 1024) {
		mergesort_objs(s, N); return;
	}
	N &= UINT32(-1);
	unsigned m = N / 2, n = N - m;
	T **u = new T*[m], **v = new T*[n];
	memcpy(u, s, m * sizeof(T*)), memcpy(v, s + m, n * sizeof(T*));
	thread T1([&](T** s, UINT64 N) { MultiThreadSort_objs(s, N); }, u, UINT64(m) | (UINT64(depth + 1) << 32));
	thread T2([&](T** s, UINT64 N) { MultiThreadSort_objs(s, N); }, v, UINT64(n) | (UINT64(depth + 1) << 32));
	T1.join(), T2.join();
	int i, j, k;
	for (i = j = k = 0; i < m && j < n; k++) {
		if (u[i]->cz < v[j]->cz) s[k] = u[i], i++;
		else s[k] = v[j], j++;
	}
	for (; i < m; i++, k++) s[k] = u[i];
	for (; j < n; j++, k++) s[k] = v[j];
	delete[] u; delete[] v;
}
template<typename T> void MultiThreadSort_objs_2(T** s, unsigned N) {
	if (N < 1024) { mergesort_objs(s, N); return; }
	const unsigned D = thread::hardware_concurrency();
	unsigned m = N / D, n = N - (D - 1) * m;
	T*** u = new T**[D]; thread** th = new thread*[D]; int *f = new int[D];
	for (int i = 0; i < D; i++) {
		unsigned sz = i == D - 1 ? n : m;
		u[i] = new T*[sz];
		memcpy(u[i], s + i * n, sz * sizeof(T*));
		f[i] = 0;
		th[i] = new thread([&](T** s, unsigned N, int *f) { mergesort_objs(s, N); *f = 1; }, u[i], sz, f + i);
		th[i]->detach();
	}

	bool finished = 0; do {
		Sleep(1);
		finished = 1;
		for (int i = 0; i < D; i++) if (!f[i]) { finished = 0; break; }
	} while (!finished);

	for (int i = 0; i < D; i++) delete th[i]; delete th;
	for (int i = 0; i < D; i++) f[i] = i == D - 1 ? n - 1 : m - 1;

	int max_dir; double max_val;
	for (int d = N - 1; d >= 0; d--) {
		max_val = -INFINITY;
		for (int i = 0; i < D; i++) {
			if (f[i] >= 0 && u[i][f[i]]->cz > max_val) max_val = u[i][f[i]]->cz, max_dir = i;
		}
		s[d] = u[max_dir][f[max_dir]]; f[max_dir]--;
	}

	delete f;
	for (int i = 0; i < D; i++) delete u[i]; delete u;

}



// Reference: https://web.williams.edu/Mathematics/sjmiller/public_html/hudson/Dickerson_Terrain.pdf
const double Width = 1000;		// geometrical dimension in meters
const double min_size = 1;	// minimum side length in meters
const unsigned Iter = log2(Width / min_size);		// number of iterations
const unsigned N = 1 << Iter;	// number of sub-sections per side
const double S = Width / N;	// side length
const double Initial_Elevation = 0;
const double A = 500;	// Amplitude
const double H = 1;		// Smoothing
double** T = 0;		// heightfield

COLORf colorf(double t) {	// fitted from Mathematica color function "rainbow", 0<t<1
	double r = (((((33.2244 * t - 100.59) * t + 115.781) * t - 67.2886) * t + 23.2038) * t - 3.95569) * t + 0.495532,
		g = (((((40.0115 * t - 129.052) * t + 160.522) * t - 97.563) * t + 27.4201) * t - 1.35831) * t + 0.120199,
		b = (((((32.1251 * t - 102.898) * t + 117.668) * t - 52.4257) * t + 2.94278) * t + 2.19122) * t + 0.517757;
	if (r > 1) r = 1; if (g > 1) g = 1; if (b > 1) b = 1; if (r < 0) r = 0; if (g < 0) g = 0; if (b < 0) b = 0;
	return RGBf(r, g, b);
}


void Midpoint_Displacement() {
	//if (n == 1) T[0][0] = A * pick_random(-1, 1), T[N][0] = A * pick_random(-1, 1), \
		T[0][N] = A * pick_random(-1, 1), T[N][N] = A * pick_random(-1, 1);
	auto displaceN = [](unsigned n) {
		auto divide = [](unsigned x0, unsigned x1, unsigned y0, unsigned y1, unsigned n) {
			unsigned xm = (x0 + x1) / 2, ym = (y0 + y1) / 2;
			double At = A * exp2(-H * n);
			if (T[xm][y0] == Initial_Elevation) T[xm][y0] = 0.5*(T[x0][y0] + T[x1][y0]) + pick_random(-1, 1) * At;
			if (T[xm][y1] == Initial_Elevation) T[xm][y1] = 0.5*(T[x0][y1] + T[x1][y1]) + pick_random(-1, 1) * At;
			if (T[x0][ym] == Initial_Elevation) T[x0][ym] = 0.5*(T[x0][y0] + T[x0][y1]) + pick_random(-1, 1) * At;
			if (T[x1][ym] == Initial_Elevation) T[x1][ym] = 0.5*(T[x1][y0] + T[x1][y1]) + pick_random(-1, 1) * At;
			T[xm][ym] = 0.25*(T[x0][y0] + T[x0][y1] + T[x1][y0] + T[x1][y1]) + pick_random(-1, 1) * At;
		};
		unsigned m = 1 << (Iter - n), k = N / m;
		for (int i = 0; i < k; i++) for (int j = 0; j < k; j++)
			divide(i*m, (i + 1)*m, j*m, (j + 1)*m, n + 1);
	};
	for (int n = 0; n < Iter; n++) displaceN(n);
}
void Diamond_Square() {
	auto diamond = [](unsigned n) {
		double At = A * pow(N / n, -H);
		for (int i = n; i < N; i += 2 * n) for (int j = n; j < N; j += 2 * n)
			T[i][j] = (T[i - n][j - n] + T[i - n][j + n] + T[i + n][j - n] + T[i + n][j + n]) / 4 + pick_random(-1, 1) * At;
	};
	auto square = [](unsigned n) {
		double At = A * pow(N / n, -H);
		for (int i = 0; i <= N; i += n) for (int j = 0; j <= N; j += n)
			//if (!((i == 0 || i == N) && (j == 0 || j == N)) && (((i / n) & 1) || ((j / n) & 1))) {
			if (!((i == 0 || i == N) && (j == 0 || j == N)) && T[i][j] == Initial_Elevation) {
				if (i == 0) T[i][j] = (T[i][j + n] + T[i][j - n] + T[i + n][j]) / 3;
				else if (i == N) T[i][j] = (T[i][j + n] + T[i][j - n] + T[i - n][j]) / 3;
				else if (j == 0) T[i][j] = (T[i][j + n] + T[i + n][j] + T[i - n][j]) / 3;
				else if (j == N) T[i][j] = (T[i][j - n] + T[i + n][j] + T[i - n][j]) / 3;
				else T[i][j] = (T[i][j + n] + T[i][j - n] + T[i + n][j] + T[i - n][j]) / 4;
				T[i][j] += pick_random(-1, 1) * At;
			}
	};
	//T[0][0] = A * pick_random(-1, 1), T[N][0] = A * pick_random(-1, 1), \
		T[0][N] = A * pick_random(-1, 1), T[N][N] = A * pick_random(-1, 1);
	for (int n = Iter - 1; n >= 0; n--) {
		diamond(1 << n);
		square(1 << n);
	}
}
void Fractal_Noise() {	// debugging
	const double e = 3 - H;	// 0≤H<2
	double ux = pick_random(1, 2 * PI), vx = pick_random(1, 2 * PI);
	double sx = pick_random(-0.5, 0.5), tx = pick_random(-0.5, 0.5);
	double uy = pick_random(1, 2 * PI), vy = pick_random(1, 2 * PI);
	double sy = pick_random(-0.5, 0.5), ty = pick_random(-0.5, 0.5);
	unsigned It = 2 * Iter * log(2) / log(e);	// not exact
	double x, y, a;
#define Noise(x,y) ((sx*sin(ux*(x))+tx*cos(vx*(x)))*(sy*sin(uy*(y))+ty*cos(vy*(y))))
	for (int i = 0; i <= N; i++) {
		for (int j = 0; j <= N; j++) {
			x = double(i) / N, y = double(j) / N, a = 1;
			for (int n = 0; n < It; n++) {
				T[i][j] += Noise(x, y) / a;
				x *= e, y *= e, a *= e;
			}
			T[i][j] *= A;
		}
	}
#undef Noise
}
void GenerateTerrain() {
	T = new double*[N + 1];
	for (unsigned i = 0; i <= N; i++) {
		T[i] = new double[N + 1];
		for (unsigned j = 0; j <= N; j++) T[i][j] = Initial_Elevation;
	}
	setRandomNumberSeed(0.01);
	Midpoint_Displacement();
	//Diamond_Square();
	//Fractal_Noise();
}


double rx = -0.8, rz = -1.2, orig_rx = rx, orig_rz = rz;
double Unit = 0.5;
vec2 Cursor(NAN, NAN), OrigCursor(Cursor); bool mouse_down;

#define render RenderShaded


// Wireframes
segment** wfs = 0; const unsigned wfs_N = 2 * N * (N + 1);
void ConstructWireframes() {
	double min_z = INFINITY, max_z = -INFINITY;
	for (int i = 0; i <= N; i++) for (int j = 0; j <= N; j++) min_z = min(min_z, T[i][j]), max_z = max(max_z, T[i][j]);
	double dz = max_z - min_z;

	wfs = new segment*[wfs_N];
	for (int i = 0, n = 0; i <= N; i++) {
		for (int j = 0; j <= N; j++) {
			if (i != N) wfs[n] = new segment(vec3(i*S, j*S, T[i][j]), vec3((i + 1)*S, j*S, T[i + 1][j]),
				colorf((0.5*(T[i][j] + T[i + 1][j]) - min_z) / dz)), n++;
			if (j != N) wfs[n] = new segment(vec3(i*S, j*S, T[i][j]), vec3(i*S, (j + 1)*S, T[i][j + 1]),
				colorf((0.5*(T[i][j] + T[i][j + 1]) - min_z) / dz)), n++;
		}
	}
}
void RenderWireframes() {
	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);
	fill_n(img, clt_w * clt_h, _RGB(0, 0, 0));

	if (wfs == 0) ConstructWireframes();

	segment** WFS = new segment*[wfs_N];
	double HalfWidth = 0.5 * Width;
	mat3 M; M.rotate_xz(rx, rz);
	for (int i = 0; i < wfs_N; i++) {
		WFS[i] = new segment(*wfs[i]);
		WFS[i]->A.x -= HalfWidth, WFS[i]->B.x -= HalfWidth; WFS[i]->A.y -= HalfWidth, WFS[i]->B.y -= HalfWidth;
		WFS[i]->A = M * WFS[i]->A, WFS[i]->B = M * WFS[i]->B, WFS[i]->cz = 0.5*(WFS[i]->A.z + WFS[i]->B.z);
	}

	sort_objs(WFS, wfs_N);
	for (int i = 0; i < wfs_N; i++) {
		drawLine(Unit*WFS[i]->A.x + clt_w / 2, Unit*WFS[i]->A.y + clt_h / 2,
			Unit*WFS[i]->B.x + clt_w / 2, Unit*WFS[i]->B.y + clt_h / 2, toCOLORREF(WFS[i]->col));
	}

	for (int i = 0; i < wfs_N; i++) delete WFS[i];
	delete WFS;

	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);
}


// Shaded, try different algorithms
#define Z_BUFFER 1
triangle **sds = 0, **SDS = 0; const unsigned sds_N = 2 * N * N;
const vec3 light = vec3(-0.5, -0.6, 1.0).unitvec();
double* ZB = 0;
void ConstructShaded() {
	double min_z = INFINITY, max_z = -INFINITY;
	for (int i = 0; i <= N; i++) for (int j = 0; j <= N; j++) min_z = min(min_z, T[i][j]), max_z = max(max_z, T[i][j]);
	double dz = max_z - min_z;

	sds = new triangle*[sds_N];
	for (int i = 0, n = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			if (abs(T[i + 1][j + 1] - T[i][j]) < abs(T[i][j + 1] - T[i + 1][j])) {
				sds[n] = new triangle(vec3(i*S, j*S, T[i][j]), vec3((i + 1)*S, (j + 1)*S, T[i + 1][j + 1]), vec3(i*S, (j + 1)*S, T[i][j + 1]),
					colorf((0.3*(T[i][j] + T[i][j + 1] + T[i + 1][j + 1]) - min_z) / dz)), n++;
				sds[n] = new triangle(vec3(i*S, j*S, T[i][j]), vec3((i + 1)*S, j*S, T[i + 1][j]), vec3((i + 1)*S, (j + 1)*S, T[i + 1][j + 1]),
					colorf((0.3*(T[i][j] + T[i + 1][j] + T[i + 1][j + 1]) - min_z) / dz)), n++;
			}
			else {
				sds[n] = new triangle(vec3(i*S, j*S, T[i][j]), vec3((i + 1)*S, j*S, T[i + 1][j]), vec3(i*S, (j + 1)*S, T[i][j + 1]),
					colorf((0.3*(T[i][j] + T[i][j + 1] + T[i + 1][j]) - min_z) / dz)), n++;
				sds[n] = new triangle(vec3((i + 1)*S, (j + 1)*S, T[i + 1][j + 1]), vec3(i*S, (j + 1)*S, T[i][j + 1]), vec3((i + 1)*S, j*S, T[i + 1][j]),
					colorf((0.3*(T[i][j + 1] + T[i + 1][j] + T[i + 1][j + 1]) - min_z) / dz)), n++;
			}
		}
	}

	double HalfWidth = 0.5*Width;
	for (int i = 0; i < sds_N; i++) {
		sds[i]->A.x -= HalfWidth, sds[i]->B.x -= HalfWidth, sds[i]->C.x -= HalfWidth;
		sds[i]->A.y -= HalfWidth, sds[i]->B.y -= HalfWidth, sds[i]->C.y -= HalfWidth;
	}
}
void RenderShaded() {
	//rx = rz = 1e-6, Unit = 0.5;
	HDC hdc = GetDC(HWnd);
	HDC HImgMem = CreateCompatibleDC(hdc);
	HBITMAP hbmOld = (HBITMAP)SelectObject(HImgMem, HImg);
	fill_n(img, clt_w * clt_h, _RGB(0, 0, 0));

	if (sds == 0) ConstructShaded();
	if (SDS == 0) {
		SDS = new triangle*[sds_N];
		for (int i = 0; i < sds_N; i++) SDS[i] = new triangle;
	}

	mat3 M; M.rotate_xz(rx, rz);
	vec3 _light = M * light;
	for (int i = 0; i < sds_N; i++) {
		SDS[i]->A = M * sds[i]->A, SDS[i]->B = M * sds[i]->B, SDS[i]->C = M * sds[i]->C;
		SDS[i]->n = M * sds[i]->n;
		SDS[i]->cz = (SDS[i]->A.z + SDS[i]->B.z + SDS[i]->C.z) / 3;
		SDS[i]->col = max(dot(SDS[i]->n, _light), 0) * sds[i]->col;
	}



#if PAINTERS_ALGO	// about 5 fps on my computer

	sort_objs(SDS, sds_N);	// most time-wasting process
	for (int i = 0; i < sds_N; i++) {
		fillTrig(Unit*SDS[i]->A.x + clt_w / 2, Unit*SDS[i]->A.y + clt_h / 2,
			Unit*SDS[i]->B.x + clt_w / 2, Unit*SDS[i]->B.y + clt_h / 2, Unit*SDS[i]->C.x + clt_w / 2, Unit*SDS[i]->C.y + clt_h / 2, toCOLORREF(SDS[i]->col));
	}

#elif Z_BUFFER	// 12-14 fps in multithread and 5 fps in single thread (8 fps on power save mode)

	if (ZB == 0) ZB = new double[clt_w*clt_h];
	Fill_N(ZB, clt_w*clt_h, -INFINITY);

	// similar as "fillTrig"
	auto fillTrigInZBuffer = [](triangle &T, COLORREF fill) {
#define Floor(x) ((x)>0?int(x):int((x)-0.999999))
#define Ceil(x) ((x)>0?int((x)+0.999999):int(x))
		if (T.n.z == 0) return;
		double x1 = T.A.x, y1 = T.A.y, x2 = T.B.x, y2 = T.B.y, x3 = T.C.x, y3 = T.C.y;
		double a = -T.n.x / T.n.z, b = -T.n.y / T.n.z, c = (T.n.x*T.A.x + T.n.y*T.A.y) / T.n.z + T.A.z;		// triangle's plane's equation is z=ax+by+c

		if (y1 > y2) swap(x1, x2), swap(y1, y2); if (y2 > y3) swap(x2, x3), swap(y2, y3); if (y1 > y2) swap(x1, x2), swap(y1, y2);

		/*auto inTriangle = [](int px, int py, double x1, double y1, double x2, double y2, double x3, double y3) -> bool {
			x1 -= px, x2 -= px, x3 -= px; y1 -= py, y2 -= py, y3 -= py;
			return (int(x1 * y2 - x2 * y1 > 0) + int(x2 * y3 - x3 * y2 > 0) + int(x3 * y1 - x1 * y3 > 0)) % 3 == 0;
		};*/
		auto inTriangle = [](const int &px, const int &py, const double &x1, const double &y1, const double &x2, const double &y2, const double &x3, const double &y3) -> bool {
			return !((char((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py) > 0) + char((x2 - px) * (y3 - py) - (x3 - px) * (y2 - py) > 0) + char((x3 - px) * (y1 - py) - (x1 - px) * (y3 - py) > 0)) % 3);
		};

		double xm = x1 + ((y2 - y1) / (y3 - y1)) * (x3 - x1);
		double mind, maxd;
		if (y1 != y2) {	// fill bottom-flat triangle
			double bk_x3 = x3, bk_y3 = y3; x3 = xm, y3 = y2;
			double invslope1 = (x2 - x1) / (y2 - y1), invslope2 = (x3 - x1) / (y3 - y1);
			if (isNaN(invslope1) || isNaN(invslope2)) return;
			double curx1 = x1, curx2 = x1; if (0 * curx1 != 0) return;
			mind = y1, maxd = y2; if (mind > maxd) swap(mind, maxd); int y_min = Floor(mind), y_max = Ceil(maxd);
			if (y_min < 0) y_min = 0; if (y_max >= clt_h) y_max = clt_h - 1;
			mind = y_min - mind; curx1 += mind * invslope1, curx2 += mind * invslope2;
			for (int y = y_min; y <= y_max; y++) {
				mind = curx1, maxd = curx2; if (mind > maxd) swap(mind, maxd); int x_min = Floor(mind), x_max = Ceil(maxd);
				if (x_min < 0) x_min = 0; if (x_max >= clt_w) x_max = clt_w - 1;
				for (int x = x_min, dr = y * clt_w + x_min; x <= x_max; x++, dr++) {
					if ((x != x_min && y != y_min && x != x_max && y != y_max) || inTriangle(x, y, x1, y1, x2, y2, x3, y3)) {
						double z = a * x + b * y + c;
						if (z > ZB[dr]) img[dr] = fill, ZB[dr] = z;
					}
				}
				curx1 += invslope1, curx2 += invslope2;
			}
			x3 = bk_x3, y3 = bk_y3;
		}
		if (y2 != y3) {	// fill top-flat triangle
			x1 = x2, y1 = y2, x2 = xm;
			double invslope1 = (x3 - x1) / (y3 - y1), invslope2 = (x3 - x2) / (y3 - y2);
			if (isNaN(invslope1) || isNaN(invslope2)) return;
			double curx1 = x3, curx2 = x3; if (0 * curx1 != 0) return;
			mind = y1, maxd = y3; if (mind > maxd) swap(mind, maxd); int y_min = Floor(mind), y_max = Ceil(maxd);
			if (y_min < -1) y_min = -1; if (y_max >= clt_h) y_max = clt_h - 1;
			maxd = y_max - maxd; curx1 += maxd * invslope1, curx2 += maxd * invslope2;
			for (int y = y_max; y > y_min; y--) {
				mind = curx1, maxd = curx2; if (mind > maxd) swap(mind, maxd); int x_min = Floor(mind), x_max = Ceil(maxd);
				if (x_min < 0) x_min = 0; if (x_max >= clt_w) x_max = clt_w - 1;
				for (int x = x_min, dr = y * clt_w + x_min; x <= x_max; x++, dr++) {
					if ((x != x_min && y != y_min && x != x_max && y != y_max) || inTriangle(x, y, x1, y1, x2, y2, x3, y3)) {
						double z = a * x + b * y + c;
						if (z > ZB[dr]) img[dr] = fill, ZB[dr] = z;
					}
				}
				curx1 -= invslope1, curx2 -= invslope2;
			}
		}
	};


	// single thread
	/*vec2 dr(clt_w / 2, clt_h / 2);
	for (int i = 0; i < sds_N; i++) {
		SDS[i]->A *= Unit, SDS[i]->B *= Unit, SDS[i]->C *= Unit; SDS[i]->A += dr, SDS[i]->B += dr, SDS[i]->C += dr;
		fillTrigInZBuffer(*SDS[i], toCOLORREF(SDS[i]->col));
	}*/

	// multi-thread
	const unsigned D = thread::hardware_concurrency();
	unsigned m = sds_N / D, n = sds_N - (D - 1) * m;
	thread** th = new thread*[D]; bool *f = new bool[D];
	for (int i = 0; i < D; i++) {
		unsigned sz = i == D - 1 ? n : m;
		f[i] = false;
		th[i] = new thread([&](unsigned beg, unsigned end, bool *f) {
			vec2 dr(clt_w / 2, clt_h / 2);
			for (int i = beg; i < end; i++) {
				SDS[i]->A *= Unit, SDS[i]->B *= Unit, SDS[i]->C *= Unit; SDS[i]->A += dr, SDS[i]->B += dr, SDS[i]->C += dr;
				fillTrigInZBuffer(*SDS[i], toCOLORREF(SDS[i]->col));
			}
			*f = true;
		}, m * i, m * i + sz, f + i);
		th[i]->detach();
	}

	bool finished = 0; do {
		Sleep(1);
		finished = 1;
		for (int i = 0; i < D; i++) if (!f[i]) { finished = 0; break; }
	} while (!finished);

	delete f;
	for (int i = 0; i < D; i++) delete th[i]; delete th;



#endif


	segment x_axis(M * vec3(0, 0, 0), M * vec3(1, 0, 0), RGBf(1, 0, 0));
	segment y_axis(M * vec3(0, 0, 0), M * vec3(0, 1, 0), RGBf(0, 0.5, 0));
	segment z_axis(M * vec3(0, 0, 0), M * vec3(0, 0, 1), RGBf(0, 0, 1));
	segment light_axis(M*vec3(0, 0, 0), M*light, RGBf(1, 1, 0));
	auto drawAxis = [](segment axis) {
		axis.A *= 50, axis.B *= 50;
		axis.A += vec3(80, clt_h - 80, 0), axis.B += vec3(80, clt_h - 80, 0);
		drawLine(axis.A.x, axis.A.y, axis.B.x, axis.B.y, toCOLORREF(axis.col));
	};
	segment* p[4] = { &x_axis, &y_axis, &z_axis, &light_axis };
	sort_objs(p, 4);
	for (int i = 0; i < 4; i++) drawAxis(*p[i]);


	BitBlt(hdc, 0, 0, clt_w, clt_h, HImgMem, 0, 0, SRCCOPY);
	SelectObject(HImgMem, hbmOld);
	DeleteDC(HImgMem);
	DeleteDC(hdc);

	//saveBitmap(img, clt_w, clt_h, "C:\\Users\\harry\\Desktop\\Test\\Test.bmp"); exit(0);
	}




void destruct() {
	if (T != 0) {
		for (unsigned i = 0; i <= N; i++) if (T[i] != 0) delete T[i], T[i] = 0;
		delete T; T = 0;
	}
	if (wfs != 0) {
		for (unsigned i = 0; i < wfs_N; i++) if (wfs[i] != 0) delete wfs[i], wfs[i] = 0;
		delete wfs; wfs = 0;
	}
	if (sds != 0) {
		for (unsigned i = 0; i < sds_N; i++) if (sds[i] != 0) delete sds[i], sds[i] = 0;
		delete sds; sds = 0;
	}
	if (SDS != 0) {
		for (int i = 0; i < sds_N; i++) delete SDS[i];
		delete SDS;
	}
	if (ZB != 0) delete ZB;
}




LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	auto InitializeClientBitmap = [](HWND hWnd, HBITMAP &hbmp, COLORREF* &pixels, bool order_pixels_from_top_to_bottom) {
		BITMAPINFO bmi;
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biWidth = clt_w;
		bmi.bmiHeader.biHeight = order_pixels_from_top_to_bottom ? -(long)clt_h : clt_h;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biCompression = BI_RGB;
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter = 0;
		bmi.bmiHeader.biYPelsPerMeter = 0;
		bmi.bmiHeader.biClrUsed = 0;
		bmi.bmiHeader.biClrImportant = 0;
		bmi.bmiColors[0].rgbBlue = 0;
		bmi.bmiColors[0].rgbGreen = 0;
		bmi.bmiColors[0].rgbRed = 0;
		bmi.bmiColors[0].rgbReserved = 0;
		HDC hdc = GetDC(hWnd);
		if (hbmp != NULL) DeleteObject(hbmp);
		hbmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
		DeleteDC(hdc);
	};
	switch (message) {
	case WM_CREATE: {
		GetClientRect(hWnd, &Client);
		clt_w = Client.right, clt_h = Client.bottom;
		InitializeClientBitmap(hWnd, HImg, img, false);
		HWnd = hWnd;
		GenerateTerrain();
		break;
	}
	case WM_MOVE:;
	case WM_SIZE: {
		GetClientRect(hWnd, &Client);
		if (Client.right*Client.bottom == 0) break;
		double prev_w = clt_w, prev_h = clt_h;
		clt_w = Client.right, clt_h = Client.bottom;
		Unit *= sqrt((clt_w * clt_h) / (prev_w * prev_h));
		DeleteObject(HImg);
		InitializeClientBitmap(hWnd, HImg, img, false);
		if (ZB != 0) delete ZB, ZB = new double[clt_w*clt_h];
		render();

		// Test the speed of different rendering methods
		auto Test = []() {
			typedef chrono::high_resolution_clock NTime;
			typedef std::chrono::duration<double> fsec;
			const unsigned N = 20;
			auto t0 = NTime::now();
			for (int i = 0; i < N; i++) render();
			auto t1 = NTime::now();
			fsec fs = t1 - t0;
			DBGLOG("\n" << (N / fs.count()) << "fps\n\n");
		};
		//Test(); exit(0);

		break;
	}
	case WM_GETMINMAXINFO: {
		LPMINMAXINFO lpMMI = (LPMINMAXINFO)lParam;
		lpMMI->ptMinTrackSize.x = 600, lpMMI->ptMinTrackSize.y = 400;
		break;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		HDC HMem = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(HMem, HImg);
		BitBlt(hdc, 0, 0, Client.right, Client.bottom, HMem, 0, 0, SRCCOPY);
		SelectObject(HMem, hbmOld);
		EndPaint(hWnd, &ps);
		DeleteDC(HMem);
		DeleteDC(hdc);
		break;
	}
	case WM_MOUSEMOVE: {
		Cursor.x = GET_X_LPARAM(lParam);
		Cursor.y = clt_h - GET_Y_LPARAM(lParam);
		if (mouse_down) {	// click and drag
			double dx = Cursor.x - OrigCursor.x, dy = OrigCursor.y - Cursor.y;
			dx /= 100, dy /= 120;
			rx = orig_rx, rz = orig_rz;
			rx += dy, rz += dx;
			render();
		}
		break;
	}
	case WM_LBUTTONDOWN: {
		mouse_down = true;
		OrigCursor.x = GET_X_LPARAM(lParam);
		OrigCursor.y = clt_h - GET_Y_LPARAM(lParam);
		orig_rx = rx, orig_rz = rz;
		break;
	}
	case WM_LBUTTONUP: {
		mouse_down = false;
		OrigCursor = vec2(NAN, NAN);
		break;
	}
	case WM_MOUSEWHEEL: {
		int delta = GET_WHEEL_DELTA_WPARAM(wParam);
		const double MAX = 1e+6, MIN = 1e-8;
		double d = exp(0.0005 * delta);
		if (Unit * d > MAX) d = MAX / Unit;
		else if (Unit * d < MIN) d = MIN / Unit;
		Unit *= d;
		render();
		break;
	}
	case WM_CLOSE: {
		DestroyWindow(hWnd);
		destruct();
		return 0;
	}
	case WM_DESTROY: {
		PostQuitMessage(0);
		return 0;
	}
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {

	//BreakOn(118);

	const wchar_t CLASS_NAME[] = _T("Fractal Landscape");
	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = wc.hIconSm = 0;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(RGB(16, 20, 23));
	wc.lpszMenuName = NULL;
	wc.lpszClassName = CLASS_NAME;
	if (!RegisterClassEx(&wc)) return -1;

	HWND hWnd = CreateWindowEx(
		0,
		CLASS_NAME,
		CLASS_NAME,
		WS_OVERLAPPEDWINDOW,
		//WS_MINIMIZEBOX | WS_SYSMENU | WS_POPUP | WS_CAPTION,
		CW_USEDEFAULT, CW_USEDEFAULT,
		900, 600,
		//600, 400,
		NULL, NULL, hInstance, NULL
	);
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	MSG message;
	while (GetMessage(&message, 0, 0, 0)) {
		TranslateMessage(&message);
		DispatchMessage(&message);
	}

	CheckMemoryLeaks;
	return (int)message.wParam;
}


